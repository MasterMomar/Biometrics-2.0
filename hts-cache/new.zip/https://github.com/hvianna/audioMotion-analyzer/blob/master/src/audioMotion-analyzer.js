





<!DOCTYPE html>
<html lang="en" data-color-mode="auto" data-light-theme="light" data-dark-theme="dark"  data-a11y-animated-images="system" data-a11y-link-underlines="false">


  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">
  <link rel="preconnect" href="https://github.githubassets.com" crossorigin>
  <link rel="preconnect" href="https://avatars.githubusercontent.com">

  


  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/light-a09cef873428.css" /><link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/dark-5d486a4ede8e.css" /><link data-color-theme="dark_dimmed" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_dimmed-27c8d635e4e5.css" /><link data-color-theme="dark_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_high_contrast-8438e75afd36.css" /><link data-color-theme="dark_colorblind" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_colorblind-bf5665b96628.css" /><link data-color-theme="light_colorblind" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_colorblind-c414b5ba1dce.css" /><link data-color-theme="light_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_high_contrast-e5868b7374db.css" /><link data-color-theme="light_tritanopia" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_tritanopia-299ac9c64ec0.css" /><link data-color-theme="dark_tritanopia" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_tritanopia-3a26e78ad0ff.css" />
  
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-primitives-6143c8f97ed1.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-047ee6293fcd.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/global-d7555a777bd9.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/github-af3c6af5a9a7.css" />
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/code-1fecec11b11c.css" />

  

  <script type="application/json" id="client-env">{"locale":"en","featureFlags":["failbot_handle_non_errors","geojson_azure_maps","image_metric_tracking","turbo_experiment_risky","sample_network_conn_type"]}</script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/wp-runtime-bd4a13d3c20a.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_dompurify_dist_purify_js-64d590970fa6.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_stacktrace-parser_dist_stack-trace-parser_esm_js-node_modules_github_bro-a4c183-18bf85b8e9f4.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_soft-nav_soft-nav_ts-df17d5597d8f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/environment-509b58e05b9f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_selector-observer_dist_index_esm_js-2646a2c533e3.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_behaviors_dist_esm_focus-zone_js-d55308df5023.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_relative-time-element_dist_index_js-99e288659d4f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_delegated-events_dist_index_js-node_modules_github_auto-complete-element-5b3870-9b38c0812424.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_filter-input-element_dist_index_js-node_modules_github_remote-inp-d1569f-eb0e0c1e5438.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_file-attachment-element_dist_index_js-node_modules_primer_view-co-821777-aecaf1b5e5fa.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/github-elements-424a6c363e13.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/element-registry-d892b58419fa.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_lit-html_lit-html_js-9d9fe1859ce5.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_hydro-analytics-client_dist_analytics-client_js-node_modules_gith-f3aee1-fd3c22610e40.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_index_js-node_modules_github_alive-client_dist-bf5aa2-4aefce0fc3c8.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_morphdom_dist_morphdom-esm_js-b1fdd7158cf0.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_turbo_dist_turbo_es2017-esm_js-1f4793023fcd.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_remote-form_dist_index_js-node_modules_scroll-anchoring_dist_scro-52dc4b-e1e33bfc0b7e.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_color-convert_index_js-35b3ae68c408.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_paste-markdown_dist_index_esm_js-node_modules_github_quote-select-426751-0153d059d677.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_details-dialog_ts-app_assets_modules_github_fetch_ts-9ca164041015.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_updatable-content_ts-ui_packages_hydro-analytics_hydro-analytics_ts-e4da304b75e7.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_onfocus_ts-app_assets_modules_github_sticky-scroll-into-view_ts-b88dcdb1ae32.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_task-list_ts-app_assets_modules_github_sso_ts-ui_packages-7d50ad-9491f2be61ee.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_ajax-error_ts-app_assets_modules_github_behaviors_include-2e2258-f7b8ad0ef997.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_commenting_edit_ts-app_assets_modules_github_behaviors_ht-83c235-f22ac6b94445.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/behaviors-03fc0e2fb4bb.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_delegated-events_dist_index_js-node_modules_github_catalyst_lib_index_js-06ff531-fe0b8ccc90a5.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/notifications-global-f57687007bfc.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/code-menu-c743a13234fc.js"></script>
  
  <script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/react-lib-210c4b5934c3.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_octicons-react_dist_index_esm_js-node_modules_primer_react_lib-es-3db9ab-258f1f04207a.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Box_Box_js-8d2713f90c9a.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Button_Button_js-node_modules_primer_react_lib-esm_-c2022e-88c4ecff094b.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Truncate_Truncate_js-node_modules_primer_react_lib--5d1957-6153f21fb087.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Button_index_js-node_modules_primer_react_lib-esm_O-133b0c-6f42d36f1de7.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_TextInput_TextInput_js-b86f4e68bb7f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_ActionList_index_js-2ef65721de15.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_behaviors_dist_esm_scroll-into-view_js-node_modules_primer_react_-04bb1b-c16a26e8811a.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_ActionMenu_ActionMenu_js-54f723818b04.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_FormControl_FormControl_js-66072033b955.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_react-router-dom_dist_index_js-4a785319b497.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_PageLayout_PageLayout_js-0bc476b118a0.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Avatar_Avatar_js-node_modules_primer_react_lib-esm_-164d19-6fcb4b6762d4.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_Dialog_js-node_modules_primer_react_lib-esm_TabNav_-8321f5-b3cddef78a7e.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_UnderlineNav2_index_js-4c97d31072c1.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_TreeView_TreeView_js-838f9e6cacf9.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_BranchName_BranchName_js-node_modules_primer_react_-463c3e-ff8eea0fcaf1.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_react_lib-esm_AvatarStack_AvatarStack_js-node_modules_primer_reac-957af0-12aa4721b5bf.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_react-core_create-browser-history_ts-ui_packages_react-core_deferred-registry_ts--ebbb92-f46ec58c6478.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_react-core_register-app_ts-4c8aa7d9158e.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/ui_packages_ref-selector_RefSelector_tsx-9cbaf85c5199.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_blob-anchor_ts-app_assets_modules_github_filter-sort_ts-app_assets_-681869-f24eab09c9e6.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_react-code-view_pages_CodeView_tsx-f056a12a18e4.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/react-code-view-34e6e6a0fe71.js"></script>


  <title>audioMotion-analyzer/src/audioMotion-analyzer.js at master · hvianna/audioMotion-analyzer · GitHub</title>



  <meta name="route-pattern" content="/:user_id/:repository/blob/*name(/*path)">

    
  <meta name="current-catalog-service-hash" content="82c569b93da5c18ed649ebd4c2c79437db4611a6a1373e805a3cb001c64130b7">


  <meta name="request-id" content="2BE2:794D:1CB0B7:298D48:65131A78" data-pjax-transient="true"/><meta name="html-safe-nonce" content="6f97900a72bac996d6d7031bf96f7a924e57be983a04b76edaeb1f739ecf1554" data-pjax-transient="true"/><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHA6Ly9naXRodWIuY29tL2h2aWFubmEvYXVkaW9Nb3Rpb24tYW5hbHl6ZXIvYmxvYi9tYXN0ZXIvZGVtby9tdWx0aS5qcyIsInJlcXVlc3RfaWQiOiIyQkUyOjc5NEQ6MUNCMEI3OjI5OEQ0ODo2NTEzMUE3OCIsInZpc2l0b3JfaWQiOiI1MjYyNzE1MTM5OTIxMjIyMTMxIiwicmVnaW9uX2VkZ2UiOiJpYWQiLCJyZWdpb25fcmVuZGVyIjoiaWFkIn0=" data-pjax-transient="true"/><meta name="visitor-hmac" content="18f60766546791e1a5e222b032b0a0258cd43f06c47c0bdee54180596601136f" data-pjax-transient="true"/>


    <meta name="hovercard-subject-tag" content="repository:191051179" data-turbo-transient>


  <meta name="github-keyboard-shortcuts" content="repository,source-code,file-tree" data-turbo-transient="true" />
  

  <meta name="selected-link" value="repo_source" data-turbo-transient>
  <link rel="assets" href="https://github.githubassets.com/">

    <meta name="google-site-verification" content="c1kuD-K2HIVF635lypcsWPoD4kilo5-jA_wBFyT4uMY">
  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
  <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
  <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">
  <meta name="google-site-verification" content="Apib7-x98H0j5cPqHWwSMm6dNU4GmODRoqxLiDzdx9I">

<meta name="octolytics-url" content="https://collector.github.com/github/collect" />

  <meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/show" data-turbo-transient="true" />

  




  

    <meta name="user-login" content="">

  

    <meta name="viewport" content="width=device-width">
    
      <meta name="description" content="High-resolution real-time graphic audio spectrum analyzer JavaScript module with no dependencies. - audioMotion-analyzer/src/audioMotion-analyzer.js at master · hvianna/audioMotion-analyzer">
      <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <meta property="fb:app_id" content="1401488693436528">
    <meta name="apple-itunes-app" content="app-id=1477376905, app-argument=https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js" />
      <meta name="twitter:image:src" content="https://repository-images.githubusercontent.com/191051179/c583d100-800a-11ea-8659-5cfbfdf61805" /><meta name="twitter:site" content="@github" /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content="audioMotion-analyzer/src/audioMotion-analyzer.js at master · hvianna/audioMotion-analyzer" /><meta name="twitter:description" content="High-resolution real-time graphic audio spectrum analyzer JavaScript module with no dependencies. - hvianna/audioMotion-analyzer" />
      <meta property="og:image" content="https://repository-images.githubusercontent.com/191051179/c583d100-800a-11ea-8659-5cfbfdf61805" /><meta property="og:image:alt" content="High-resolution real-time graphic audio spectrum analyzer JavaScript module with no dependencies. - hvianna/audioMotion-analyzer" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="audioMotion-analyzer/src/audioMotion-analyzer.js at master · hvianna/audioMotion-analyzer" /><meta property="og:url" content="https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js" /><meta property="og:description" content="High-resolution real-time graphic audio spectrum analyzer JavaScript module with no dependencies. - hvianna/audioMotion-analyzer" />
      



        <meta name="hostname" content="github.com">



        <meta name="expected-hostname" content="github.com">


  <meta http-equiv="x-pjax-version" content="514e014c5d9fdfafd5944c16ec191a88c3584d9981e40127e8187e43afe0f65b" data-turbo-track="reload">
  <meta http-equiv="x-pjax-csp-version" content="e804c38ee3350492314d64554f04af42b36a24b682b0e84414a6d326d62b74dc" data-turbo-track="reload">
  <meta http-equiv="x-pjax-css-version" content="4980b4b3869a07ac6ffece40d2da32f0edf317486270d49ee15d7c89bc971b8a" data-turbo-track="reload">
  <meta http-equiv="x-pjax-js-version" content="3bd0101b90e0c2ea1907885bb7680e7022ada382f00f40d4e85a314087471fbb" data-turbo-track="reload">

  <meta name="turbo-cache-control" content="no-preview" data-turbo-transient="">

      <meta name="turbo-cache-control" content="no-cache" data-turbo-transient>
    <meta data-hydrostats="publish">

  <meta name="go-import" content="github.com/hvianna/audioMotion-analyzer git https://github.com/hvianna/audioMotion-analyzer.git">

  <meta name="octolytics-dimension-user_id" content="1033735" /><meta name="octolytics-dimension-user_login" content="hvianna" /><meta name="octolytics-dimension-repository_id" content="191051179" /><meta name="octolytics-dimension-repository_nwo" content="hvianna/audioMotion-analyzer" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="191051179" /><meta name="octolytics-dimension-repository_network_root_nwo" content="hvianna/audioMotion-analyzer" />



  <meta name="turbo-body-classes" content="logged-out env-production page-responsive">


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <meta name="browser-optimizely-client-errors-url" content="https://api.github.com/_private/browser/optimizely_client/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="alternate icon" class="js-site-favicon" type="image/png" href="https://github.githubassets.com/favicons/favicon.png">
  <link rel="icon" class="js-site-favicon" type="image/svg+xml" href="https://github.githubassets.com/favicons/favicon.svg">

<meta name="theme-color" content="#1e2327">
<meta name="color-scheme" content="light dark" />


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production page-responsive" style="word-wrap: break-word;">
    <div data-turbo-body class="logged-out env-production page-responsive" style="word-wrap: break-word;">
      


    <div class="position-relative js-header-wrapper ">
      <a href="#start-of-content" class="px-2 py-4 color-bg-accent-emphasis color-fg-on-emphasis show-on-focus js-skip-to-content">Skip to content</a>
      <span data-view-component="true" class="progress-pjax-loader Progress position-fixed width-full">
    <span style="width: 0%;" data-view-component="true" class="Progress-item progress-pjax-loader-bar left-0 top-0 color-bg-accent-emphasis"></span>
</span>      
      


      

        

            

<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_remote-form_dist_index_js-node_modules_delegated-events_dist_inde-94fd67-8311888324b2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" src="https://github.githubassets.com/assets/sessions-76b694b87336.js"></script>
<header class="Header-old header-logged-out js-details-container Details position-relative f4 py-3" role="banner" data-color-mode=light data-light-theme=light data-dark-theme=dark>
  <button type="button" class="Header-backdrop d-lg-none border-0 position-fixed top-0 left-0 width-full height-full js-details-target" aria-label="Toggle navigation">
    <span class="d-none">Toggle navigation</span>
  </button>

  <div class=" d-flex flex-column flex-lg-row flex-items-center p-responsive height-full position-relative z-1">
    <div class="d-flex flex-justify-between flex-items-center width-full width-lg-auto">
      <a class="mr-lg-3 color-fg-inherit flex-order-2" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
        <svg height="32" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="32" data-view-component="true" class="octicon octicon-mark-github">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path>
</svg>
      </a>

        <div class="flex-1">
          <a href="/signup?ref_cta=Sign+up&amp;ref_loc=header+logged+out&amp;ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Fblob%2Fshow&amp;source=header-repo"
            class="d-inline-block d-lg-none flex-order-1 f5 no-underline border color-border-default rounded-2 px-2 py-1 color-fg-inherit"
            data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="ef92af6ab6752bc8e0c1fe7aad637e176fc37ab2facd02922a47e23e8e7aa83c"
          >
            Sign&nbsp;up
          </a>
        </div>

      <div class="flex-1 flex-order-2 text-right">
          <button aria-label="Toggle navigation" aria-expanded="false" type="button" data-view-component="true" class="js-details-target Button--link Button--medium Button d-lg-none color-fg-inherit p-1">    <span class="Button-content">
      <span class="Button-label"><div class="HeaderMenu-toggle-bar rounded my-1"></div>
            <div class="HeaderMenu-toggle-bar rounded my-1"></div>
            <div class="HeaderMenu-toggle-bar rounded my-1"></div></span>
    </span>
</button>  
      </div>
    </div>


    <div class="HeaderMenu--logged-out p-responsive height-fit position-lg-relative d-lg-flex flex-column flex-auto pt-7 pb-4 top-0">
      <div class="header-menu-wrapper d-flex flex-column flex-self-end flex-lg-row flex-justify-between flex-auto p-3 p-lg-0 rounded rounded-lg-0 mt-3 mt-lg-0">
          <nav class="mt-0 px-3 px-lg-0 mb-3 mb-lg-0" aria-label="Global">
            <ul class="d-lg-flex list-style-none">
                <li class="HeaderMenu-item position-relative flex-wrap flex-justify-between flex-items-center d-block d-lg-flex flex-lg-nowrap flex-lg-items-center js-details-container js-header-menu-item">
      <button type="button" class="HeaderMenu-link border-0 width-full width-lg-auto px-0 px-lg-2 py-3 py-lg-2 no-wrap d-flex flex-items-center flex-justify-between js-details-target" aria-expanded="false">
        Product
        <svg opacity="0.5" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-chevron-down HeaderMenu-icon ml-1">
    <path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path>
</svg>
      </button>
      <div class="HeaderMenu-dropdown dropdown-menu rounded m-0 p-0 py-2 py-lg-4 position-relative position-lg-absolute left-0 left-lg-n3 d-lg-flex dropdown-menu-wide">
          <div class="px-lg-4 border-lg-right mb-4 mb-lg-0 pr-lg-7">
            <ul class="list-style-none f5" >
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center pb-lg-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Actions&quot;,&quot;label&quot;:&quot;ref_cta:Actions;&quot;}" href="/features/actions">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-workflow color-fg-subtle mr-3">
    <path d="M1 3a2 2 0 0 1 2-2h6.5a2 2 0 0 1 2 2v6.5a2 2 0 0 1-2 2H7v4.063C7 16.355 7.644 17 8.438 17H12.5v-2.5a2 2 0 0 1 2-2H21a2 2 0 0 1 2 2V21a2 2 0 0 1-2 2h-6.5a2 2 0 0 1-2-2v-2.5H8.437A2.939 2.939 0 0 1 5.5 15.562V11.5H3a2 2 0 0 1-2-2Zm2-.5a.5.5 0 0 0-.5.5v6.5a.5.5 0 0 0 .5.5h6.5a.5.5 0 0 0 .5-.5V3a.5.5 0 0 0-.5-.5ZM14.5 14a.5.5 0 0 0-.5.5V21a.5.5 0 0 0 .5.5H21a.5.5 0 0 0 .5-.5v-6.5a.5.5 0 0 0-.5-.5Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Actions</div>
        Automate any workflow
      </div>

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center pb-lg-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Packages&quot;,&quot;label&quot;:&quot;ref_cta:Packages;&quot;}" href="/features/packages">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-package color-fg-subtle mr-3">
    <path d="M12.876.64V.639l8.25 4.763c.541.313.875.89.875 1.515v9.525a1.75 1.75 0 0 1-.875 1.516l-8.25 4.762a1.748 1.748 0 0 1-1.75 0l-8.25-4.763a1.75 1.75 0 0 1-.875-1.515V6.917c0-.625.334-1.202.875-1.515L11.126.64a1.748 1.748 0 0 1 1.75 0Zm-1 1.298L4.251 6.34l7.75 4.474 7.75-4.474-7.625-4.402a.248.248 0 0 0-.25 0Zm.875 19.123 7.625-4.402a.25.25 0 0 0 .125-.216V7.639l-7.75 4.474ZM3.501 7.64v8.803c0 .09.048.172.125.216l7.625 4.402v-8.947Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Packages</div>
        Host and manage packages
      </div>

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center pb-lg-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Security&quot;,&quot;label&quot;:&quot;ref_cta:Security;&quot;}" href="/features/security">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-shield-check color-fg-subtle mr-3">
    <path d="M16.53 9.78a.75.75 0 0 0-1.06-1.06L11 13.19l-1.97-1.97a.75.75 0 0 0-1.06 1.06l2.5 2.5a.75.75 0 0 0 1.06 0l5-5Z"></path><path d="m12.54.637 8.25 2.675A1.75 1.75 0 0 1 22 4.976V10c0 6.19-3.771 10.704-9.401 12.83a1.704 1.704 0 0 1-1.198 0C5.77 20.705 2 16.19 2 10V4.976c0-.758.489-1.43 1.21-1.664L11.46.637a1.748 1.748 0 0 1 1.08 0Zm-.617 1.426-8.25 2.676a.249.249 0 0 0-.173.237V10c0 5.46 3.28 9.483 8.43 11.426a.199.199 0 0 0 .14 0C17.22 19.483 20.5 15.461 20.5 10V4.976a.25.25 0 0 0-.173-.237l-8.25-2.676a.253.253 0 0 0-.154 0Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Security</div>
        Find and fix vulnerabilities
      </div>

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center pb-lg-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Codespaces&quot;,&quot;label&quot;:&quot;ref_cta:Codespaces;&quot;}" href="/features/codespaces">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-codespaces color-fg-subtle mr-3">
    <path d="M3.5 3.75C3.5 2.784 4.284 2 5.25 2h13.5c.966 0 1.75.784 1.75 1.75v7.5A1.75 1.75 0 0 1 18.75 13H5.25a1.75 1.75 0 0 1-1.75-1.75Zm-2 12c0-.966.784-1.75 1.75-1.75h17.5c.966 0 1.75.784 1.75 1.75v4a1.75 1.75 0 0 1-1.75 1.75H3.25a1.75 1.75 0 0 1-1.75-1.75ZM5.25 3.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h13.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Zm-2 12a.25.25 0 0 0-.25.25v4c0 .138.112.25.25.25h17.5a.25.25 0 0 0 .25-.25v-4a.25.25 0 0 0-.25-.25Z"></path><path d="M10 17.75a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 0 1.5h-6.5a.75.75 0 0 1-.75-.75Zm-4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1-.75-.75Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Codespaces</div>
        Instant dev environments
      </div>

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center pb-lg-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Copilot&quot;,&quot;label&quot;:&quot;ref_cta:Copilot;&quot;}" href="/features/copilot">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-copilot color-fg-subtle mr-3">
    <path d="M23.922 16.992c-.861 1.495-5.859 5.023-11.922 5.023-6.063 0-11.061-3.528-11.922-5.023A.641.641 0 0 1 0 16.736v-2.869a.841.841 0 0 1 .053-.22c.372-.935 1.347-2.292 2.605-2.656.167-.429.414-1.055.644-1.517a10.195 10.195 0 0 1-.052-1.086c0-1.331.282-2.499 1.132-3.368.397-.406.89-.717 1.474-.952 1.399-1.136 3.392-2.093 6.122-2.093 2.731 0 4.767.957 6.166 2.093.584.235 1.077.546 1.474.952.85.869 1.132 2.037 1.132 3.368 0 .368-.014.733-.052 1.086.23.462.477 1.088.644 1.517 1.258.364 2.233 1.721 2.605 2.656a.832.832 0 0 1 .053.22v2.869a.641.641 0 0 1-.078.256ZM12.172 11h-.344a4.323 4.323 0 0 1-.355.508C10.703 12.455 9.555 13 7.965 13c-1.725 0-2.989-.359-3.782-1.259a2.005 2.005 0 0 1-.085-.104L4 11.741v6.585c1.435.779 4.514 2.179 8 2.179 3.486 0 6.565-1.4 8-2.179v-6.585l-.098-.104s-.033.045-.085.104c-.793.9-2.057 1.259-3.782 1.259-1.59 0-2.738-.545-3.508-1.492a4.323 4.323 0 0 1-.355-.508h-.016.016Zm.641-2.935c.136 1.057.403 1.913.878 2.497.442.544 1.134.938 2.344.938 1.573 0 2.292-.337 2.657-.751.384-.435.558-1.15.558-2.361 0-1.14-.243-1.847-.705-2.319-.477-.488-1.319-.862-2.824-1.025-1.487-.161-2.192.138-2.533.529-.269.307-.437.808-.438 1.578v.021c0 .265.021.562.063.893Zm-1.626 0c.042-.331.063-.628.063-.894v-.02c-.001-.77-.169-1.271-.438-1.578-.341-.391-1.046-.69-2.533-.529-1.505.163-2.347.537-2.824 1.025-.462.472-.705 1.179-.705 2.319 0 1.211.175 1.926.558 2.361.365.414 1.084.751 2.657.751 1.21 0 1.902-.394 2.344-.938.475-.584.742-1.44.878-2.497Z"></path><path d="M14.5 14.25a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1Zm-5 0a1 1 0 0 1 1 1v2a1 1 0 0 1-2 0v-2a1 1 0 0 1 1-1Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Copilot</div>
        Write better code with AI
      </div>

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center pb-lg-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Code review&quot;,&quot;label&quot;:&quot;ref_cta:Code review;&quot;}" href="/features/code-review">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-code-review color-fg-subtle mr-3">
    <path d="M10.3 6.74a.75.75 0 0 1-.04 1.06l-2.908 2.7 2.908 2.7a.75.75 0 1 1-1.02 1.1l-3.5-3.25a.75.75 0 0 1 0-1.1l3.5-3.25a.75.75 0 0 1 1.06.04Zm3.44 1.06a.75.75 0 1 1 1.02-1.1l3.5 3.25a.75.75 0 0 1 0 1.1l-3.5 3.25a.75.75 0 1 1-1.02-1.1l2.908-2.7-2.908-2.7Z"></path><path d="M1.5 4.25c0-.966.784-1.75 1.75-1.75h17.5c.966 0 1.75.784 1.75 1.75v12.5a1.75 1.75 0 0 1-1.75 1.75h-9.69l-3.573 3.573A1.458 1.458 0 0 1 5 21.043V18.5H3.25a1.75 1.75 0 0 1-1.75-1.75ZM3.25 4a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h2.5a.75.75 0 0 1 .75.75v3.19l3.72-3.72a.749.749 0 0 1 .53-.22h10a.25.25 0 0 0 .25-.25V4.25a.25.25 0 0 0-.25-.25Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Code review</div>
        Manage code changes
      </div>

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center pb-lg-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Issues&quot;,&quot;label&quot;:&quot;ref_cta:Issues;&quot;}" href="/features/issues">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-issue-opened color-fg-subtle mr-3">
    <path d="M12 1c6.075 0 11 4.925 11 11s-4.925 11-11 11S1 18.075 1 12 5.925 1 12 1ZM2.5 12a9.5 9.5 0 0 0 9.5 9.5 9.5 9.5 0 0 0 9.5-9.5A9.5 9.5 0 0 0 12 2.5 9.5 9.5 0 0 0 2.5 12Zm9.5 2a2 2 0 1 1-.001-3.999A2 2 0 0 1 12 14Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Issues</div>
        Plan and track work
      </div>

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Discussions&quot;,&quot;label&quot;:&quot;ref_cta:Discussions;&quot;}" href="/features/discussions">
      <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-comment-discussion color-fg-subtle mr-3">
    <path d="M1.75 1h12.5c.966 0 1.75.784 1.75 1.75v9.5A1.75 1.75 0 0 1 14.25 14H8.061l-2.574 2.573A1.458 1.458 0 0 1 3 15.543V14H1.75A1.75 1.75 0 0 1 0 12.25v-9.5C0 1.784.784 1 1.75 1ZM1.5 2.75v9.5c0 .138.112.25.25.25h2a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h6.5a.25.25 0 0 0 .25-.25v-9.5a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25Z"></path><path d="M22.5 8.75a.25.25 0 0 0-.25-.25h-3.5a.75.75 0 0 1 0-1.5h3.5c.966 0 1.75.784 1.75 1.75v9.5A1.75 1.75 0 0 1 22.25 20H21v1.543a1.457 1.457 0 0 1-2.487 1.03L15.939 20H10.75A1.75 1.75 0 0 1 9 18.25v-1.465a.75.75 0 0 1 1.5 0v1.465c0 .138.112.25.25.25h5.5a.75.75 0 0 1 .53.22l2.72 2.72v-2.19a.75.75 0 0 1 .75-.75h2a.25.25 0 0 0 .25-.25v-9.5Z"></path>
</svg>
      <div>
        <div class="color-fg-default h4">Discussions</div>
        Collaborate outside of code
      </div>

    
</a></li>

            </ul>
          </div>
          <div class="px-lg-4">
              <span class="d-block h4 color-fg-default my-1" id="product-explore-heading">Explore</span>
            <ul class="list-style-none f5" aria-labelledby="product-explore-heading">
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to All features&quot;,&quot;label&quot;:&quot;ref_cta:All features;&quot;}" href="/features">
      All features

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Documentation&quot;,&quot;label&quot;:&quot;ref_cta:Documentation;&quot;}" href="https://docs.github.com">
      Documentation

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to GitHub Skills&quot;,&quot;label&quot;:&quot;ref_cta:GitHub Skills;&quot;}" href="https://skills.github.com/">
      GitHub Skills

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Blog&quot;,&quot;label&quot;:&quot;ref_cta:Blog;&quot;}" href="https://github.blog">
      Blog

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

            </ul>
          </div>
      </div>
</li>


                <li class="HeaderMenu-item position-relative flex-wrap flex-justify-between flex-items-center d-block d-lg-flex flex-lg-nowrap flex-lg-items-center js-details-container js-header-menu-item">
      <button type="button" class="HeaderMenu-link border-0 width-full width-lg-auto px-0 px-lg-2 py-3 py-lg-2 no-wrap d-flex flex-items-center flex-justify-between js-details-target" aria-expanded="false">
        Solutions
        <svg opacity="0.5" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-chevron-down HeaderMenu-icon ml-1">
    <path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path>
</svg>
      </button>
      <div class="HeaderMenu-dropdown dropdown-menu rounded m-0 p-0 py-2 py-lg-4 position-relative position-lg-absolute left-0 left-lg-n3 px-lg-4">
          <div class="border-bottom pb-3 mb-3">
              <span class="d-block h4 color-fg-default my-1" id="solutions-for-heading">For</span>
            <ul class="list-style-none f5" aria-labelledby="solutions-for-heading">
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to Enterprise&quot;,&quot;label&quot;:&quot;ref_cta:Enterprise;&quot;}" href="/enterprise">
      Enterprise

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to Teams&quot;,&quot;label&quot;:&quot;ref_cta:Teams;&quot;}" href="/team">
      Teams

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to Startups&quot;,&quot;label&quot;:&quot;ref_cta:Startups;&quot;}" href="/enterprise/startups">
      Startups

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to Education&quot;,&quot;label&quot;:&quot;ref_cta:Education;&quot;}" href="https://education.github.com">
      Education

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

            </ul>
          </div>
          <div class="border-bottom pb-3 mb-3">
              <span class="d-block h4 color-fg-default my-1" id="solutions-by-solution-heading">By Solution</span>
            <ul class="list-style-none f5" aria-labelledby="solutions-by-solution-heading">
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to CI/CD &amp;amp; Automation&quot;,&quot;label&quot;:&quot;ref_cta:CI/CD &amp;amp; Automation;&quot;}" href="/solutions/ci-cd/">
      CI/CD &amp; Automation

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to DevOps&quot;,&quot;label&quot;:&quot;ref_cta:DevOps;&quot;}" href="https://resources.github.com/devops/">
      DevOps

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to DevSecOps&quot;,&quot;label&quot;:&quot;ref_cta:DevSecOps;&quot;}" href="https://resources.github.com/devops/fundamentals/devsecops/">
      DevSecOps

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

            </ul>
          </div>
          <div class="">
              <span class="d-block h4 color-fg-default my-1" id="solutions-resources-heading">Resources</span>
            <ul class="list-style-none f5" aria-labelledby="solutions-resources-heading">
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to Learning Pathways&quot;,&quot;label&quot;:&quot;ref_cta:Learning Pathways;&quot;}" href="https://resources.github.com/learn/pathways/">
      Learning Pathways

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to White papers, Ebooks, Webinars&quot;,&quot;label&quot;:&quot;ref_cta:White papers, Ebooks, Webinars;&quot;}" href="https://resources.github.com/">
      White papers, Ebooks, Webinars

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to Customer Stories&quot;,&quot;label&quot;:&quot;ref_cta:Customer Stories;&quot;}" href="/customer-stories">
      Customer Stories

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" target="_blank" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Solutions&quot;,&quot;action&quot;:&quot;click to go to Partners&quot;,&quot;label&quot;:&quot;ref_cta:Partners;&quot;}" href="https://partner.github.com/">
      Partners

    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-link-external HeaderMenu-external-icon color-fg-subtle">
    <path d="M3.75 2h3.5a.75.75 0 0 1 0 1.5h-3.5a.25.25 0 0 0-.25.25v8.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-3.5a.75.75 0 0 1 1.5 0v3.5A1.75 1.75 0 0 1 12.25 14h-8.5A1.75 1.75 0 0 1 2 12.25v-8.5C2 2.784 2.784 2 3.75 2Zm6.854-1h4.146a.25.25 0 0 1 .25.25v4.146a.25.25 0 0 1-.427.177L13.03 4.03 9.28 7.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.75-3.75-1.543-1.543A.25.25 0 0 1 10.604 1Z"></path>
</svg>
</a></li>

            </ul>
          </div>
      </div>
</li>


                <li class="HeaderMenu-item position-relative flex-wrap flex-justify-between flex-items-center d-block d-lg-flex flex-lg-nowrap flex-lg-items-center js-details-container js-header-menu-item">
      <button type="button" class="HeaderMenu-link border-0 width-full width-lg-auto px-0 px-lg-2 py-3 py-lg-2 no-wrap d-flex flex-items-center flex-justify-between js-details-target" aria-expanded="false">
        Open Source
        <svg opacity="0.5" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-chevron-down HeaderMenu-icon ml-1">
    <path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path>
</svg>
      </button>
      <div class="HeaderMenu-dropdown dropdown-menu rounded m-0 p-0 py-2 py-lg-4 position-relative position-lg-absolute left-0 left-lg-n3 px-lg-4">
          <div class="border-bottom pb-3 mb-3">
            <ul class="list-style-none f5" >
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Open Source&quot;,&quot;action&quot;:&quot;click to go to GitHub Sponsors&quot;,&quot;label&quot;:&quot;ref_cta:GitHub Sponsors;&quot;}" href="/sponsors">
      
      <div>
        <div class="color-fg-default h4">GitHub Sponsors</div>
        Fund open source developers
      </div>

    
</a></li>

            </ul>
          </div>
          <div class="border-bottom pb-3 mb-3">
            <ul class="list-style-none f5" >
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary d-flex flex-items-center" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Open Source&quot;,&quot;action&quot;:&quot;click to go to The ReadME Project&quot;,&quot;label&quot;:&quot;ref_cta:The ReadME Project;&quot;}" href="/readme">
      
      <div>
        <div class="color-fg-default h4">The ReadME Project</div>
        GitHub community articles
      </div>

    
</a></li>

            </ul>
          </div>
          <div class="">
              <span class="d-block h4 color-fg-default my-1" id="open-source-repositories-heading">Repositories</span>
            <ul class="list-style-none f5" aria-labelledby="open-source-repositories-heading">
                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Open Source&quot;,&quot;action&quot;:&quot;click to go to Topics&quot;,&quot;label&quot;:&quot;ref_cta:Topics;&quot;}" href="/topics">
      Topics

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Open Source&quot;,&quot;action&quot;:&quot;click to go to Trending&quot;,&quot;label&quot;:&quot;ref_cta:Trending;&quot;}" href="/trending">
      Trending

    
</a></li>

                <li>
  <a class="HeaderMenu-dropdown-link lh-condensed d-block no-underline position-relative py-2 Link--secondary" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Open Source&quot;,&quot;action&quot;:&quot;click to go to Collections&quot;,&quot;label&quot;:&quot;ref_cta:Collections;&quot;}" href="/collections">
      Collections

    
</a></li>

            </ul>
          </div>
      </div>
</li>


                <li class="HeaderMenu-item position-relative flex-wrap flex-justify-between flex-items-center d-block d-lg-flex flex-lg-nowrap flex-lg-items-center js-details-container js-header-menu-item">
    <a class="HeaderMenu-link no-underline px-0 px-lg-2 py-3 py-lg-2 d-block d-lg-inline-block" data-analytics-event="{&quot;category&quot;:&quot;Header menu top item (logged out)&quot;,&quot;action&quot;:&quot;click to go to Pricing&quot;,&quot;label&quot;:&quot;ref_cta:Pricing;&quot;}" href="/pricing">Pricing</a>
</li>

            </ul>
          </nav>

        <div class="d-lg-flex flex-items-center mb-3 mb-lg-0 text-center text-lg-left ml-3" style="">
                


<qbsearch-input class="search-input" data-scope="repo:hvianna/audioMotion-analyzer" data-custom-scopes-path="/search/custom_scopes" data-delete-custom-scopes-csrf="q8JG_jo7a7MwifTOaAfM0rdJA8eQ3hcJkpqzq3i6LInIx2a5FTUSbdswg9eM0iZ2NOqKkyZpngjBdDdbNOqecw" data-max-custom-scopes="10" data-header-redesign-enabled="false" data-initial-value="" data-blackbird-suggestions-path="/search/suggestions" data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations" data-current-repository="hvianna/audioMotion-analyzer" data-current-org="" data-current-owner="hvianna" data-logged-in="false">
  <div
    class="search-input-container search-with-dialog position-relative d-flex flex-row flex-items-center mr-4 rounded"
    data-action="click:qbsearch-input#searchInputContainerClicked"
  >
      <button
        type="button"
        class="header-search-button placeholder  input-button form-control d-flex flex-1 flex-self-stretch flex-items-center no-wrap width-full py-0 pl-2 pr-0 text-left border-0 box-shadow-none"
        data-target="qbsearch-input.inputButton"
        placeholder="Search or jump to..."
        data-hotkey=s,/
        autocapitalize="off"
        data-action="click:qbsearch-input#handleExpand"
      >
        <div class="mr-2 color-fg-muted">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
        </div>
        <span class="flex-1" data-target="qbsearch-input.inputButtonText">Search or jump to...</span>
          <div class="d-flex" data-target="qbsearch-input.hotkeyIndicator">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="20" aria-hidden="true" class="mr-1"><path fill="none" stroke="#979A9C" opacity=".4" d="M3.5.5h12c1.7 0 3 1.3 3 3v13c0 1.7-1.3 3-3 3h-12c-1.7 0-3-1.3-3-3v-13c0-1.7 1.3-3 3-3z"></path><path fill="#979A9C" d="M11.8 6L8 15.1h-.9L10.8 6h1z"></path></svg>

          </div>
      </button>

    <input type="hidden" name="type" class="js-site-search-type-field">

    
<div class="Overlay--hidden " data-modal-dialog-overlay>
  <modal-dialog data-action="close:qbsearch-input#handleClose cancel:qbsearch-input#handleClose" data-target="qbsearch-input.searchSuggestionsDialog" role="dialog" id="search-suggestions-dialog" aria-modal="true" aria-labelledby="search-suggestions-dialog-header" data-view-component="true" class="Overlay Overlay--width-large Overlay--height-auto">
      <h1 id="search-suggestions-dialog-header" class="sr-only">Search code, repositories, users, issues, pull requests...</h1>
    <div class="Overlay-body Overlay-body--paddingNone">
      
          <div data-view-component="true">        <div class="search-suggestions position-fixed width-full color-shadow-large border color-fg-default color-bg-default overflow-hidden d-flex flex-column query-builder-container"
          style="border-radius: 12px;"
          data-target="qbsearch-input.queryBuilderContainer"
          hidden
        >
          <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="query-builder-test-form" action="" accept-charset="UTF-8" method="get">
  <query-builder data-target="qbsearch-input.queryBuilder" id="query-builder-query-builder-test" data-filter-key=":" data-view-component="true" class="QueryBuilder search-query-builder">
    <div class="FormControl FormControl--fullWidth">
      <label id="query-builder-test-label" for="query-builder-test" class="FormControl-label sr-only">
        Search
      </label>
      <div
        class="QueryBuilder-StyledInput width-fit "
        data-target="query-builder.styledInput"
      >
          <span id="query-builder-test-leadingvisual-wrap" class="FormControl-input-leadingVisualWrap QueryBuilder-leadingVisualWrap">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search FormControl-input-leadingVisual">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
          </span>
        <div data-target="query-builder.styledInputContainer" class="QueryBuilder-StyledInputContainer">
          <div
            aria-hidden="true"
            class="QueryBuilder-StyledInputContent"
            data-target="query-builder.styledInputContent"
          ></div>
          <div class="QueryBuilder-InputWrapper">
            <div aria-hidden="true" class="QueryBuilder-Sizer" data-target="query-builder.sizer"></div>
            <input id="query-builder-test" name="query-builder-test" value="" autocomplete="off" type="text" role="combobox" spellcheck="false" aria-expanded="false" aria-describedby="validation-6517329d-761e-49a7-87bf-b0d76a18faa1" data-target="query-builder.input" data-action="
          input:query-builder#inputChange
          blur:query-builder#inputBlur
          keydown:query-builder#inputKeydown
          focus:query-builder#inputFocus
        " data-view-component="true" class="FormControl-input QueryBuilder-Input FormControl-medium" />
          </div>
        </div>
          <span class="sr-only" id="query-builder-test-clear">Clear</span>
          
  <button role="button" id="query-builder-test-clear-button" aria-labelledby="query-builder-test-clear query-builder-test-label" data-target="query-builder.clearButton" data-action="
                click:query-builder#clear
                focus:query-builder#clearButtonFocus
                blur:query-builder#clearButtonBlur
              " variant="small" hidden="hidden" type="button" data-view-component="true" class="Button Button--iconOnly Button--invisible Button--medium mr-1 px-2 py-0 d-flex flex-items-center rounded-1 color-fg-muted">    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x-circle-fill Button-visual">
    <path d="M2.343 13.657A8 8 0 1 1 13.658 2.343 8 8 0 0 1 2.343 13.657ZM6.03 4.97a.751.751 0 0 0-1.042.018.751.751 0 0 0-.018 1.042L6.94 8 4.97 9.97a.749.749 0 0 0 .326 1.275.749.749 0 0 0 .734-.215L8 9.06l1.97 1.97a.749.749 0 0 0 1.275-.326.749.749 0 0 0-.215-.734L9.06 8l1.97-1.97a.749.749 0 0 0-.326-1.275.749.749 0 0 0-.734.215L8 6.94Z"></path>
</svg>
</button>  

      </div>
      <template id="search-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
</template>

<template id="code-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</template>

<template id="file-code-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file-code">
    <path d="M4 1.75C4 .784 4.784 0 5.75 0h5.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v8.586A1.75 1.75 0 0 1 14.25 15h-9a.75.75 0 0 1 0-1.5h9a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 10 4.25V1.5H5.75a.25.25 0 0 0-.25.25v2.5a.75.75 0 0 1-1.5 0Zm1.72 4.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734l1.47-1.47-1.47-1.47a.75.75 0 0 1 0-1.06ZM3.28 7.78 1.81 9.25l1.47 1.47a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Zm8.22-6.218V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"></path>
</svg>
</template>

<template id="history-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-history">
    <path d="m.427 1.927 1.215 1.215a8.002 8.002 0 1 1-1.6 5.685.75.75 0 1 1 1.493-.154 6.5 6.5 0 1 0 1.18-4.458l1.358 1.358A.25.25 0 0 1 3.896 6H.25A.25.25 0 0 1 0 5.75V2.104a.25.25 0 0 1 .427-.177ZM7.75 4a.75.75 0 0 1 .75.75v2.992l2.028.812a.75.75 0 0 1-.557 1.392l-2.5-1A.751.751 0 0 1 7 8.25v-3.5A.75.75 0 0 1 7.75 4Z"></path>
</svg>
</template>

<template id="repo-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo">
    <path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8ZM5 12.25a.25.25 0 0 1 .25-.25h3.5a.25.25 0 0 1 .25.25v3.25a.25.25 0 0 1-.4.2l-1.45-1.087a.249.249 0 0 0-.3 0L5.4 15.7a.25.25 0 0 1-.4-.2Z"></path>
</svg>
</template>

<template id="bookmark-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bookmark">
    <path d="M3 2.75C3 1.784 3.784 1 4.75 1h6.5c.966 0 1.75.784 1.75 1.75v11.5a.75.75 0 0 1-1.227.579L8 11.722l-3.773 3.107A.751.751 0 0 1 3 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v9.91l3.023-2.489a.75.75 0 0 1 .954 0l3.023 2.49V2.75a.25.25 0 0 0-.25-.25Z"></path>
</svg>
</template>

<template id="plus-circle-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-plus-circle">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm7.25-3.25v2.5h2.5a.75.75 0 0 1 0 1.5h-2.5v2.5a.75.75 0 0 1-1.5 0v-2.5h-2.5a.75.75 0 0 1 0-1.5h2.5v-2.5a.75.75 0 0 1 1.5 0Z"></path>
</svg>
</template>

<template id="circle-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-dot-fill">
    <path d="M8 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z"></path>
</svg>
</template>

<template id="trash-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-trash">
    <path d="M11 1.75V3h2.25a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1 0-1.5H5V1.75C5 .784 5.784 0 6.75 0h2.5C10.216 0 11 .784 11 1.75ZM4.496 6.675l.66 6.6a.25.25 0 0 0 .249.225h5.19a.25.25 0 0 0 .249-.225l.66-6.6a.75.75 0 0 1 1.492.149l-.66 6.6A1.748 1.748 0 0 1 10.595 15h-5.19a1.75 1.75 0 0 1-1.741-1.575l-.66-6.6a.75.75 0 1 1 1.492-.15ZM6.5 1.75V3h3V1.75a.25.25 0 0 0-.25-.25h-2.5a.25.25 0 0 0-.25.25Z"></path>
</svg>
</template>

<template id="team-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-people">
    <path d="M2 5.5a3.5 3.5 0 1 1 5.898 2.549 5.508 5.508 0 0 1 3.034 4.084.75.75 0 1 1-1.482.235 4 4 0 0 0-7.9 0 .75.75 0 0 1-1.482-.236A5.507 5.507 0 0 1 3.102 8.05 3.493 3.493 0 0 1 2 5.5ZM11 4a3.001 3.001 0 0 1 2.22 5.018 5.01 5.01 0 0 1 2.56 3.012.749.749 0 0 1-.885.954.752.752 0 0 1-.549-.514 3.507 3.507 0 0 0-2.522-2.372.75.75 0 0 1-.574-.73v-.352a.75.75 0 0 1 .416-.672A1.5 1.5 0 0 0 11 5.5.75.75 0 0 1 11 4Zm-5.5-.5a2 2 0 1 0-.001 3.999A2 2 0 0 0 5.5 3.5Z"></path>
</svg>
</template>

<template id="project-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project">
    <path d="M1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0ZM1.5 1.75v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25ZM11.75 3a.75.75 0 0 1 .75.75v7.5a.75.75 0 0 1-1.5 0v-7.5a.75.75 0 0 1 .75-.75Zm-8.25.75a.75.75 0 0 1 1.5 0v5.5a.75.75 0 0 1-1.5 0ZM8 3a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 8 3Z"></path>
</svg>
</template>

<template id="pencil-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-pencil">
    <path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61Zm.176 4.823L9.75 4.81l-6.286 6.287a.253.253 0 0 0-.064.108l-.558 1.953 1.953-.558a.253.253 0 0 0 .108-.064Zm1.238-3.763a.25.25 0 0 0-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 0 0 0-.354Z"></path>
</svg>
</template>

        <div class="position-relative">
                <ul
                  role="listbox"
                  class="ActionListWrap QueryBuilder-ListWrap"
                  aria-label="Suggestions"
                  data-action="
                    combobox-commit:query-builder#comboboxCommit
                    mousedown:query-builder#resultsMousedown
                  "
                  data-target="query-builder.resultsList"
                  data-persist-list=false
                  id="query-builder-test-results"
                ></ul>
        </div>
      <div class="FormControl-inlineValidation" id="validation-6517329d-761e-49a7-87bf-b0d76a18faa1" hidden="hidden">
        <span class="FormControl-inlineValidation--visual">
          <svg aria-hidden="true" height="12" viewBox="0 0 12 12" version="1.1" width="12" data-view-component="true" class="octicon octicon-alert-fill">
    <path d="M4.855.708c.5-.896 1.79-.896 2.29 0l4.675 8.351a1.312 1.312 0 0 1-1.146 1.954H1.33A1.313 1.313 0 0 1 .183 9.058ZM7 7V3H5v4Zm-1 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"></path>
</svg>
        </span>
        <span></span>
</div>    </div>
    <div data-target="query-builder.screenReaderFeedback" aria-live="polite" aria-atomic="true" class="sr-only"></div>
</query-builder></form>
          <div class="d-flex flex-row color-fg-muted px-3 text-small color-bg-default search-feedback-prompt">
            <a target="_blank" href="https://docs.github.com/en/search-github/github-code-search/understanding-github-code-search-syntax" data-view-component="true" class="Link color-fg-accent text-normal ml-2">
              Search syntax tips
</a>            <div class="d-flex flex-1"></div>
          </div>
        </div>
</div>

    </div>
</modal-dialog></div>
  </div>
  <div data-action="click:qbsearch-input#retract" class="dark-backdrop position-fixed" hidden data-target="qbsearch-input.darkBackdrop"></div>
  <div class="color-fg-default">
    
<div class="Overlay--hidden Overlay-backdrop--center" data-modal-dialog-overlay>
  <modal-dialog data-target="qbsearch-input.feedbackDialog" data-action="close:qbsearch-input#handleDialogClose cancel:qbsearch-input#handleDialogClose" role="dialog" id="feedback-dialog" aria-modal="true" aria-disabled="true" aria-labelledby="feedback-dialog-title" aria-describedby="feedback-dialog-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-medium Overlay--motion-scaleFade">
    <div data-view-component="true" class="Overlay-header">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title " id="feedback-dialog-title">
        Provide feedback
      </h1>
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="feedback-dialog" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
</div>
      <div data-view-component="true" class="Overlay-body">        <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="code-search-feedback-form" data-turbo="false" action="/search/feedback" accept-charset="UTF-8" method="post"><input type="hidden" data-csrf="true" name="authenticity_token" value="USgxxRmEFoHjfTxRcQOjj9GOQ2EMutHo/XWfRmiMgqS5p6gkUTMwW6h3C+EtYJ+tG6wzUVQlygAS9w7OYezcFg==" />
          <p>We read every piece of feedback, and take your input very seriously.</p>
          <textarea name="feedback" class="form-control width-full mb-2" style="height: 120px" id="feedback"></textarea>
          <input name="include_email" id="include_email" aria-label="Include my email address so I can be contacted" class="form-control mr-2" type="checkbox">
          <label for="include_email" style="font-weight: normal">Include my email address so I can be contacted</label>
</form></div>
      <div data-view-component="true" class="Overlay-footer Overlay-footer--alignEnd">          <button data-close-dialog-id="feedback-dialog" type="button" data-view-component="true" class="btn">    Cancel
</button>
          <button form="code-search-feedback-form" data-action="click:qbsearch-input#submitFeedback" type="submit" data-view-component="true" class="btn-primary btn">    Submit feedback
</button>
</div>
</modal-dialog></div>

    <custom-scopes data-target="qbsearch-input.customScopesManager">
    
<div class="Overlay--hidden Overlay-backdrop--center" data-modal-dialog-overlay>
  <modal-dialog data-target="custom-scopes.customScopesModalDialog" data-action="close:qbsearch-input#handleDialogClose cancel:qbsearch-input#handleDialogClose" role="dialog" id="custom-scopes-dialog" aria-modal="true" aria-disabled="true" aria-labelledby="custom-scopes-dialog-title" aria-describedby="custom-scopes-dialog-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-medium Overlay--motion-scaleFade">
    <div data-view-component="true" class="Overlay-header Overlay-header--divided">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title " id="custom-scopes-dialog-title">
        Saved searches
      </h1>
        <h2 id="custom-scopes-dialog-description" class="Overlay-description">Use saved searches to filter your results more quickly</h2>
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="custom-scopes-dialog" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
</div>
      <div data-view-component="true" class="Overlay-body">        <div data-target="custom-scopes.customScopesModalDialogFlash"></div>

        <div hidden class="create-custom-scope-form" data-target="custom-scopes.createCustomScopeForm">
        <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="custom-scopes-dialog-form" data-turbo="false" action="/search/custom_scopes" accept-charset="UTF-8" method="post"><input type="hidden" data-csrf="true" name="authenticity_token" value="IkbZRLhwDqxSSS1JrZrco0Ls40gw4d46zh9xF1tcnLdL/UqfW4OmXmtrvZiB0KTZ81ouOQ6JP16vLvbU21Ij1g==" />
          <div data-target="custom-scopes.customScopesModalDialogFlash"></div>

          <input type="hidden" id="custom_scope_id" name="custom_scope_id" data-target="custom-scopes.customScopesIdField">

          <div class="form-group">
            <label for="custom_scope_name">Name</label>
            <auto-check src="/search/custom_scopes/check_name" required>
              <input
                type="text"
                name="custom_scope_name"
                id="custom_scope_name"
                data-target="custom-scopes.customScopesNameField"
                class="form-control"
                autocomplete="off"
                placeholder="github-ruby"
                required
                maxlength="50">
              <input type="hidden" data-csrf="true" value="bCVaLWs1WF4yWO8Hai/JR/bs20X3v96iM72IHojEltZk/lAb/KDc2ip/v+QJJ76vXDQIDErN67ml/jt6xAwQmw==" />
            </auto-check>
          </div>

          <div class="form-group">
            <label for="custom_scope_query">Query</label>
            <input
              type="text"
              name="custom_scope_query"
              id="custom_scope_query"
              data-target="custom-scopes.customScopesQueryField"
              class="form-control"
              autocomplete="off"
              placeholder="(repo:mona/a OR repo:mona/b) AND lang:python"
              required
              maxlength="500">
          </div>

          <p class="text-small color-fg-muted">
            To see all available qualifiers, see our <a class="Link--inTextBlock" href="https://docs.github.com/en/search-github/github-code-search/understanding-github-code-search-syntax">documentation</a>.
          </p>
</form>        </div>

        <div data-target="custom-scopes.manageCustomScopesForm">
          <div data-target="custom-scopes.list"></div>
        </div>

</div>
      <div data-view-component="true" class="Overlay-footer Overlay-footer--alignEnd Overlay-footer--divided">          <button data-action="click:custom-scopes#customScopesCancel" type="button" data-view-component="true" class="btn">    Cancel
</button>
          <button form="custom-scopes-dialog-form" data-action="click:custom-scopes#customScopesSubmit" data-target="custom-scopes.customScopesSubmitButton" type="submit" data-view-component="true" class="btn-primary btn">    Create saved search
</button>
</div>
</modal-dialog></div>
    </custom-scopes>
  </div>
</qbsearch-input><input type="hidden" data-csrf="true" class="js-data-jump-to-suggestions-path-csrf" value="916WJ3Om+ayrxekGbYECMAEclYTYkcJX3v74KMZ8WlK6Gi1TTiSezzxtZZ9GFEQiLPYEyHT09pNdgjen1JovXA==" />


          <div class="position-relative mr-lg-3 d-lg-inline-block">
            <a href="/login?return_to=https%3A%2F%2Fgithub.com%2Fhvianna%2FaudioMotion-analyzer%2Fblob%2Fmaster%2Fsrc%2FaudioMotion-analyzer.js"
              class="HeaderMenu-link HeaderMenu-link--sign-in flex-shrink-0 no-underline d-block d-lg-inline-block border border-lg-0 rounded rounded-lg-0 p-2 p-lg-0"
              data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="b66fa2452390332f8b0371fbc1dbd385d6aed9d0b312871d9569d36842ac4c4f"
              data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">
              Sign in
            </a>
          </div>

            <a href="/signup?ref_cta=Sign+up&amp;ref_loc=header+logged+out&amp;ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E%2Fblob%2Fshow&amp;source=header-repo&amp;source_repo=hvianna%2FaudioMotion-analyzer"
              class="HeaderMenu-link HeaderMenu-link--sign-up flex-shrink-0 d-none d-lg-inline-block no-underline border color-border-default rounded px-2 py-1"
              data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="b66fa2452390332f8b0371fbc1dbd385d6aed9d0b312871d9569d36842ac4c4f"
              data-analytics-event="{&quot;category&quot;:&quot;Sign up&quot;,&quot;action&quot;:&quot;click to sign up for account&quot;,&quot;label&quot;:&quot;ref_page:/&lt;user-name&gt;/&lt;repo-name&gt;/blob/show;ref_cta:Sign up;ref_loc:header logged out&quot;}"
            >
              Sign up
            </a>
        </div>
      </div>
    </div>
  </div>
</header>

      <div hidden="hidden" data-view-component="true" class="js-stale-session-flash flash flash-warn mb-3">
  
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>
        <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>
        <span class="js-stale-session-flash-switched" hidden>You switched accounts on another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>

    <div data-view-component="true" class="flash-close">
  <button id="icon-button-1015ee7e-4f15-4a5b-9c49-97372c788f6c" type="button" data-view-component="true" class="Button Button--iconOnly Button--invisible Button--medium js-flash-close">    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x Button-visual">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</button>  <tool-tip id="tooltip-2b151f9f-6ed3-440e-82eb-abb9ac62b7c4" for="icon-button-1015ee7e-4f15-4a5b-9c49-97372c788f6c" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Dismiss alert</tool-tip>
</div>

  
</div>
    </div>

  <div id="start-of-content" class="show-on-focus"></div>








    <div id="js-flash-container" data-turbo-replace>





  <template class="js-flash-template">
    
<div class="flash flash-full   {{ className }}">
  <div class="px-2" >
    <button autofocus class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
    </button>
    <div aria-atomic="true" role="alert" class="js-flash-alert">
      
      <div>{{ message }}</div>

    </div>
  </div>
</div>
  </template>
</div>


    
    <include-fragment class="js-notification-shelf-include-fragment" data-base-src="https://github.com/notifications/beta/shelf"></include-fragment>






  <div
    class="application-main "
    data-commit-hovercards-enabled
    data-discussion-hovercards-enabled
    data-issue-and-pr-hovercards-enabled
  >
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" >
      
      
      






  
  <div id="repository-container-header"  class="pt-3 hide-full-screen" style="background-color: var(--color-page-header-bg);" data-turbo-replace>

      <div class="d-flex flex-wrap flex-justify-end mb-3  px-3 px-md-4 px-lg-5" style="gap: 1rem;">

        <div class="flex-auto min-width-0 width-fit mr-3">
            
  <div class=" d-flex flex-wrap flex-items-center wb-break-word f3 text-normal">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo color-fg-muted mr-2">
    <path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8ZM5 12.25a.25.25 0 0 1 .25-.25h3.5a.25.25 0 0 1 .25.25v3.25a.25.25 0 0 1-.4.2l-1.45-1.087a.249.249 0 0 0-.3 0L5.4 15.7a.25.25 0 0 1-.4-.2Z"></path>
</svg>
    
    <span class="author flex-self-stretch" itemprop="author">
      <a class="url fn" rel="author" data-hovercard-type="user" data-hovercard-url="/users/hvianna/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/hvianna">
        hvianna
</a>    </span>
    <span class="mx-1 flex-self-stretch color-fg-muted">/</span>
    <strong itemprop="name" class="mr-2 flex-self-stretch">
      <a data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/hvianna/audioMotion-analyzer">audioMotion-analyzer</a>
    </strong>

    <span></span><span class="Label Label--secondary v-align-middle mr-1">Public</span>
  </div>


        </div>

        <div id="repository-details-container" data-turbo-replace>
            <ul class="pagehead-actions flex-shrink-0 d-none d-md-inline" style="padding: 2px 0;">
    
        <li>
          <include-fragment src="/hvianna/audioMotion-analyzer/sponsor_button"></include-fragment>
        </li>

      

  <li>
            <a href="/login?return_to=%2Fhvianna%2FaudioMotion-analyzer" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;notification subscription menu watch&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="26d5d5418f9cbd17a5eaa769728bbda037e2dcfecf981cc7b6570c1a69c0bd44" aria-label="You must be signed in to change notification settings" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn">    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bell mr-2">
    <path d="M8 16a2 2 0 0 0 1.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 0 0 8 16ZM3 5a5 5 0 0 1 10 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.519 1.519 0 0 1 13.482 13H2.518a1.516 1.516 0 0 1-1.263-2.36l1.703-2.554A.255.255 0 0 0 3 7.947Zm5-3.5A3.5 3.5 0 0 0 4.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.017.017 0 0 0-.003.01l.001.006c0 .002.002.004.004.006l.006.004.007.001h10.964l.007-.001.006-.004.004-.006.001-.007a.017.017 0 0 0-.003-.01l-1.703-2.554a1.745 1.745 0 0 1-.294-.97V5A3.5 3.5 0 0 0 8 1.5Z"></path>
</svg>Notifications
</a>
  </li>

  <li>
          <a icon="repo-forked" id="fork-button" href="/login?return_to=%2Fhvianna%2FaudioMotion-analyzer" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;repo details fork button&quot;,&quot;repository_id&quot;:191051179,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="e47a01327a0bc4237f9c5a4f0c46b699bc9ec7acddc8396fc735eb0bd0445d52" data-view-component="true" class="btn-sm btn">    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-forked mr-2">
    <path d="M5 5.372v.878c0 .414.336.75.75.75h4.5a.75.75 0 0 0 .75-.75v-.878a2.25 2.25 0 1 1 1.5 0v.878a2.25 2.25 0 0 1-2.25 2.25h-1.5v2.128a2.251 2.251 0 1 1-1.5 0V8.5h-1.5A2.25 2.25 0 0 1 3.5 6.25v-.878a2.25 2.25 0 1 1 1.5 0ZM5 3.25a.75.75 0 1 0-1.5 0 .75.75 0 0 0 1.5 0Zm6.75.75a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm-3 8.75a.75.75 0 1 0-1.5 0 .75.75 0 0 0 1.5 0Z"></path>
</svg>Fork
    <span id="repo-network-counter" data-pjax-replace="true" data-turbo-replace="true" title="42" data-view-component="true" class="Counter">42</span>
</a>
  </li>

  <li>
        <div data-view-component="true" class="BtnGroup d-flex">
        <a href="/login?return_to=%2Fhvianna%2FaudioMotion-analyzer" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;star button&quot;,&quot;repository_id&quot;:191051179,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="70f4f062dc8067c5cf840e7e9580f454c5fb1f315d6a4a952045a7cab46b12d6" aria-label="You must be signed in to star a repository" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn BtnGroup-item">    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star v-align-text-bottom d-inline-block mr-2">
    <path d="M8 .25a.75.75 0 0 1 .673.418l1.882 3.815 4.21.612a.75.75 0 0 1 .416 1.279l-3.046 2.97.719 4.192a.751.751 0 0 1-1.088.791L8 12.347l-3.766 1.98a.75.75 0 0 1-1.088-.79l.72-4.194L.818 6.374a.75.75 0 0 1 .416-1.28l4.21-.611L7.327.668A.75.75 0 0 1 8 .25Zm0 2.445L6.615 5.5a.75.75 0 0 1-.564.41l-3.097.45 2.24 2.184a.75.75 0 0 1 .216.664l-.528 3.084 2.769-1.456a.75.75 0 0 1 .698 0l2.77 1.456-.53-3.084a.75.75 0 0 1 .216-.664l2.24-2.183-3.096-.45a.75.75 0 0 1-.564-.41L8 2.694Z"></path>
</svg><span data-view-component="true" class="d-inline">
          Star
</span>          <span id="repo-stars-counter-star" aria-label="312 users starred this repository" data-singular-suffix="user starred this repository" data-plural-suffix="users starred this repository" data-turbo-replace="true" title="312" data-view-component="true" class="Counter js-social-count">312</span>
</a>        <button aria-label="You must be signed in to add this repository to a list" type="button" disabled="disabled" data-view-component="true" class="btn-sm btn BtnGroup-item px-2">    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path>
</svg>
</button></div>
  </li>

</ul>

        </div>
      </div>

        <div id="responsive-meta-container" data-turbo-replace>
</div>


          <nav data-pjax="#js-repo-pjax-container" aria-label="Repository" data-view-component="true" class="js-repo-nav js-sidenav-container-pjax js-responsive-underlinenav overflow-hidden UnderlineNav px-3 px-md-4 px-lg-5">

  <ul data-view-component="true" class="UnderlineNav-body list-style-none">
      <li data-view-component="true" class="d-inline-flex">
  <a id="code-tab" href="/hvianna/audioMotion-analyzer" data-tab-item="i0code-tab" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments /hvianna/audioMotion-analyzer" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g c" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Code&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" aria-current="page" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item selected">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
        <span data-content="Code">Code</span>
          <span id="code-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="issues-tab" href="/hvianna/audioMotion-analyzer/issues" data-tab-item="i1issues-tab" data-selected-links="repo_issues repo_labels repo_milestones /hvianna/audioMotion-analyzer/issues" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g i" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Issues&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
        <span data-content="Issues">Issues</span>
          <span id="issues-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="10" data-view-component="true" class="Counter">10</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="pull-requests-tab" href="/hvianna/audioMotion-analyzer/pulls" data-tab-item="i2pull-requests-tab" data-selected-links="repo_pulls checks /hvianna/audioMotion-analyzer/pulls" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g p" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Pull requests&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
        <span data-content="Pull requests">Pull requests</span>
          <span id="pull-requests-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="discussions-tab" href="/hvianna/audioMotion-analyzer/discussions" data-tab-item="i3discussions-tab" data-selected-links="repo_discussions /hvianna/audioMotion-analyzer/discussions" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g g" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Discussions&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
        <span data-content="Discussions">Discussions</span>
          <span id="discussions-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="actions-tab" href="/hvianna/audioMotion-analyzer/actions" data-tab-item="i4actions-tab" data-selected-links="repo_actions /hvianna/audioMotion-analyzer/actions" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g a" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Actions&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"></path>
</svg>
        <span data-content="Actions">Actions</span>
          <span id="actions-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="projects-tab" href="/hvianna/audioMotion-analyzer/projects" data-tab-item="i5projects-tab" data-selected-links="repo_projects new_repo_project repo_project /hvianna/audioMotion-analyzer/projects" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g b" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Projects&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table UnderlineNav-octicon d-none d-sm-inline">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25ZM6.5 6.5v8h7.75a.25.25 0 0 0 .25-.25V6.5Zm8-1.5V1.75a.25.25 0 0 0-.25-.25H6.5V5Zm-13 1.5v7.75c0 .138.112.25.25.25H5v-8ZM5 5V1.5H1.75a.25.25 0 0 0-.25.25V5Z"></path>
</svg>
        <span data-content="Projects">Projects</span>
          <span id="projects-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="security-tab" href="/hvianna/audioMotion-analyzer/security" data-tab-item="i6security-tab" data-selected-links="security overview alerts policy token_scanning code_scanning /hvianna/audioMotion-analyzer/security" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g s" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Security&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield UnderlineNav-octicon d-none d-sm-inline">
    <path d="M7.467.133a1.748 1.748 0 0 1 1.066 0l5.25 1.68A1.75 1.75 0 0 1 15 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.697 1.697 0 0 1-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 0 1 1.217-1.667Zm.61 1.429a.25.25 0 0 0-.153 0l-5.25 1.68a.25.25 0 0 0-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.196.196 0 0 0 .154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.251.251 0 0 0-.174-.237l-5.25-1.68ZM8.75 4.75v3a.75.75 0 0 1-1.5 0v-3a.75.75 0 0 1 1.5 0ZM9 10.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        <span data-content="Security">Security</span>
          <include-fragment src="/hvianna/audioMotion-analyzer/security/overall-count" accept="text/fragment+html"></include-fragment>

    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="insights-tab" href="/hvianna/audioMotion-analyzer/pulse" data-tab-item="i7insights-tab" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /hvianna/audioMotion-analyzer/pulse" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Insights&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.5 1.75V13.5h13.75a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1-.75-.75V1.75a.75.75 0 0 1 1.5 0Zm14.28 2.53-5.25 5.25a.75.75 0 0 1-1.06 0L7 7.06 4.28 9.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.25-3.25a.75.75 0 0 1 1.06 0L10 7.94l4.72-4.72a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
        <span data-content="Insights">Insights</span>
          <span id="insights-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
</ul>
    <div style="visibility:hidden;" data-view-component="true" class="UnderlineNav-actions js-responsive-underlinenav-overflow position-absolute pr-3 pr-md-4 pr-lg-5 right-0">        <details data-view-component="true" class="details-overlay details-reset position-relative">
    <summary role="button" data-view-component="true">          <div class="UnderlineNav-item mr-0 border-0">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal">
    <path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path>
</svg>
            <span class="sr-only">More</span>
          </div>
</summary>
    <details-menu role="menu" data-view-component="true" class="dropdown-menu dropdown-menu-sw">
          <ul>
              <li data-menu-item="i0code-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item selected dropdown-item" aria-current="page" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments /hvianna/audioMotion-analyzer" href="/hvianna/audioMotion-analyzer">
                  Code
</a>              </li>
              <li data-menu-item="i1issues-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_issues repo_labels repo_milestones /hvianna/audioMotion-analyzer/issues" href="/hvianna/audioMotion-analyzer/issues">
                  Issues
</a>              </li>
              <li data-menu-item="i2pull-requests-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_pulls checks /hvianna/audioMotion-analyzer/pulls" href="/hvianna/audioMotion-analyzer/pulls">
                  Pull requests
</a>              </li>
              <li data-menu-item="i3discussions-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_discussions /hvianna/audioMotion-analyzer/discussions" href="/hvianna/audioMotion-analyzer/discussions">
                  Discussions
</a>              </li>
              <li data-menu-item="i4actions-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_actions /hvianna/audioMotion-analyzer/actions" href="/hvianna/audioMotion-analyzer/actions">
                  Actions
</a>              </li>
              <li data-menu-item="i5projects-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_projects new_repo_project repo_project /hvianna/audioMotion-analyzer/projects" href="/hvianna/audioMotion-analyzer/projects">
                  Projects
</a>              </li>
              <li data-menu-item="i6security-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="security overview alerts policy token_scanning code_scanning /hvianna/audioMotion-analyzer/security" href="/hvianna/audioMotion-analyzer/security">
                  Security
</a>              </li>
              <li data-menu-item="i7insights-tab" hidden>
                <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /hvianna/audioMotion-analyzer/pulse" href="/hvianna/audioMotion-analyzer/pulse">
                  Insights
</a>              </li>
          </ul>
</details-menu>
</details></div>
</nav>

  </div>

  



<turbo-frame id="repo-content-turbo-frame" target="_top" data-turbo-action="advance" class="">
    <div id="repo-content-pjax-container" class="repository-content " >
    


    
      
    





<react-app
  app-name="react-code-view"
  initial-path="/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js"
  style="min-height: calc(100vh - 62px)"
  data-ssr="false"
  data-lazy="false"
  data-alternate="false"
>
  
  <script type="application/json" data-target="react-app.embeddedData">{"payload":{"allShortcutsEnabled":false,"fileTree":{"src":{"items":[{"name":"audioMotion-analyzer.js","path":"src/audioMotion-analyzer.js","contentType":"file"},{"name":"index.d.ts","path":"src/index.d.ts","contentType":"file"}],"totalCount":2},"":{"items":[{"name":".github","path":".github","contentType":"directory"},{"name":".well-known","path":".well-known","contentType":"directory"},{"name":"demo","path":"demo","contentType":"directory"},{"name":"img","path":"img","contentType":"directory"},{"name":"src","path":"src","contentType":"directory"},{"name":"tools","path":"tools","contentType":"directory"},{"name":".editorconfig","path":".editorconfig","contentType":"file"},{"name":".gitignore","path":".gitignore","contentType":"file"},{"name":"CNAME","path":"CNAME","contentType":"file"},{"name":"CONTRIBUTING.md","path":"CONTRIBUTING.md","contentType":"file"},{"name":"Changelog.md","path":"Changelog.md","contentType":"file"},{"name":"LICENSE","path":"LICENSE","contentType":"file"},{"name":"README.md","path":"README.md","contentType":"file"},{"name":"_config.yml","path":"_config.yml","contentType":"file"},{"name":"cover.png","path":"cover.png","contentType":"file"},{"name":"coverpage.md","path":"coverpage.md","contentType":"file"},{"name":"favicon.ico","path":"favicon.ico","contentType":"file"},{"name":"index.html","path":"index.html","contentType":"file"},{"name":"package.json","path":"package.json","contentType":"file"}],"totalCount":19}},"fileTreeProcessingTime":9.103258,"foldersToFetch":[],"reducedMotionEnabled":null,"repo":{"id":191051179,"defaultBranch":"master","name":"audioMotion-analyzer","ownerLogin":"hvianna","currentUserCanPush":false,"isFork":false,"isEmpty":false,"createdAt":"2019-06-09T20:15:29.000Z","ownerAvatar":"https://avatars.githubusercontent.com/u/1033735?v=4","public":true,"private":false,"isOrgOwned":false},"symbolsExpanded":false,"treeExpanded":true,"refInfo":{"name":"master","listCacheKey":"v0:1694117946.0","canEdit":false,"refType":"branch","currentOid":"70a1b5c0dbe0b88827953e1d6fa064bfbac90a6b"},"path":"src/audioMotion-analyzer.js","currentUser":null,"blob":{"rawLines":["/**!"," * audioMotion-analyzer"," * High-resolution real-time graphic audio spectrum analyzer JS module"," *"," * @version 4.2.0"," * @author  Henrique Avila Vianna \u003chvianna@gmail.com\u003e \u003chttps://henriquevianna.com\u003e"," * @license AGPL-3.0-or-later"," */","","const VERSION = '4.2.0';","","// internal constants","const TAU     = 2 * Math.PI,","\t  HALF_PI = Math.PI / 2,","\t  C_1     = 8.17579892;  // frequency for C -1","","const CANVAS_BACKGROUND_COLOR  = '#000',","\t  CHANNEL_COMBINED         = 'dual-combined',","\t  CHANNEL_SINGLE           = 'single',","\t  CHANNEL_VERTICAL         = 'dual-vertical',","\t  COLOR_BAR_INDEX          = 'bar-index',","\t  COLOR_BAR_LEVEL          = 'bar-level',","\t  COLOR_GRADIENT           = 'gradient',","\t  DEBOUNCE_TIMEOUT         = 60,","\t  EVENT_CLICK              = 'click',","\t  EVENT_FULLSCREENCHANGE   = 'fullscreenchange',","\t  EVENT_RESIZE             = 'resize',"," \t  GRADIENT_DEFAULT_BGCOLOR = '#111',"," \t  FILTER_NONE              = '',"," \t  FILTER_A                 = 'A',"," \t  FILTER_B                 = 'B',"," \t  FILTER_C                 = 'C',"," \t  FILTER_D                 = 'D',"," \t  FILTER_468               = '468',","\t  FONT_FAMILY              = 'sans-serif',","\t  FPS_COLOR                = '#0f0',","\t  LEDS_UNLIT_COLOR         = '#7f7f7f22',","\t  REASON_CREATE            = 'create',","\t  REASON_FSCHANGE          = 'fschange',","\t  REASON_LORES             = 'lores',","\t  REASON_RESIZE            = EVENT_RESIZE,","\t  REASON_USER              = 'user',","\t  SCALEX_BACKGROUND_COLOR  = '#000c',","\t  SCALEX_LABEL_COLOR       = '#fff',","\t  SCALEX_HIGHLIGHT_COLOR   = '#4f4',","\t  SCALEY_LABEL_COLOR       = '#888',","\t  SCALEY_MIDLINE_COLOR     = '#555',","\t  SCALE_BARK               = 'bark',","\t  SCALE_LINEAR             = 'linear',","\t  SCALE_LOG                = 'log',","\t  SCALE_MEL                = 'mel';","","// built-in gradients","const PRISM = [ '#a35', '#c66', '#e94', '#ed0', '#9d5', '#4d8', '#2cb', '#0bc', '#09c', '#36b' ],","\t  GRADIENTS = [","\t  [ 'classic', {","\t\t\tcolorStops: [","\t\t\t\t'red',","\t\t\t\t{ color: 'yellow', level: .85, pos: .6 },","\t\t\t\t{ color: 'lime', level: .475 }","\t\t\t]","\t  }],","\t  [ 'prism', {","\t\t\tcolorStops: PRISM","\t  }],","\t  [ 'rainbow', {","\t\t\tdir: 'h',","\t\t\tcolorStops: [ '#817', ...PRISM, '#639' ]","\t  }],","\t  [ 'orangered', {","\t  \t\tbgColor: '#3e2f29',","\t  \t\tcolorStops: [ 'OrangeRed' ]","\t  }],","\t  [ 'steelblue', {","\t  \t\tbgColor: '#222c35',","\t  \t\tcolorStops: [ 'SteelBlue' ]","\t  }]","];","","// custom error messages","const ERR_AUDIO_CONTEXT_FAIL     = [ 'ERR_AUDIO_CONTEXT_FAIL', 'Could not create audio context. Web Audio API not supported?' ],","\t  ERR_INVALID_AUDIO_CONTEXT  = [ 'ERR_INVALID_AUDIO_CONTEXT', 'Provided audio context is not valid' ],","\t  ERR_UNKNOWN_GRADIENT       = [ 'ERR_UNKNOWN_GRADIENT', 'Unknown gradient' ],","\t  ERR_FREQUENCY_TOO_LOW      = [ 'ERR_FREQUENCY_TOO_LOW', 'Frequency values must be \u003e= 1' ],","\t  ERR_INVALID_MODE           = [ 'ERR_INVALID_MODE', 'Invalid mode' ],","\t  ERR_REFLEX_OUT_OF_RANGE    = [ 'ERR_REFLEX_OUT_OF_RANGE', 'Reflex ratio must be \u003e= 0 and \u003c 1' ],","\t  ERR_INVALID_AUDIO_SOURCE   = [ 'ERR_INVALID_AUDIO_SOURCE', 'Audio source must be an instance of HTMLMediaElement or AudioNode' ],","\t  ERR_GRADIENT_INVALID_NAME  = [ 'ERR_GRADIENT_INVALID_NAME', 'Gradient name must be a non-empty string' ],","\t  ERR_GRADIENT_NOT_AN_OBJECT = [ 'ERR_GRADIENT_NOT_AN_OBJECT', 'Gradient options must be an object' ],","\t  ERR_GRADIENT_MISSING_COLOR = [ 'ERR_GRADIENT_MISSING_COLOR', 'Gradient colorStops must be a non-empty array' ];","","class AudioMotionError extends Error {","\tconstructor( error, value ) {","\t\tconst [ code, message ] = error;","\t\tsuper( message + ( value !== undefined ? `: ${value}` : '' ) );","\t\tthis.name = 'AudioMotionError';","\t\tthis.code = code;","\t}","}","","// helper function - output deprecation warning message on console","const deprecate = ( name, alternative ) =\u003e console.warn( `${name} is deprecated. Use ${alternative} instead.` );","","// helper function - validate a given value with an array of strings (by default, all lowercase)","// returns the validated value, or the first element of `list` if `value` is not found in the array","const validateFromList = ( value, list, modifier = 'toLowerCase' ) =\u003e list[ Math.max( 0, list.indexOf( ( '' + value )[ modifier ]() ) ) ];","","// helper function - find the Y-coordinate of a point located between two other points, given its X-coordinate","const findY = ( x1, y1, x2, y2, x ) =\u003e y1 + ( y2 - y1 ) * ( x - x1 ) / ( x2 - x1 );","","// Polyfill for Array.findLastIndex()","if ( ! Array.prototype.findLastIndex ) {","\tArray.prototype.findLastIndex = function( callback ) {","\t\tlet index = this.length;","\t\twhile ( index-- \u003e 0 ) {","\t\t\tif ( callback( this[ index ] ) )","\t\t\t\treturn index;","\t\t}","\t\treturn -1;","\t}","}","","// AudioMotionAnalyzer class","","export default class AudioMotionAnalyzer {","","/**"," * CONSTRUCTOR"," *"," * @param {object} [container] DOM element where to insert the analyzer; if undefined, uses the document body"," * @param {object} [options]"," * @returns {object} AudioMotionAnalyzer object"," */","\tconstructor( container, options = {} ) {","","\t\tthis._ready = false;","","\t\t// Initialize internal objects","\t\tthis._aux = {};\t\t\t\t// auxiliary variables","\t\tthis._canvasGradients = []; // CanvasGradient objects for channels 0 and 1","\t\tthis._destroyed = false;","\t\tthis._energy = { val: 0, peak: 0, hold: 0 };","\t\tthis._flg = {};\t\t\t\t// flags","\t\tthis._fps = 0;","\t\tthis._gradients = {};       // registered gradients","\t\tthis._last = 0;\t\t\t\t// timestamp of last rendered frame","\t\tthis._outNodes = [];\t\t// output nodes","\t\tthis._ownContext = false;","\t\tthis._selectedGrads = [];   // names of the currently selected gradients for channels 0 and 1","\t\tthis._sources = [];\t\t\t// input nodes","","\t\t// Register built-in gradients","\t\tfor ( const [ name, options ] of GRADIENTS )","\t\t\tthis.registerGradient( name, options );","","\t\t// Set container","\t\tthis._container = container || document.body;","","\t\t// Make sure we have minimal width and height dimensions in case of an inline container","\t\tthis._defaultWidth  = this._container.clientWidth  || 640;","\t\tthis._defaultHeight = this._container.clientHeight || 270;","","\t\t// Use audio context provided by user, or create a new one","","\t\tlet audioCtx;","","\t\tif ( options.source \u0026\u0026 ( audioCtx = options.source.context ) ) {","\t\t\t// get audioContext from provided source audioNode","\t\t}","\t\telse if ( audioCtx = options.audioCtx ) {","\t\t\t// use audioContext provided by user","\t\t}","\t\telse {","\t\t\ttry {","\t\t\t\taudioCtx = new ( window.AudioContext || window.webkitAudioContext )();","\t\t\t\tthis._ownContext = true;","\t\t\t}","\t\t\tcatch( err ) {","\t\t\t\tthrow new AudioMotionError( ERR_AUDIO_CONTEXT_FAIL );","\t\t\t}","\t\t}","","\t\t// make sure audioContext is valid","\t\tif ( ! audioCtx.createGain )","\t\t\tthrow new AudioMotionError( ERR_INVALID_AUDIO_CONTEXT );","","\t\t/*","\t\t\tConnection routing:","\t\t\t===================","","\t\t\tfor dual channel layouts:                +---\u003e  analyzer[0]  ---+","\t\t    \t                                     |                      |","\t\t\t(source) ---\u003e  input  ---\u003e  splitter  ---+                      +---\u003e  merger  ---\u003e  output  ---\u003e (destination)","\t\t    \t                                     |                      |","\t\t        \t                                 +---\u003e  analyzer[1]  ---+","","\t\t\tfor single channel layout:","","\t\t\t(source) ---\u003e  input  -----------------------\u003e  analyzer[0]  ---------------------\u003e  output  ---\u003e (destination)","","\t\t*/","","\t\t// create the analyzer nodes, channel splitter and merger, and gain nodes for input/output connections","\t\tconst analyzer = this._analyzer = [ audioCtx.createAnalyser(), audioCtx.createAnalyser() ];","\t\tconst splitter = this._splitter = audioCtx.createChannelSplitter(2);"," \t\tconst merger   = this._merger   = audioCtx.createChannelMerger(2);"," \t\tthis._input    = audioCtx.createGain();"," \t\tthis._output   = audioCtx.createGain();",""," \t\t// connect audio source if provided in the options","\t\tif ( options.source )","\t\t\tthis.connectInput( options.source );",""," \t\t// connect splitter -\u003e analyzers"," \t\tfor ( const i of [0,1] )","\t\t\tsplitter.connect( analyzer[ i ], i );","","\t\t// connect merger -\u003e output","\t\tmerger.connect( this._output );","","\t\t// connect output -\u003e destination (speakers)","\t\tif ( options.connectSpeakers !== false )","\t\t\tthis.connectOutput();","","\t\t// create analyzer canvas","\t\tconst canvas = document.createElement('canvas');","\t\tcanvas.style = 'max-width: 100%;';","\t\tthis._ctx = canvas.getContext('2d');","","\t\t// create auxiliary canvases for the X-axis and radial scale labels","\t\tfor ( const ctx of [ '_scaleX', '_scaleR' ] )","\t\t\tthis[ ctx ] = document.createElement('canvas').getContext('2d');","","\t\t// set fullscreen element (defaults to canvas)","\t\tthis._fsEl = options.fsElement || canvas;","","\t\t// Update canvas size on container / window resize and fullscreen events","","\t\t// Fullscreen changes are handled quite differently across browsers:","\t\t// 1. Chromium browsers will trigger a `resize` event followed by a `fullscreenchange`","\t\t// 2. Firefox triggers the `fullscreenchange` first and then the `resize`","\t\t// 3. Chrome on Android (TV) won't trigger a `resize` event, only `fullscreenchange`","\t\t// 4. Safari won't trigger `fullscreenchange` events at all, and on iPadOS the `resize`","\t\t//    event is triggered **on the window** only (last tested on iPadOS 14)","","\t\t// helper function for resize events","\t\tconst onResize = () =\u003e {","\t\t\tif ( ! this._fsTimeout ) {","\t\t\t\t// delay the resize to prioritize a possible following `fullscreenchange` event","\t\t\t\tthis._fsTimeout = window.setTimeout( () =\u003e {","\t\t\t\t\tif ( ! this._fsChanging ) {","\t\t\t\t\t\tthis._setCanvas( REASON_RESIZE );","\t\t\t\t\t\tthis._fsTimeout = 0;","\t\t\t\t\t}","\t\t\t\t}, DEBOUNCE_TIMEOUT );","\t\t\t}","\t\t}","","\t\t// if browser supports ResizeObserver, listen for resize on the container","\t\tif ( window.ResizeObserver ) {","\t\t\tthis._observer = new ResizeObserver( onResize );","\t\t\tthis._observer.observe( this._container );","\t\t}","","\t\t// create an AbortController to remove event listeners on destroy()","\t\tthis._controller = new AbortController();","\t\tconst signal = this._controller.signal;","","\t\t// listen for resize events on the window - required for fullscreen on iPadOS","\t\twindow.addEventListener( EVENT_RESIZE, onResize, { signal } );","","\t\t// listen for fullscreenchange events on the canvas - not available on Safari","\t\tcanvas.addEventListener( EVENT_FULLSCREENCHANGE, () =\u003e {","\t\t\t// set flag to indicate a fullscreen change in progress","\t\t\tthis._fsChanging = true;","","\t\t\t// if there is a scheduled resize event, clear it","\t\t\tif ( this._fsTimeout )","\t\t\t\twindow.clearTimeout( this._fsTimeout );","","\t\t\t// update the canvas","\t\t\tthis._setCanvas( REASON_FSCHANGE );","","\t\t\t// delay clearing the flag to prevent any shortly following resize event","\t\t\tthis._fsTimeout = window.setTimeout( () =\u003e {","\t\t\t\tthis._fsChanging = false;","\t\t\t\tthis._fsTimeout = 0;","\t\t\t}, DEBOUNCE_TIMEOUT );","\t\t}, { signal } );","","\t\t// Resume audio context if in suspended state (browsers' autoplay policy)","\t\tconst unlockContext = () =\u003e {","\t\t\tif ( audioCtx.state == 'suspended' )","\t\t\t\taudioCtx.resume();","\t\t\twindow.removeEventListener( EVENT_CLICK, unlockContext );","\t\t}","\t\twindow.addEventListener( EVENT_CLICK, unlockContext );","","\t\t// reset FPS-related variables when window becomes visible (avoid FPS drop due to frames not rendered while hidden)","\t\tdocument.addEventListener( 'visibilitychange', () =\u003e {","\t\t\tif ( document.visibilityState != 'hidden' ) {","\t\t\t\tthis._frames = 0;","\t\t\t\tthis._time = performance.now();","\t\t\t}","\t\t}, { signal } );","","\t\t// Set configuration options and use defaults for any missing properties","\t\tthis._setProps( options, true );","","\t\t// add canvas to the container","\t\tif ( this.useCanvas )","\t\t\tthis._container.appendChild( canvas );","","\t\t// Finish canvas setup","\t\tthis._ready = true;","\t\tthis._setCanvas( REASON_CREATE );","\t}","","\t/**","\t * ==========================================================================","\t *","\t * PUBLIC PROPERTIES GETTERS AND SETTERS","\t *","\t * ==========================================================================","\t */","","\tget alphaBars() {","\t\treturn this._alphaBars;","\t}","\tset alphaBars( value ) {","\t\tthis._alphaBars = !! value;","\t\tthis._calcBars();","\t}","","\tget ansiBands() {","\t\treturn this._ansiBands;","\t}","\tset ansiBands( value ) {","\t\tthis._ansiBands = !! value;","\t\tthis._calcBars();","\t}","","\tget barSpace() {","\t\treturn this._barSpace;","\t}","\tset barSpace( value ) {","\t\tthis._barSpace = +value || 0;","\t\tthis._calcBars();","\t}","","\tget channelLayout() {","\t\treturn this._chLayout;","\t}","\tset channelLayout( value ) {","\t\tthis._chLayout = validateFromList( value, [ CHANNEL_SINGLE, CHANNEL_VERTICAL, CHANNEL_COMBINED ] );","","\t\t// update node connections","\t\tthis._input.disconnect();","\t\tthis._input.connect( this._chLayout != CHANNEL_SINGLE ? this._splitter : this._analyzer[0] );","\t\tthis._analyzer[0].disconnect();","\t\tif ( this._outNodes.length ) // connect analyzer only if the output is connected to other nodes","\t\t\tthis._analyzer[0].connect( this._chLayout != CHANNEL_SINGLE ? this._merger : this._output );","","\t\tthis._calcBars();","\t\tthis._makeGrad();","\t}","","\tget colorMode() {","\t\treturn this._colorMode;","\t}","\tset colorMode( value ) {","\t\tthis._colorMode = validateFromList( value, [ COLOR_GRADIENT, COLOR_BAR_INDEX, COLOR_BAR_LEVEL ] );","\t}","","\tget fftSize() {","\t\treturn this._analyzer[0].fftSize;","\t}","\tset fftSize( value ) {","\t\tfor ( const i of [0,1] )","\t\t\tthis._analyzer[ i ].fftSize = value;","\t\tconst binCount = this._analyzer[0].frequencyBinCount;","\t\tthis._fftData = [ new Float32Array( binCount ), new Float32Array( binCount ) ];","\t\tthis._calcBars();","\t}","","\tget frequencyScale() {","\t\treturn this._frequencyScale;","\t}","\tset frequencyScale( value ) {","\t\tthis._frequencyScale = validateFromList( value, [ SCALE_LOG, SCALE_BARK, SCALE_MEL, SCALE_LINEAR ] );","\t\tthis._calcBars();","\t}","","\tget gradient() {","\t\treturn this._selectedGrads[0];","\t}","\tset gradient( value ) {","\t\tthis._setGradient( value );","\t}","","\tget gradientLeft() {","\t\treturn this._selectedGrads[0];","\t}","\tset gradientLeft( value ) {","\t\tthis._setGradient( value, 0 );","\t}","","\tget gradientRight() {","\t\treturn this._selectedGrads[1];","\t}","\tset gradientRight( value ) {","\t\tthis._setGradient( value, 1 );","\t}","","\tget height() {","\t\treturn this._height;","\t}","\tset height( h ) {","\t\tthis._height = h;","\t\tthis._setCanvas( REASON_USER );","\t}","","\tget ledBars() {","\t\treturn this._showLeds;","\t}","\tset ledBars( value ) {","\t\tthis._showLeds = !! value;","\t\tthis._calcBars();","\t}","","\tget linearAmplitude() {","\t\treturn this._linearAmplitude;","\t}","\tset linearAmplitude( value ) {","\t\tthis._linearAmplitude = !! value;","\t}","","\tget linearBoost() {","\t\treturn this._linearBoost;","\t}","\tset linearBoost( value ) {","\t\tthis._linearBoost = value \u003e= 1 ? +value : 1;","\t}","","\tget lineWidth() {","\t\treturn this._lineWidth;","\t}","\tset lineWidth( value ) {","\t\tthis._lineWidth = +value || 0;","\t}","","\tget loRes() {","\t\treturn this._loRes;","\t}","\tset loRes( value ) {","\t\tthis._loRes = !! value;","\t\tthis._setCanvas( REASON_LORES );","\t}","","\tget lumiBars() {","\t\treturn this._lumiBars;","\t}","\tset lumiBars( value ) {","\t\tthis._lumiBars = !! value;","\t\tthis._calcBars();","\t\tthis._makeGrad();","\t}","","\tget maxDecibels() {","\t\treturn this._analyzer[0].maxDecibels;","\t}","\tset maxDecibels( value ) {","\t\tfor ( const i of [0,1] )","\t\t\tthis._analyzer[ i ].maxDecibels = value;","\t}","","\tget maxFPS() {","\t\treturn this._maxFPS;","\t}","\tset maxFPS( value ) {","\t\tthis._maxFPS = value \u003c 0 ? 0 : +value || 0;","\t}","","\tget maxFreq() {","\t\treturn this._maxFreq;","\t}","\tset maxFreq( value ) {","\t\tif ( value \u003c 1 )","\t\t\tthrow new AudioMotionError( ERR_FREQUENCY_TOO_LOW );","\t\telse {","\t\t\tthis._maxFreq = Math.min( value, this.audioCtx.sampleRate / 2 );","\t\t\tthis._calcBars();","\t\t}","\t}","","\tget minDecibels() {","\t\treturn this._analyzer[0].minDecibels;","\t}","\tset minDecibels( value ) {","\t\tfor ( const i of [0,1] )","\t\t\tthis._analyzer[ i ].minDecibels = value;","\t}","","\tget minFreq() {","\t\treturn this._minFreq;","\t}","\tset minFreq( value ) {","\t\tif ( value \u003c 1 )","\t\t\tthrow new AudioMotionError( ERR_FREQUENCY_TOO_LOW );","\t\telse {","\t\t\tthis._minFreq = +value;","\t\t\tthis._calcBars();","\t\t}","\t}","","\tget mirror() {","\t\treturn this._mirror;","\t}","\tset mirror( value ) {","\t\tthis._mirror = Math.sign( value ) | 0; // ensure only -1, 0 or 1","\t\tthis._calcBars();","\t\tthis._makeGrad();","\t}","","\tget mode() {","\t\treturn this._mode;","\t}","\tset mode( value ) {","\t\tconst mode = value | 0;","\t\tif ( mode \u003e= 0 \u0026\u0026 mode \u003c= 10 \u0026\u0026 mode != 9 ) {","\t\t\tthis._mode = mode;","\t\t\tthis._calcBars();","\t\t\tthis._makeGrad();","\t\t}","\t\telse","\t\t\tthrow new AudioMotionError( ERR_INVALID_MODE, value );","\t}","","\tget noteLabels() {","\t\treturn this._noteLabels;","\t}","\tset noteLabels( value ) {","\t\tthis._noteLabels = !! value;","\t\tthis._createScales();","\t}","","\tget outlineBars() {","\t\treturn this._outlineBars;","\t}","\tset outlineBars( value ) {","\t\tthis._outlineBars = !! value;","\t\tthis._calcBars();","\t}","","\tget peakLine() {","\t\treturn this._peakLine;","\t}","\tset peakLine( value ) {","\t\tthis._peakLine = !! value;","\t}","","\tget radial() {","\t\treturn this._radial;","\t}","\tset radial( value ) {","\t\tthis._radial = !! value;","\t\tthis._calcBars();","\t\tthis._makeGrad();","\t}","","\tget reflexRatio() {","\t\treturn this._reflexRatio;","\t}","\tset reflexRatio( value ) {","\t\tvalue = +value || 0;","\t\tif ( value \u003c 0 || value \u003e= 1 )","\t\t\tthrow new AudioMotionError( ERR_REFLEX_OUT_OF_RANGE );","\t\telse {","\t\t\tthis._reflexRatio = value;","\t\t\tthis._calcBars();","\t\t\tthis._makeGrad();","\t\t}","\t}","","\tget roundBars() {","\t\treturn this._roundBars;","\t}","\tset roundBars( value ) {","\t\tthis._roundBars = !! value;","\t\tthis._calcBars();","\t}","","\tget smoothing() {","\t\treturn this._analyzer[0].smoothingTimeConstant;","\t}","\tset smoothing( value ) {","\t\tfor ( const i of [0,1] )","\t\t\tthis._analyzer[ i ].smoothingTimeConstant = value;","\t}","","\tget spinSpeed() {","\t\treturn this._spinSpeed;","\t}","\tset spinSpeed( value ) {","\t\tvalue = +value || 0;","\t\tif ( this._spinSpeed === undefined || value == 0 )","\t\t\tthis._spinAngle = -HALF_PI; // initialize or reset the rotation angle","\t\tthis._spinSpeed = value;","\t}","","\tget splitGradient() {","\t\treturn this._splitGradient;","\t}","\tset splitGradient( value ) {","\t\tthis._splitGradient = !! value;","\t\tthis._makeGrad();","\t}","","\tget stereo() {","\t\tdeprecate( 'stereo', 'channelLayout' );","\t\treturn this._chLayout != CHANNEL_SINGLE;","\t}","\tset stereo( value ) {","\t\tdeprecate( 'stereo', 'channelLayout' );","\t\tthis.channelLayout = value ? CHANNEL_VERTICAL : CHANNEL_SINGLE;","\t}","","\tget trueLeds() {","\t\treturn this._trueLeds;","\t}","\tset trueLeds( value ) {","\t\tthis._trueLeds = !! value;","\t}","","\tget volume() {","\t\treturn this._output.gain.value;","\t}","\tset volume( value ) {","\t\tthis._output.gain.value = value;","\t}","","\tget weightingFilter() {","\t\treturn this._weightingFilter;","\t}","\tset weightingFilter( value ) {","\t\tthis._weightingFilter = validateFromList( value, [ FILTER_NONE, FILTER_A, FILTER_B, FILTER_C, FILTER_D, FILTER_468 ], 'toUpperCase' );","\t}","","\tget width() {","\t\treturn this._width;","\t}","\tset width( w ) {","\t\tthis._width = w;","\t\tthis._setCanvas( REASON_USER );","\t}","","\t// Read only properties","","\tget audioCtx() {","\t\treturn this._input.context;","\t}","\tget canvas() {","\t\treturn this._ctx.canvas;","\t}","\tget canvasCtx() {","\t\treturn this._ctx;","\t}","\tget connectedSources() {","\t\treturn this._sources;","\t}","\tget connectedTo() {","\t\treturn this._outNodes;","\t}","\tget fps() {","\t\treturn this._fps;","\t}","\tget fsHeight() {","\t\treturn this._fsHeight;","\t}","\tget fsWidth() {","\t\treturn this._fsWidth;","\t}","\tget isAlphaBars() {","\t\treturn this._flg.isAlpha;","\t}","\tget isBandsMode() {","\t\treturn this._flg.isBands;","\t}","\tget isDestroyed() {","\t\treturn this._destroyed;","\t}","\tget isFullscreen() {","\t\treturn this._fsEl \u0026\u0026 ( document.fullscreenElement || document.webkitFullscreenElement ) === this._fsEl;","\t}","\tget isLedBars() {","\t\treturn this._flg.isLeds;","\t}","\tget isLumiBars() {","\t\treturn this._flg.isLumi;","\t}","\tget isOctaveBands() {","\t\treturn this._flg.isOctaves;","\t}","\tget isOn() {","\t\treturn !! this._runId;","\t}","\tget isOutlineBars() {","\t\treturn this._flg.isOutline;","\t}","\tget pixelRatio() {","\t\treturn this._pixelRatio;","\t}","\tget isRoundBars() {","\t\treturn this._flg.isRound;","\t}","\tstatic get version() {","\t\treturn VERSION;","\t}","","\t/**","\t * ==========================================================================","     *","\t * PUBLIC METHODS","\t *","\t * ==========================================================================","\t */","","\t/**","\t * Connects an HTML media element or audio node to the analyzer","\t *","\t * @param {object} an instance of HTMLMediaElement or AudioNode","\t * @returns {object} a MediaElementAudioSourceNode object if created from HTML element, or the same input object otherwise","\t */","\tconnectInput( source ) {","\t\tconst isHTML = source instanceof HTMLMediaElement;","","\t\tif ( ! ( isHTML || source.connect ) )","\t\t\tthrow new AudioMotionError( ERR_INVALID_AUDIO_SOURCE );","","\t\t// if source is an HTML element, create an audio node for it; otherwise, use the provided audio node","\t\tconst node = isHTML ? this.audioCtx.createMediaElementSource( source ) : source;","","\t\tif ( ! this._sources.includes( node ) ) {","\t\t\tnode.connect( this._input );","\t\t\tthis._sources.push( node );","\t\t}","","\t\treturn node;","\t}","","\t/**","\t * Connects the analyzer output to another audio node","\t *","\t * @param [{object}] an AudioNode; if undefined, the output is connected to the audio context destination (speakers)","\t */","\tconnectOutput( node = this.audioCtx.destination ) {","\t\tif ( this._outNodes.includes( node ) )","\t\t\treturn;","","\t\tthis._output.connect( node );","\t\tthis._outNodes.push( node );","","\t\t// when connecting the first node, also connect the analyzer nodes to the merger / output nodes","\t\tif ( this._outNodes.length == 1 ) {","\t\t\tfor ( const i of [0,1] )","\t\t\t\tthis._analyzer[ i ].connect( ( this._chLayout == CHANNEL_SINGLE \u0026\u0026 ! i ? this._output : this._merger ), 0, i );","\t\t}","\t}","","\t/**","\t * Destroys instance","\t */","\tdestroy() {","\t\tif ( ! this._ready )","\t\t\treturn;","","\t\tconst { audioCtx, canvas, _controller, _input, _merger, _observer, _ownContext, _splitter } = this;","","\t\tthis._destroyed = true;","\t\tthis._ready = false;","\t\tthis.stop();","","\t\t// remove event listeners","\t\t_controller.abort();","\t\tif ( _observer )","\t\t\t_observer.disconnect();","","\t\t// clear callbacks and fullscreen element","\t\tthis.onCanvasResize = null;","\t\tthis.onCanvasDraw = null;","\t\tthis._fsEl = null;","","\t\t// disconnect audio nodes","\t\tthis.disconnectInput();","\t\tthis.disconnectOutput(); // also disconnects analyzer nodes","\t\t_input.disconnect();","\t\t_splitter.disconnect();","\t\t_merger.disconnect();","","\t\t// if audio context is our own (not provided by the user), close it","\t\tif ( _ownContext )","\t\t\taudioCtx.close();","","\t\t// remove canvas from the DOM","\t\tcanvas.remove();","","\t\t// reset flags","\t\tthis._calcBars();","\t}","","\t/**","\t * Disconnects audio sources from the analyzer","\t *","\t * @param [{object|array}] a connected AudioNode object or an array of such objects; if falsy, all connected nodes are disconnected","\t * @param [{boolean}] if true, stops/releases audio tracks from disconnected media streams (e.g. microphone)","\t */","\tdisconnectInput( sources, stopTracks ) {","\t\tif ( ! sources )","\t\t\tsources = Array.from( this._sources );","\t\telse if ( ! Array.isArray( sources ) )","\t\t\tsources = [ sources ];","","\t\tfor ( const node of sources ) {","\t\t\tconst idx = this._sources.indexOf( node );","\t\t\tif ( stopTracks \u0026\u0026 node.mediaStream ) {","\t\t\t\tfor ( const track of node.mediaStream.getAudioTracks() ) {","\t\t\t\t\ttrack.stop();","\t\t\t\t}","\t\t\t}","\t\t\tif ( idx \u003e= 0 ) {","\t\t\t\tnode.disconnect( this._input );","\t\t\t\tthis._sources.splice( idx, 1 );","\t\t\t}","\t\t}","\t}","","\t/**","\t * Disconnects the analyzer output from other audio nodes","\t *","\t * @param [{object}] a connected AudioNode object; if undefined, all connected nodes are disconnected","\t */","\tdisconnectOutput( node ) {","\t\tif ( node \u0026\u0026 ! this._outNodes.includes( node ) )","\t\t\treturn;","","\t\tthis._output.disconnect( node );","\t\tthis._outNodes = node ? this._outNodes.filter( e =\u003e e !== node ) : [];","","\t\t// if disconnected from all nodes, also disconnect the analyzer nodes so they keep working on Chromium","\t\t// see https://github.com/hvianna/audioMotion-analyzer/issues/13#issuecomment-808764848","\t\tif ( this._outNodes.length == 0 ) {","\t\t\tfor ( const i of [0,1] )","\t\t\t\tthis._analyzer[ i ].disconnect();","\t\t}","\t}","","\t/**","\t * Returns analyzer bars data","     *","\t * @returns {array}","\t */","\tgetBars() {","\t\treturn Array.from( this._bars, ( { posX, freq, freqLo, freqHi, hold, peak, value } ) =\u003e ( { posX, freq, freqLo, freqHi, hold, peak, value } ) );","\t}","","\t/**","\t * Returns the energy of a frequency, or average energy of a range of frequencies","\t *","\t * @param [{number|string}] single or initial frequency (Hz), or preset name; if undefined, returns the overall energy","\t * @param [{number}] ending frequency (Hz)","\t * @returns {number|null} energy value (0 to 1) or null, if the specified preset is unknown","\t */","\tgetEnergy( startFreq, endFreq ) {","\t\tif ( startFreq === undefined )","\t\t\treturn this._energy.val;","","\t\t// if startFreq is a string, check for presets","\t\tif ( startFreq != +startFreq ) {","\t\t\tif ( startFreq == 'peak' )","\t\t\t\treturn this._energy.peak;","","\t\t\tconst presets = {","\t\t\t\tbass:    [ 20, 250 ],","\t\t\t\tlowMid:  [ 250, 500 ],","\t\t\t\tmid:     [ 500, 2e3 ],","\t\t\t\thighMid: [ 2e3, 4e3 ],","\t\t\t\ttreble:  [ 4e3, 16e3 ]","\t\t\t}","","\t\t\tif ( ! presets[ startFreq ] )","\t\t\t\treturn null;","","\t\t\t[ startFreq, endFreq ] = presets[ startFreq ];","\t\t}","","\t\tconst startBin = this._freqToBin( startFreq ),","\t\t      endBin   = endFreq ? this._freqToBin( endFreq ) : startBin,","\t\t      chnCount = this._chLayout == CHANNEL_SINGLE ? 1 : 2;","","\t\tlet energy = 0;","\t\tfor ( let channel = 0; channel \u003c chnCount; channel++ ) {","\t\t\tfor ( let i = startBin; i \u003c= endBin; i++ )","\t\t\t\tenergy += this._normalizedB( this._fftData[ channel ][ i ] );","\t\t}","","\t\treturn energy / ( endBin - startBin + 1 ) / chnCount;","\t}","","\t/**","\t * Registers a custom gradient","\t *","\t * @param {string} name","\t * @param {object} options","\t */","\tregisterGradient( name, options ) {","\t\tif ( typeof name != 'string' || name.trim().length == 0 )","\t\t\tthrow new AudioMotionError( ERR_GRADIENT_INVALID_NAME );","","\t\tif ( typeof options != 'object' )","\t\t\tthrow new AudioMotionError( ERR_GRADIENT_NOT_AN_OBJECT );","","\t\tconst { colorStops } = options;","","\t\tif ( ! Array.isArray( colorStops ) || ! colorStops.length )","\t\t\tthrow new AudioMotionError( ERR_GRADIENT_MISSING_COLOR );","","\t\tconst count     = colorStops.length,","\t\t\t  isInvalid = val =\u003e +val != val || val \u003c 0 || val \u003e 1;","","\t\t// normalize all colorStops as objects with `pos`, `color` and `level` properties","\t\tcolorStops.forEach( ( colorStop, index ) =\u003e {","\t\t\tconst pos = index / Math.max( 1, count - 1 );","\t\t\tif ( typeof colorStop != 'object' ) // only color string was defined","\t\t\t\tcolorStops[ index ] = {\tpos, color: colorStop };","\t\t\telse if ( isInvalid( colorStop.pos ) )","\t\t\t\tcolorStop.pos = pos;","","\t\t\tif ( isInvalid( colorStop.level ) )","\t\t\t\tcolorStops[ index ].level = 1 - index / count;","\t\t});","","\t\t// make sure colorStops is in descending `level` order and that the first one has `level == 1`","\t\t// this is crucial for proper operation of 'bar-level' colorMode!","\t\tcolorStops.sort( ( a, b ) =\u003e a.level \u003c b.level ? 1 : a.level \u003e b.level ? -1 : 0 );","\t\tcolorStops[0].level = 1;","","\t\tthis._gradients[ name ] = {","\t\t\tbgColor:    options.bgColor || GRADIENT_DEFAULT_BGCOLOR,","\t\t\tdir:        options.dir,","\t\t\tcolorStops: colorStops","\t\t};","","\t\t// if the registered gradient is one of the currently selected gradients, regenerate them","\t\tif ( this._selectedGrads.includes( name ) )","\t\t\tthis._makeGrad();","\t}","","\t/**","\t * Set dimensions of analyzer's canvas","\t *","\t * @param {number} w width in pixels","\t * @param {number} h height in pixels","\t */","\tsetCanvasSize( w, h ) {","\t\tthis._width = w;","\t\tthis._height = h;","\t\tthis._setCanvas( REASON_USER );","\t}","","\t/**","\t * Set desired frequency range","\t *","\t * @param {number} min lowest frequency represented in the x-axis","\t * @param {number} max highest frequency represented in the x-axis","\t */","\tsetFreqRange( min, max ) {","\t\tif ( min \u003c 1 || max \u003c 1 )","\t\t\tthrow new AudioMotionError( ERR_FREQUENCY_TOO_LOW );","\t\telse {","\t\t\tthis._minFreq = Math.min( min, max );","\t\t\tthis.maxFreq  = Math.max( min, max ); // use the setter for maxFreq","\t\t}","\t}","","\t/**","\t * Set custom parameters for LED effect","\t * If called with no arguments or if any property is invalid, clears any previous custom parameters","\t *","\t * @param {object} [params]","\t */","\tsetLedParams( params ) {","\t\tlet maxLeds, spaceV, spaceH;","","\t\t// coerce parameters to Number; `NaN` results are rejected in the condition below","\t\tif ( params ) {","\t\t\tmaxLeds = params.maxLeds | 0, // ensure integer","\t\t\tspaceV  = +params.spaceV,","\t\t\tspaceH  = +params.spaceH;","\t\t}","","\t\tthis._ledParams = maxLeds \u003e 0 \u0026\u0026 spaceV \u003e 0 \u0026\u0026 spaceH \u003e= 0 ? [ maxLeds, spaceV, spaceH ] : undefined;","\t\tthis._calcBars();","\t}","","\t/**","\t * Shorthand function for setting several options at once","\t *","\t * @param {object} options","\t */","\tsetOptions( options ) {","\t\tthis._setProps( options );","\t}","","\t/**","\t * Adjust the analyzer's sensitivity","\t *","\t * @param {number} min minimum decibels value","\t * @param {number} max maximum decibels value","\t */","\tsetSensitivity( min, max ) {","\t\tfor ( const i of [0,1] ) {","\t\t\tthis._analyzer[ i ].minDecibels = Math.min( min, max );","\t\t\tthis._analyzer[ i ].maxDecibels = Math.max( min, max );","\t\t}","\t}","","\t/**","\t * Start the analyzer","\t */","\tstart() {","\t\tthis.toggleAnalyzer( true );","\t}","","\t/**","\t * Stop the analyzer","\t */","\tstop() {","\t\tthis.toggleAnalyzer( false );","\t}","","\t/**","\t * Start / stop canvas animation","\t *","\t * @param {boolean} [force] if undefined, inverts the current state","\t * @returns {boolean} resulting state after the change","\t */","\ttoggleAnalyzer( force ) {","\t\tconst hasStarted = this.isOn;","","\t\tif ( force === undefined )","\t\t\tforce = ! hasStarted;","","\t\t// Stop the analyzer if it was already running and must be disabled","\t\tif ( hasStarted \u0026\u0026 ! force ) {","\t\t\tcancelAnimationFrame( this._runId );","\t\t\tthis._runId = 0;","\t\t}","\t\t// Start the analyzer if it was stopped and must be enabled","\t\telse if ( ! hasStarted \u0026\u0026 force \u0026\u0026 ! this._destroyed ) {","\t\t\tthis._frames = 0;","\t\t\tthis._time = performance.now();","\t\t\tthis._runId = requestAnimationFrame( timestamp =\u003e this._draw( timestamp ) ); // arrow function preserves the scope of *this*","\t\t}","","\t\treturn this.isOn;","\t}","","\t/**","\t * Toggles canvas full-screen mode","\t */","\ttoggleFullscreen() {","\t\tif ( this.isFullscreen ) {","\t\t\tif ( document.exitFullscreen )","\t\t\t\tdocument.exitFullscreen();","\t\t\telse if ( document.webkitExitFullscreen )","\t\t\t\tdocument.webkitExitFullscreen();","\t\t}","\t\telse {","\t\t\tconst fsEl = this._fsEl;","\t\t\tif ( ! fsEl )","\t\t\t\treturn;","\t\t\tif ( fsEl.requestFullscreen )","\t\t\t\tfsEl.requestFullscreen();","\t\t\telse if ( fsEl.webkitRequestFullscreen )","\t\t\t\tfsEl.webkitRequestFullscreen();","\t\t}","\t}","","\t/**","\t * ==========================================================================","\t *","\t * PRIVATE METHODS","\t *","\t * ==========================================================================","\t */","","\t/**","\t * Return the frequency (in Hz) for a given FFT bin","\t */","\t_binToFreq( bin ) {","\t\treturn bin * this.audioCtx.sampleRate / this.fftSize || 1; // returns 1 for bin 0","\t}","","\t/**","\t * Compute all internal data required for the analyzer, based on its current settings","\t */","\t_calcBars() {","\t\tconst bars = this._bars = []; // initialize object property","","\t\tif ( ! this._ready ) {","\t\t\tthis._flg = { isAlpha: false, isBands: false, isLeds: false, isLumi: false, isOctaves: false, isOutline: false, isRound: false, noLedGap: false };","\t\t\treturn;","\t\t}","","\t\tconst barSpace    = this._barSpace,","\t\t \t  canvas      = this.canvas,","\t\t\t  centerX     = canvas.width \u003e\u003e 1,","\t\t\t  chLayout    = this._chLayout,","\t\t\t  isAnsiBands = this._ansiBands,","\t\t\t  isRadial    = this._radial,","\t\t\t  isDual      = chLayout == CHANNEL_VERTICAL \u0026\u0026 ! isRadial,","\t\t\t  maxFreq     = this._maxFreq,","\t\t\t  minFreq     = this._minFreq,","\t\t\t  mode        = this._mode,","","\t\t\t  // COMPUTE FLAGS","","\t\t\t  isBands   = mode % 10 != 0,","\t\t\t  isOctaves = isBands \u0026\u0026 this._frequencyScale == SCALE_LOG,","\t\t\t  isLeds    = this._showLeds \u0026\u0026 isBands \u0026\u0026 ! isRadial,","\t\t\t  isLumi    = this._lumiBars \u0026\u0026 isBands \u0026\u0026 ! isRadial,","\t\t\t  isAlpha   = this._alphaBars \u0026\u0026 ! isLumi \u0026\u0026 mode != 10,","\t\t\t  isOutline = this._outlineBars \u0026\u0026 isBands \u0026\u0026 ! isLumi \u0026\u0026 ! isLeds,","\t\t\t  isRound   = this._roundBars \u0026\u0026 isBands \u0026\u0026 ! isLumi \u0026\u0026 ! isLeds,","\t\t\t  noLedGap  = chLayout != CHANNEL_VERTICAL || this._reflexRatio \u003e 0 \u0026\u0026 ! isLumi,","","\t\t\t  // COMPUTE AUXILIARY VALUES","","\t\t\t  // channelHeight is the total canvas height dedicated to each channel, including the reflex area, if any)","\t\t\t  channelHeight  = canvas.height - ( isDual \u0026\u0026 ! isLeds ? .5 : 0 ) \u003e\u003e isDual,","\t\t\t  // analyzerHeight is the effective height used to render the analyzer, excluding the reflex area","\t\t\t  analyzerHeight = channelHeight * ( isLumi || isRadial ? 1 : 1 - this._reflexRatio ) | 0,","","\t\t\t  analyzerWidth  = canvas.width - centerX * ( this._mirror != 0 ),","","\t\t\t  // channelGap is **0** if isLedDisplay == true (LEDs already have spacing); **1** if canvas height is odd (windowed); **2** if it's even","\t\t\t  // TODO: improve this, make it configurable?","\t\t\t  channelGap     = isDual ? canvas.height - channelHeight * 2 : 0,","","\t\t\t  initialX       = centerX * ( this._mirror == -1 \u0026\u0026 ! isRadial ),","\t\t\t  radius         = Math.min( canvas.width, canvas.height ) * ( chLayout == CHANNEL_VERTICAL ? .375 : .125 ) | 0;","","\t\t/**","\t\t *\tCREATE ANALYZER BANDS","\t\t *","\t\t *\tUSES:","\t\t *\t\tanalyzerWidth","\t\t *\t\tinitialX","\t\t *\t\tisBands","\t\t *\t\tisOctaves","\t\t *","\t\t *\tGENERATES:","\t\t *\t\tbars (populates this._bars)","\t\t *\t\tbardWidth","\t\t *\t\tscaleMin","\t\t *\t\tunitWidth","\t\t */","","\t\t// helper function","\t\t// bar object: { posX, freq, freqLo, freqHi, binLo, binHi, ratioLo, ratioHi, peak, hold, value }","\t\tconst barsPush = args =\u003e bars.push( { ...args, peak: [0,0], hold: [0], value: [0] } );","","\t\t/*","\t\t\tA simple interpolation is used to obtain an approximate amplitude value for any given frequency,","\t\t\tfrom the available FFT data. We find the FFT bin which closer matches the desired frequency\tand","\t\t\tinterpolate its value with that of the next adjacent bin, like so:","","\t\t\t\tv = v0 + ( v1 - v0 ) * ( log2( f / f0 ) / log2( f1 / f0 ) )","\t\t\t\t                       \\__________________________________/","\t\t\t\t                                        |","\t\t\t\t                                      ratio","\t\t\t\twhere:","","\t\t\t\tf  - desired frequency","\t\t\t\tv  - amplitude (volume) of desired frequency","\t\t\t\tf0 - frequency represented by the lower FFT bin","\t\t\t\tf1 - frequency represented by the upper FFT bin","\t\t\t\tv0 - amplitude of f0","\t\t\t\tv1 - amplitude of f1","","\t\t\tratio is calculated in advance here, to reduce computational complexity during real-time rendering.","\t\t*/","","\t\t// helper function to calculate FFT bin and interpolation ratio for a given frequency","\t\tconst calcRatio = freq =\u003e {","\t\t\tconst bin   = this._freqToBin( freq, 'floor' ), // find closest FFT bin","\t\t\t\t  lower = this._binToFreq( bin ),","\t\t\t\t  upper = this._binToFreq( bin + 1 ),","\t\t\t\t  ratio = Math.log2( freq / lower ) / Math.log2( upper / lower );","","\t\t\treturn [ bin, ratio ];","\t\t}","","\t\tlet barWidth, scaleMin, unitWidth;","","\t\tif ( isOctaves ) {","\t\t\t// helper function to round a value to a given number of significant digits","\t\t\t// `atLeast` set to true prevents reducing the number of integer significant digits","\t\t\tconst roundSD = ( value, digits, atLeast ) =\u003e +value.toPrecision( atLeast ? Math.max( digits, 1 + Math.log10( value ) | 0 ) : digits );","","\t\t\t// helper function to find the nearest preferred number (Renard series) for a given value","\t\t\tconst nearestPreferred = value =\u003e {","\t\t\t\t// R20 series is used here, as it provides closer approximations for 1/2 octave bands (non-standard)","\t\t\t\tconst preferred = [ 1, 1.12, 1.25, 1.4, 1.6, 1.8, 2, 2.24, 2.5, 2.8, 3.15, 3.55, 4, 4.5, 5, 5.6, 6.3, 7.1, 8, 9, 10 ],","\t\t\t\t\t  power = Math.log10( value ) | 0,","\t\t\t\t\t  normalized = value / 10 ** power;","","\t\t\t\tlet i = 1;","\t\t\t\twhile ( i \u003c preferred.length \u0026\u0026 normalized \u003e preferred[ i ] )","\t\t\t\t\ti++;","","\t\t\t\tif ( normalized - preferred[ i - 1 ] \u003c preferred[ i ] - normalized )","\t\t\t\t\ti--;","","\t\t\t\treturn ( preferred[ i ] * 10 ** ( power + 5 ) | 0 ) / 1e5; // keep 5 significant digits","\t\t\t}","","\t\t\t// ANSI standard octave bands use the base-10 frequency ratio, as preferred by [ANSI S1.11-2004, p.2]","\t\t\t// The equal-tempered scale uses the base-2 ratio","\t\t\tconst bands = [0,24,12,8,6,4,3,2,1][ this._mode ],","\t\t\t\t  bandWidth = isAnsiBands ? 10 ** ( 3 / ( bands * 10 ) ) : 2 ** ( 1 / bands ), // 10^(3/10N) or 2^(1/N)","\t\t\t\t  halfBand  = bandWidth ** .5;","","\t\t\tlet analyzerBars = [],","\t\t\t\tcurrFreq = isAnsiBands ? 7.94328235 / ( bands % 2 ? 1 : halfBand ) : C_1;","\t\t\t\t// For ANSI bands with even denominators (all except 1/1 and 1/3), the reference frequency (1 kHz)","\t\t\t\t// must fall on the edges of a pair of adjacent bands, instead of midband [ANSI S1.11-2004, p.2]","\t\t\t\t// In the equal-tempered scale, all midband frequencies represent a musical note or quarter-tone.","","\t\t\tdo {","\t\t\t\tlet freq = currFreq; // midband frequency","","\t\t\t\tconst freqLo = roundSD( freq / halfBand, 4, true ), // lower edge frequency","\t\t\t\t\t  freqHi = roundSD( freq * halfBand, 4, true ), // upper edge frequency","\t\t\t\t\t  [ binLo, ratioLo ] = calcRatio( freqLo ),","\t\t\t\t\t  [ binHi, ratioHi ] = calcRatio( freqHi );","","\t\t\t\t// for 1/1, 1/2 and 1/3 ANSI bands, use the preferred numbers to find the nominal midband frequency","\t\t\t\t// for 1/4 to 1/24, round to 2 or 3 significant digits, according to the MSD [ANSI S1.11-2004, p.12]","\t\t\t\tif ( isAnsiBands )","\t\t\t\t\tfreq = bands \u003c 4 ? nearestPreferred( freq ) : roundSD( freq, freq.toString()[0] \u003c 5 ? 3 : 2 );","\t\t\t\telse","\t\t\t\t\tfreq = roundSD( freq, 4, true );","","\t\t\t\tif ( freq \u003e= minFreq )","\t\t\t\t\tbarsPush( { posX: 0, freq, freqLo, freqHi, binLo, binHi, ratioLo, ratioHi } );","","\t\t\t\tcurrFreq *= bandWidth;","\t\t\t} while ( currFreq \u003c= maxFreq );","","\t\t\tbarWidth = analyzerWidth / bars.length;","","\t\t\tbars.forEach( ( bar, index ) =\u003e bar.posX = initialX + index * barWidth );","","\t\t\tconst firstBar = bars[0],","\t\t\t\t  lastBar  = bars[ bars.length - 1 ];","","\t\t\tscaleMin = this._freqScaling( firstBar.freqLo );","\t\t\tunitWidth = analyzerWidth / ( this._freqScaling( lastBar.freqHi ) - scaleMin );","","\t\t\t// clamp edge frequencies to minFreq / maxFreq, if necessary","\t\t\t// this is done after computing scaleMin and unitWidth, for the proper positioning of labels on the X-axis","\t\t\tif ( firstBar.freqLo \u003c minFreq ) {","\t\t\t\tfirstBar.freqLo = minFreq;","\t\t\t\t[ firstBar.binLo, firstBar.ratioLo ] = calcRatio( minFreq );","\t\t\t}","","\t\t\tif ( lastBar.freqHi \u003e maxFreq ) {","\t\t\t\tlastBar.freqHi = maxFreq;","\t\t\t\t[ lastBar.binHi, lastBar.ratioHi ] = calcRatio( maxFreq );","\t\t\t}","\t\t}","\t\telse if ( isBands ) { // a bands mode is selected, but frequency scale is not logarithmic","","\t\t\tconst bands = [0,24,12,8,6,4,3,2,1][ this._mode ] * 10;","","\t\t\tconst invFreqScaling = x =\u003e {","\t\t\t\tswitch ( this._frequencyScale ) {","\t\t\t\t\tcase SCALE_BARK :","\t\t\t\t\t\treturn 1960 / ( 26.81 / ( x + .53 ) - 1 );","\t\t\t\t\tcase SCALE_MEL :","\t\t\t\t\t\treturn 700 * ( 2 ** x - 1 );","\t\t\t\t\tcase SCALE_LINEAR :","\t\t\t\t\t\treturn x;","\t\t\t\t}","\t\t\t}","","\t\t\tbarWidth = analyzerWidth / bands;","","\t\t\tscaleMin = this._freqScaling( minFreq );","\t\t\tunitWidth = analyzerWidth / ( this._freqScaling( maxFreq ) - scaleMin );","","\t\t\tfor ( let i = 0, posX = 0; i \u003c bands; i++, posX += barWidth ) {","\t\t\t\tconst freqLo = invFreqScaling( scaleMin + posX / unitWidth ),","\t\t\t\t\t  freq   = invFreqScaling( scaleMin + ( posX + barWidth / 2 ) / unitWidth ),","\t\t\t\t\t  freqHi = invFreqScaling( scaleMin + ( posX + barWidth ) / unitWidth ),","\t\t\t\t\t  [ binLo, ratioLo ] = calcRatio( freqLo ),","\t\t\t\t\t  [ binHi, ratioHi ] = calcRatio( freqHi );","","\t\t\t\tbarsPush( { posX: initialX + posX, freq, freqLo, freqHi, binLo, binHi, ratioLo, ratioHi } );","\t\t\t}","","\t\t}","\t\telse {\t// Discrete frequencies modes","\t\t\tbarWidth = 1;","","\t\t\tscaleMin = this._freqScaling( minFreq );","\t\t\tunitWidth = analyzerWidth / ( this._freqScaling( maxFreq ) - scaleMin );","","\t\t\tconst minIndex = this._freqToBin( minFreq, 'floor' ),","\t\t\t\t  maxIndex = this._freqToBin( maxFreq );","","\t \t\tlet lastPos = -999;","","\t\t\tfor ( let i = minIndex; i \u003c= maxIndex; i++ ) {","\t\t\t\tconst freq = this._binToFreq( i ), // frequency represented by this index","\t\t\t\t\t  posX = initialX + Math.round( unitWidth * ( this._freqScaling( freq ) - scaleMin ) ); // avoid fractionary pixel values","","\t\t\t\t// if it's on a different X-coordinate, create a new bar for this frequency","\t\t\t\tif ( posX \u003e lastPos ) {","\t\t\t\t\tbarsPush( { posX, freq, freqLo: freq, freqHi: freq, binLo: i, binHi: i, ratioLo: 0, ratioHi: 0 } );","\t\t\t\t\tlastPos = posX;","\t\t\t\t} // otherwise, add this frequency to the last bar's range","\t\t\t\telse if ( bars.length ) {","\t\t\t\t\tconst lastBar = bars[ bars.length - 1 ];","\t\t\t\t\tlastBar.binHi = i;","\t\t\t\t\tlastBar.freqHi = freq;","\t\t\t\t\tlastBar.freq = ( lastBar.freqLo * freq ) ** .5; // compute center frequency (geometric mean)","\t\t\t\t}","\t\t\t}","\t\t}","","\t\t/**","\t\t *  COMPUTE ATTRIBUTES FOR THE LED BARS","\t\t *","\t\t *\tUSES:","\t\t *\t\tanalyzerHeight","\t\t *\t\tbarWidth","\t\t *\t\tnoLedGap","\t\t *","\t\t *\tGENERATES:","\t\t * \t\tspaceH","\t\t * \t\tspaceV","\t\t *\t\tthis._leds","\t\t */","","\t\tlet spaceH = 0,","\t\t\tspaceV = 0;","","\t\tif ( isLeds ) {","\t\t\t// adjustment for high pixel-ratio values on low-resolution screens (Android TV)","\t\t\tconst dPR = this._pixelRatio / ( window.devicePixelRatio \u003e 1 \u0026\u0026 window.screen.height \u003c= 540 ? 2 : 1 );","","\t\t\tconst params = [ [],","\t\t\t\t[ 128,  3, .45  ], // mode 1","\t\t\t\t[ 128,  4, .225 ], // mode 2","\t\t\t\t[  96,  6, .225 ], // mode 3","\t\t\t\t[  80,  6, .225 ], // mode 4","\t\t\t\t[  80,  6, .125 ], // mode 5","\t\t\t\t[  64,  6, .125 ], // mode 6","\t\t\t\t[  48,  8, .125 ], // mode 7","\t\t\t\t[  24, 16, .125 ], // mode 8","\t\t\t];","","\t\t\t// use custom LED parameters if set, or the default parameters for the current mode","\t\t\tconst customParams = this._ledParams,","\t\t\t\t  [ maxLeds, spaceVRatio, spaceHRatio ] = customParams || params[ mode ];","","\t\t\tlet ledCount, maxHeight = analyzerHeight;","","\t\t\tif ( customParams ) {","\t\t\t\tconst minHeight = 2 * dPR;","\t\t\t\tlet blockHeight;","\t\t\t\tledCount = maxLeds + 1;","\t\t\t\tdo {","\t\t\t\t\tledCount--;","\t\t\t\t\tblockHeight = maxHeight / ledCount / ( 1 + spaceVRatio );","\t\t\t\t\tspaceV = blockHeight * spaceVRatio;","\t\t\t\t} while ( ( blockHeight \u003c minHeight || spaceV \u003c minHeight ) \u0026\u0026 ledCount \u003e 1 );","\t\t\t}","\t\t\telse {","\t\t\t\t// calculate vertical spacing - aim for the reference ratio, but make sure it's at least 2px","\t\t\t\tconst refRatio = 540 / spaceVRatio;","\t\t\t\tspaceV = Math.min( spaceVRatio * dPR, Math.max( 2, maxHeight / refRatio + .1 | 0 ) );","\t\t\t}","","\t\t\t// remove the extra spacing below the last line of LEDs","\t\t\tif ( noLedGap )","\t\t\t\tmaxHeight += spaceV;","","\t\t\t// recalculate the number of leds, considering the effective spaceV","\t\t\tif ( ! customParams )","\t\t\t\tledCount = Math.min( maxLeds, maxHeight / ( spaceV * 2 ) | 0 );","","\t\t\tspaceH = spaceHRatio \u003e= 1 ? spaceHRatio : barWidth * spaceHRatio;","","\t\t\tthis._leds = [","\t\t\t\tledCount,","\t\t\t\tspaceH,","\t\t\t\tspaceV,","\t\t\t\tmaxHeight / ledCount - spaceV // ledHeight","\t\t\t];","\t\t}","","\t\t// COMPUTE ADDITIONAL BAR POSITIONING, ACCORDING TO THE CURRENT SETTINGS","\t\t// uses: barSpace, barWidth, spaceH","","\t\tconst barSpacePx = Math.min( barWidth - 1, barSpace * ( barSpace \u003e 0 \u0026\u0026 barSpace \u003c 1 ? barWidth : 1 ) );","","\t\tif ( isBands )","\t\t\tbarWidth -= Math.max( isLeds ? spaceH : 0, barSpacePx );","","\t\tbars.forEach( ( bar, index ) =\u003e {","\t\t\tlet posX  = bar.posX,","\t\t\t\twidth = barWidth;","","\t\t\t// in bands modes we need to update bar.posX to account for bar/led spacing","","\t\t\tif ( isBands ) {","\t\t\t\tif ( barSpace == 0 \u0026\u0026 ! isLeds ) {","\t\t\t\t\t// when barSpace == 0 use integer values for perfect gapless positioning","\t\t\t\t\tposX |= 0;","\t\t\t\t\twidth |= 0;","\t\t\t\t\tif ( index \u003e 0 \u0026\u0026 posX \u003e bars[ index - 1 ].posX + bars[ index - 1 ].width ) {","\t\t\t\t\t\tposX--;","\t\t\t\t\t\twidth++;","\t\t\t\t\t}","\t\t\t\t}","\t\t\t\telse","\t\t\t\t\tposX += Math.max( ( isLeds ? spaceH : 0 ), barSpacePx ) / 2;","","\t\t\t\tbar.posX = posX; // update","\t\t\t}","","\t\t\tbar.barCenter = posX + ( barWidth == 1 ? 0 : width / 2 );","\t\t\tbar.width = width;","\t\t});","","\t\t// COMPUTE CHANNEL COORDINATES (uses spaceV)","","\t\tconst channelCoords = [];","\t\tfor ( const channel of [0,1] ) {","\t\t\tconst channelTop     = chLayout == CHANNEL_VERTICAL ? ( channelHeight + channelGap ) * channel : 0,","\t\t\t\t  channelBottom  = channelTop + channelHeight,","\t\t\t\t  analyzerBottom = channelTop + analyzerHeight - ( ! isLeds || noLedGap ? 0 : spaceV );","","\t\t\tchannelCoords.push( { channelTop, channelBottom, analyzerBottom } );","\t\t}","","\t\t// SAVE INTERNAL PROPERTIES","","\t\tthis._aux = { analyzerHeight, analyzerWidth, channelCoords, channelHeight, channelGap, initialX, radius, scaleMin, unitWidth };","\t\tthis._flg = { isAlpha, isBands, isLeds, isLumi, isOctaves, isOutline, isRound, noLedGap };","","\t\t// generate the X-axis and radial scales","\t\tthis._createScales();","\t}","","\t/**","\t * Generate the X-axis and radial scales in auxiliary canvases","\t */","\t_createScales() {","\t\tif ( ! this._ready )","\t\t\treturn;","","\t\tconst { analyzerWidth, initialX, radius, scaleMin, unitWidth } = this._aux,","\t\t\t  { canvas, _frequencyScale, _mirror, _noteLabels, _radial, _scaleX, _scaleR } = this,","\t\t\t  canvasX       = _scaleX.canvas,","\t\t\t  canvasR       = _scaleR.canvas,","\t\t\t  freqLabels    = [],","\t\t\t  isVertical    = this._chLayout == CHANNEL_VERTICAL,","\t\t\t  scale         = [ 'C',, 'D',, 'E', 'F',, 'G',, 'A',, 'B' ], // for note labels (no sharp notes)","\t\t\t  scaleHeight   = Math.min( canvas.width, canvas.height ) / 34 | 0, // circular scale height (radial mode)","  \t\t\t  fontSizeX     = canvasX.height \u003e\u003e 1,","\t\t\t  fontSizeR     = scaleHeight \u003e\u003e 1,","\t\t\t  labelWidthX   = fontSizeX * ( _noteLabels ? .7 : 1.5 ),","\t\t\t  labelWidthR   = fontSizeR * ( _noteLabels ? 1 : 2 ),","\t\t  \t  root12        = 2 ** ( 1 / 12 );","","\t\tif ( ! _noteLabels \u0026\u0026 ( this._ansiBands || _frequencyScale != SCALE_LOG ) ) {","\t\t\tfreqLabels.push( 16, 31.5, 63, 125, 250, 500, 1e3, 2e3, 4e3 );","\t\t\tif ( _frequencyScale == SCALE_LINEAR )","\t\t\t\tfreqLabels.push( 6e3, 8e3, 10e3, 12e3, 14e3, 16e3, 18e3, 20e3, 22e3 );","\t\t\telse","\t\t\t\tfreqLabels.push( 8e3, 16e3 );","\t\t}","\t\telse {","\t\t\tlet freq = C_1;","\t\t\tfor ( let octave = -1; octave \u003c 11; octave++ ) {","\t\t\t\tfor ( let note = 0; note \u003c 12; note++ ) {","\t\t\t\t\tif ( freq \u003e= this._minFreq \u0026\u0026 freq \u003c= this._maxFreq ) {","\t\t\t\t\t\tconst pitch = scale[ note ],","\t\t\t\t\t\t\t  isC   = pitch == 'C';","\t\t\t\t\t\tif ( ( pitch \u0026\u0026 _noteLabels \u0026\u0026 ! _mirror ) || isC )","\t\t\t\t\t\t\tfreqLabels.push( _noteLabels ? [ freq, pitch + ( isC ? octave : '' ) ] : freq );","\t\t\t\t\t}","\t\t\t\t\tfreq *= root12;","\t\t\t\t}","\t\t\t}","\t\t}","","\t\t// in radial dual-vertical layout, the scale is positioned exactly between both channels, by making the canvas a bit larger than the inner diameter","\t\tcanvasR.width = canvasR.height = ( radius \u003c\u003c 1 ) + ( isVertical * scaleHeight );","","\t\tconst centerR = canvasR.width \u003e\u003e 1,","\t\t\t  radialY = centerR - scaleHeight * .7;\t// vertical position of text labels in the circular scale","","\t\t// helper function","\t\tconst radialLabel = ( x, label ) =\u003e {","\t\t\tconst angle  = TAU * ( x / canvas.width ),","\t\t\t\t  adjAng = angle - HALF_PI, // rotate angles so 0 is at the top","\t\t\t\t  posX   = radialY * Math.cos( adjAng ),","\t\t\t\t  posY   = radialY * Math.sin( adjAng );","","\t\t\t_scaleR.save();","\t\t\t_scaleR.translate( centerR + posX, centerR + posY );","\t\t\t_scaleR.rotate( angle );","\t\t\t_scaleR.fillText( label, 0, 0 );","\t\t\t_scaleR.restore();","\t\t}","","\t\t// clear scale canvas","\t\tcanvasX.width |= 0;","","\t\t_scaleX.fillStyle = _scaleR.strokeStyle = SCALEX_BACKGROUND_COLOR;","\t\t_scaleX.fillRect( 0, 0, canvasX.width, canvasX.height );","","\t\t_scaleR.arc( centerR, centerR, centerR - scaleHeight / 2, 0, TAU );","\t\t_scaleR.lineWidth = scaleHeight;","\t\t_scaleR.stroke();","","\t\t_scaleX.fillStyle = _scaleR.fillStyle = SCALEX_LABEL_COLOR;","\t\t_scaleX.font = `${ fontSizeX }px ${FONT_FAMILY}`;","\t\t_scaleR.font = `${ fontSizeR }px ${FONT_FAMILY}`;","\t\t_scaleX.textAlign = _scaleR.textAlign = 'center';","","\t\tlet prevX = -labelWidthX / 4,","\t\t\tprevR = -labelWidthR;","","\t\tfor ( const item of freqLabels ) {","\t\t\tconst [ freq, label ] = Array.isArray( item ) ? item : [ item, item \u003c 1e3 ? item | 0 : `${ ( item / 100 | 0 ) / 10 }k` ],","\t\t\t\t  x    = unitWidth * ( this._freqScaling( freq ) - scaleMin ),","\t\t\t\t  y    = canvasX.height * .75,","\t\t\t\t  isC  = label[0] == 'C',","\t  \t\t\t  maxW = fontSizeX * ( _noteLabels \u0026\u0026 ! _mirror ? ( isC ? 1.2 : .6 ) : 3 );","","\t  \t\t// set label color - no highlight when mirror effect is active (only Cs displayed)","\t\t\t_scaleX.fillStyle = _scaleR.fillStyle = isC \u0026\u0026 ! _mirror ? SCALEX_HIGHLIGHT_COLOR : SCALEX_LABEL_COLOR;","","\t\t\t// prioritizes which note labels are displayed, due to the restricted space on some ranges/scales","\t\t\tif ( _noteLabels ) {","\t\t\t\tconst isLog = _frequencyScale == SCALE_LOG,","\t\t\t\t\t  isLinear = _frequencyScale == SCALE_LINEAR;","","\t\t\t\tlet allowedLabels = ['C'];","","\t\t\t\tif ( isLog || freq \u003e 2e3 || ( ! isLinear \u0026\u0026 freq \u003e 250 ) ||","\t\t\t\t\t ( ( ! _radial || isVertical ) \u0026\u0026 ( ! isLinear \u0026\u0026 freq \u003e 125 || freq \u003e 1e3 ) ) )","\t\t\t\t\tallowedLabels.push('G');","\t\t\t\tif ( isLog || freq \u003e 4e3 || ( ! isLinear \u0026\u0026 freq \u003e 500 ) ||","\t\t\t\t\t ( ( ! _radial || isVertical ) \u0026\u0026 ( ! isLinear \u0026\u0026 freq \u003e 250 || freq \u003e 2e3 ) ) )","\t\t\t\t\tallowedLabels.push('E');","\t\t\t\tif ( isLinear \u0026\u0026 freq \u003e 4e3 ||","\t\t\t\t\t ( ( ! _radial || isVertical ) \u0026\u0026 ( isLog || freq \u003e 2e3 || ( ! isLinear \u0026\u0026 freq \u003e 500 ) ) ) )","\t\t\t\t\tallowedLabels.push('D','F','A','B');","\t\t\t\tif ( ! allowedLabels.includes( label[0] ) )","\t\t\t\t\tcontinue; // skip this label","\t\t\t}","","\t\t\t// linear scale","\t\t\tif ( x \u003e= prevX + labelWidthX / 2 \u0026\u0026 x \u003c= analyzerWidth ) {","\t\t\t\t_scaleX.fillText( label, initialX + x, y, maxW );","\t\t\t\tif ( _mirror \u0026\u0026 ( x \u003e labelWidthX || _mirror == 1 ) )","\t\t\t\t\t_scaleX.fillText( label, ( initialX || canvas.width ) - x, y, maxW );","\t\t\t\tprevX = x + Math.min( maxW, _scaleX.measureText( label ).width ) / 2;","\t\t\t}","","\t\t\t// radial scale","\t\t\tif ( x \u003e= prevR + labelWidthR \u0026\u0026 x \u003c analyzerWidth - labelWidthR ) { // avoid overlapping the last label over the first one","\t\t\t\tradialLabel( x, label );","\t\t\t\tif ( _mirror \u0026\u0026 ( x \u003e labelWidthR || _mirror == 1 ) ) // avoid overlapping of first labels on mirror mode","\t\t\t\t\tradialLabel( -x, label );","\t\t\t\tprevR = x;","\t\t\t}","\t\t}","\t}","","\t/**","\t * Redraw the canvas","\t * this is called 60 times per second by requestAnimationFrame()","\t */","\t_draw( timestamp ) {","\t\t// schedule next canvas update","\t\tthis._runId = requestAnimationFrame( timestamp =\u003e this._draw( timestamp ) );","","\t\tif ( this._maxFPS \u0026\u0026 ( timestamp - this._last \u003c 1000 / this._maxFPS ) )","\t\t\treturn;","","\t\tconst { isAlpha,","\t\t\t    isBands,","\t\t\t    isLeds,","\t\t\t    isLumi,","\t\t\t    isOctaves,","\t\t\t    isOutline,","\t\t\t    isRound,","\t\t\t    noLedGap }     = this._flg,","","\t\t\t  { analyzerHeight,","\t\t\t    channelCoords,","\t\t\t    channelHeight,","\t\t\t    channelGap,","\t\t\t    initialX,","\t\t\t    radius }       = this._aux,","","\t\t\t  { _bars,","\t\t\t    canvas,","\t\t\t    _canvasGradients,","\t\t\t    _chLayout,","\t\t\t    _colorMode,","\t\t\t    _ctx,","\t\t\t    _energy,","\t\t\t    fillAlpha,","\t\t\t    _fps,","\t\t\t    _linearAmplitude,","\t\t\t    _lineWidth,","\t\t\t    maxDecibels,","\t\t\t    minDecibels,","\t\t\t    _mirror,","\t\t\t    _mode,","\t\t\t    overlay,","\t\t\t    _radial,","\t\t\t    showBgColor,","\t\t\t    showPeaks,","\t\t\t    useCanvas,","\t\t\t    _weightingFilter } = this,","","\t\t\t  canvasX        = this._scaleX.canvas,","\t\t\t  canvasR        = this._scaleR.canvas,","\t\t\t  centerX        = canvas.width \u003e\u003e 1,","\t\t\t  centerY        = canvas.height \u003e\u003e 1,","\t\t\t  holdFrames     = _fps \u003e\u003e 1, // number of frames in half a second","\t\t\t  isDualVertical = _chLayout == CHANNEL_VERTICAL,","\t\t\t  isDualCombined = _chLayout == CHANNEL_COMBINED,","\t\t\t  isSingle       = _chLayout == CHANNEL_SINGLE,","\t\t\t  isTrueLeds     = isLeds \u0026\u0026 this._trueLeds \u0026\u0026 _colorMode == COLOR_GRADIENT,","\t\t\t  analyzerWidth  = _radial ? canvas.width : this._aux.analyzerWidth,","\t\t\t  finalX         = initialX + analyzerWidth,","\t\t\t  showPeakLine   = showPeaks \u0026\u0026 this._peakLine \u0026\u0026 _mode == 10,","\t\t\t  maxBarHeight   = _radial ? Math.min( centerX, centerY ) - radius : analyzerHeight,","\t\t\t  dbRange \t\t = maxDecibels - minDecibels,","\t\t\t  [ ledCount, ledSpaceH, ledSpaceV, ledHeight ] = this._leds || [];","","\t\tif ( _energy.val \u003e 0 )","\t\t\tthis._spinAngle += this._spinSpeed * TAU / ( 60 * _fps ); // spinSpeed * angle increment per frame for 1 RPM","","\t\t/* HELPER FUNCTIONS */","","\t\t// create Reflex effect","\t\tconst doReflex = channel =\u003e {","\t\t\tif ( this._reflexRatio \u003e 0 \u0026\u0026 ! isLumi ) {","\t\t\t\tlet posY, height;","\t\t\t\tif ( this.reflexFit || isDualVertical ) { // always fit reflex in vertical stereo mode","\t\t\t\t\tposY   = isDualVertical \u0026\u0026 channel == 0 ? channelHeight + channelGap : 0;","\t\t\t\t\theight = channelHeight - analyzerHeight;","\t\t\t\t}","\t\t\t\telse {","\t\t\t\t\tposY   = canvas.height - analyzerHeight * 2;","\t\t\t\t\theight = analyzerHeight;","\t\t\t\t}","","\t\t\t\t_ctx.save();","","\t\t\t\t// set alpha and brightness for the reflection","\t\t\t\t_ctx.globalAlpha = this.reflexAlpha;","\t\t\t\tif ( this.reflexBright != 1 )","\t\t\t\t\t_ctx.filter = `brightness(${this.reflexBright})`;","","\t\t\t\t// create the reflection","\t\t\t\t_ctx.setTransform( 1, 0, 0, -1, 0, canvas.height );","\t\t\t\t_ctx.drawImage( canvas, 0, channelCoords[ channel ].channelTop, canvas.width, analyzerHeight, 0, posY, canvas.width, height );","","\t\t\t\t_ctx.restore();","\t\t\t}","\t\t}","","\t\t// draw scale on X-axis","\t\tconst drawScaleX = () =\u003e {","\t\t\tif ( this.showScaleX ) {","\t\t\t\tif ( _radial ) {","\t\t\t\t\t_ctx.save();","\t\t\t\t\t_ctx.translate( centerX, centerY );","\t\t\t\t\tif ( this._spinSpeed )","\t\t\t\t\t\t_ctx.rotate( this._spinAngle + HALF_PI );","\t\t\t\t\t_ctx.drawImage( canvasR, -canvasR.width \u003e\u003e 1, -canvasR.width \u003e\u003e 1 );","\t\t\t\t\t_ctx.restore();","\t\t\t\t}","\t\t\t\telse","\t\t\t\t\t_ctx.drawImage( canvasX, 0, canvas.height - canvasX.height );","\t\t\t}","\t\t}","","\t\t// draw scale on Y-axis","\t\tconst drawScaleY = channelTop =\u003e {","\t\t\tconst scaleWidth = canvasX.height,","\t\t\t\t  fontSize   = scaleWidth \u003e\u003e 1,","\t\t\t\t  max        = _linearAmplitude ? 100 : maxDecibels,","\t\t\t\t  min        = _linearAmplitude ? 0 : minDecibels,","\t\t\t\t  incr       = _linearAmplitude ? 20 : 5,","\t\t\t\t  interval   = analyzerHeight / ( max - min );","","\t\t\t_ctx.save();","\t\t\t_ctx.fillStyle = SCALEY_LABEL_COLOR;","\t\t\t_ctx.font = `${fontSize}px ${FONT_FAMILY}`;","\t\t\t_ctx.textAlign = 'right';","\t\t\t_ctx.lineWidth = 1;","","\t\t\tfor ( let val = max; val \u003e min; val -= incr ) {","\t\t\t\tconst posY = channelTop + ( max - val ) * interval,","\t\t\t\t\t  even = ( val % 2 == 0 ) | 0;","","\t\t\t\tif ( even ) {","\t\t\t\t\tconst labelY = posY + fontSize * ( posY == channelTop ? .8 : .35 );","\t\t\t\t\tif ( _mirror != -1 )","\t\t\t\t\t\t_ctx.fillText( val, scaleWidth * .85, labelY );","\t\t\t\t\tif ( _mirror != 1 )","\t\t\t\t\t\t_ctx.fillText( val, canvas.width - scaleWidth * .1, labelY );","\t\t\t\t\t_ctx.strokeStyle = SCALEY_LABEL_COLOR;","\t\t\t\t\t_ctx.setLineDash([2,4]);","\t\t\t\t\t_ctx.lineDashOffset = 0;","\t\t\t\t}","\t\t\t\telse {","\t\t\t\t\t_ctx.strokeStyle = SCALEY_MIDLINE_COLOR;","\t\t\t\t\t_ctx.setLineDash([2,8]);","\t\t\t\t\t_ctx.lineDashOffset = 1;","\t\t\t\t}","","\t\t\t\t_ctx.beginPath();","\t\t\t\t_ctx.moveTo( initialX + scaleWidth * even * ( _mirror != -1 ), ~~posY + .5 ); // for sharp 1px line (https://stackoverflow.com/a/13879402/2370385)","\t\t\t\t_ctx.lineTo( finalX - scaleWidth * even * ( _mirror != 1 ), ~~posY + .5 );","\t\t\t\t_ctx.stroke();","\t\t\t}","\t\t\t_ctx.restore();","\t\t}","","\t\t// returns the gain (in dB) for a given frequency, considering the currently selected weighting filter","\t\tconst weightingdB = freq =\u003e {","\t\t\tconst f2 = freq ** 2,","\t\t\t\t  SQ20_6  = 424.36,","\t\t\t\t  SQ107_7 = 11599.29,","\t\t\t\t  SQ158_5 = 25122.25,","\t\t\t\t  SQ737_9 = 544496.41,","\t\t\t\t  SQ12194 = 148693636,","\t\t\t\t  linearTodB = value =\u003e 20 * Math.log10( value );","","\t\t\tswitch ( _weightingFilter ) {","\t\t\t\tcase FILTER_A : // A-weighting https://en.wikipedia.org/wiki/A-weighting","\t\t\t\t\tconst rA = ( SQ12194 * f2 ** 2 ) / ( ( f2 + SQ20_6 ) * Math.sqrt( ( f2 + SQ107_7 ) * ( f2 + SQ737_9 ) ) * ( f2 + SQ12194 ) );","\t\t\t\t\treturn 2 + linearTodB( rA );","","\t\t\t\tcase FILTER_B :","\t\t\t\t\tconst rB = ( SQ12194 * f2 * freq ) / ( ( f2 + SQ20_6 ) * Math.sqrt( f2 + SQ158_5 ) * ( f2 + SQ12194 ) );","\t\t\t\t\treturn .17 + linearTodB( rB );","","\t\t\t\tcase FILTER_C :","\t\t\t\t\tconst rC = ( SQ12194 * f2 ) / ( ( f2 + SQ20_6 ) * ( f2 + SQ12194 ) );","\t\t\t\t\treturn .06 + linearTodB( rC );","","\t\t\t\tcase FILTER_D :","\t\t\t\t\tconst h = ( ( 1037918.48 - f2 ) ** 2 + 1080768.16 * f2 ) / ( ( 9837328 - f2 ) ** 2 + 11723776 * f2 ),","\t\t\t\t\t\t  rD = ( freq / 6.8966888496476e-5 ) * Math.sqrt( h / ( ( f2 + 79919.29 ) * ( f2 + 1345600 ) ) );","\t\t\t\t\treturn linearTodB( rD );","","\t\t\t\tcase FILTER_468 : // ITU-R 468 https://en.wikipedia.org/wiki/ITU-R_468_noise_weighting","\t\t\t\t\tconst h1 = -4.737338981378384e-24 * freq ** 6 + 2.043828333606125e-15 * freq ** 4 - 1.363894795463638e-7 * f2 + 1,","\t\t\t\t\t\t  h2 = 1.306612257412824e-19 * freq ** 5 - 2.118150887518656e-11 * freq ** 3 + 5.559488023498642e-4 * freq,","\t\t\t\t\t\t  rI = 1.246332637532143e-4 * freq / Math.hypot( h1, h2 );","\t\t\t\t\treturn 18.2 + linearTodB( rI );","\t\t\t}","","\t\t\treturn 0; // unknown filter","\t\t}","","\t\t// draws (stroke) a bar from x,y1 to x,y2","\t\tconst strokeBar = ( x, y1, y2 ) =\u003e {","\t\t\t_ctx.beginPath();","\t\t\t_ctx.moveTo( x, y1 );","\t\t\t_ctx.lineTo( x, y2 );","\t\t\t_ctx.stroke();","\t\t}","","\t\t// conditionally strokes current path on canvas","\t\tconst strokeIf = flag =\u003e {","\t\t\tif ( flag \u0026\u0026 _lineWidth ) {","\t\t\t\tconst alpha = _ctx.globalAlpha;","\t\t\t\t_ctx.globalAlpha = 1;","\t\t\t\t_ctx.stroke();","\t\t\t\t_ctx.globalAlpha = alpha;","\t\t\t}","\t\t}","","\t\t// converts a given X-coordinate to its corresponding angle in radial mode","\t\tconst getAngle = ( x, dir ) =\u003e dir * TAU * ( x / canvas.width ) + this._spinAngle;","","\t\t// converts planar X,Y coordinates to radial coordinates","\t\tconst radialXY = ( x, y, dir = 1 ) =\u003e {","\t\t\tconst height = radius + y,","\t\t\t\t  angle  = getAngle( x, dir );","\t\t\treturn [ centerX + height * Math.cos( angle ), centerY + height * Math.sin( angle ) ];","\t\t}","","\t\t// draws a polygon of width `w` and height `h` at (x,y) in radial mode","\t\tconst radialPoly = ( x, y, w, h, stroke ) =\u003e {","\t\t\t_ctx.beginPath();","\t\t\tfor ( const dir of ( _mirror ? [1,-1] : [1] ) ) {","\t\t\t\tconst [ startAngle, endAngle ] = isRound ? [ getAngle( x, dir ), getAngle( x + w, dir ) ] : [];","\t\t\t\t_ctx.moveTo( ...radialXY( x, y, dir ) );","\t\t\t\t_ctx.lineTo( ...radialXY( x, y + h, dir ) );","\t\t\t\tif ( isRound )","\t\t\t\t\t_ctx.arc( centerX, centerY, radius + y + h, startAngle, endAngle, dir != 1 );","\t\t\t\telse","\t\t\t\t\t_ctx.lineTo( ...radialXY( x + w, y + h, dir ) );","\t\t\t\t_ctx.lineTo( ...radialXY( x + w, y, dir ) );","\t\t\t\tif ( isRound \u0026\u0026 ! stroke ) // close the bottom line only when not in outline mode","\t\t\t\t\t_ctx.arc( centerX, centerY, radius + y, endAngle, startAngle, dir == 1 );","\t\t\t}","\t\t\tstrokeIf( stroke );","\t\t\t_ctx.fill();","\t\t}","","\t\t// converts a value in [0;1] range to a height in pixels that fits into the current LED elements","\t\tconst ledPosY = value =\u003e Math.max( 0, ( value * ledCount | 0 ) * ( ledHeight + ledSpaceV ) - ledSpaceV );","","\t\t// update energy information","\t\tconst updateEnergy = newVal =\u003e {","\t\t\t_energy.val = newVal;","\t\t\tif ( _energy.peak \u003e 0 ) {","\t\t\t\t_energy.hold--;","\t\t\t\tif ( _energy.hold \u003c 0 )","\t\t\t\t\t_energy.peak += _energy.hold / ( holdFrames * holdFrames / 2 );","\t\t\t}","\t\t\tif ( newVal \u003e= _energy.peak ) {","\t\t\t\t_energy.peak = newVal;","\t\t\t\t_energy.hold = holdFrames;","\t\t\t}","\t\t}","","\t\t// calculate and display (if enabled) the current frame rate","\t\tconst updateFPS = () =\u003e {","\t\t\tconst elapsed = timestamp - this._time; // elapsed time since the last FPS computation","","\t\t\tthis._last = timestamp - ( this._maxFPS ? elapsed % ( 1000 / this._maxFPS ) : 0 ); // thanks https://stackoverflow.com/a/19772220/2370385","\t\t\tthis._frames++;","","\t\t\tif ( elapsed \u003e= 1000 ) {","\t\t\t\tthis._fps = this._frames / ( elapsed / 1000 );","\t\t\t\tthis._frames = 0;","\t\t\t\tthis._time = timestamp;","\t\t\t}","\t\t\tif ( this.showFPS ) {","\t\t\t\tconst size = canvasX.height;","\t\t\t\t_ctx.font = `bold ${size}px ${FONT_FAMILY}`;","\t\t\t\t_ctx.fillStyle = FPS_COLOR;","\t\t\t\t_ctx.textAlign = 'right';","\t\t\t\t_ctx.fillText( Math.round( this._fps ), canvas.width - size, size * 2 );","\t\t\t}","\t\t}","","\t\t/* MAIN FUNCTION */","","\t\tlet currentEnergy = 0;","","\t\tconst nBars     = _bars.length,","\t\t\t  nChannels = isSingle ? 1 : 2;","","\t\tfor ( let channel = 0; channel \u003c nChannels; channel++ ) {","","\t\t\tconst { channelTop, channelBottom, analyzerBottom } = channelCoords[ channel ],","\t\t\t\t  channelGradient = this._gradients[ this._selectedGrads[ channel ] ],","\t\t\t\t  colorStops      = channelGradient.colorStops,","\t\t\t\t  colorCount      = colorStops.length,","\t\t\t\t  bgColor         = ( ! showBgColor || isLeds \u0026\u0026 ! overlay ) ? '#000' : channelGradient.bgColor,","\t\t\t\t  mustClear       = channel == 0 || ! _radial \u0026\u0026 ! isDualCombined,","\t\t\t\t  direction       = channel \u0026\u0026 _radial \u0026\u0026 isDualVertical ? -1 : 1; // for radial dual vertical layout","","\t\t\t// helper function for FFT data interpolation (uses fftData)","\t\t\tconst interpolate = ( bin, ratio ) =\u003e {","\t\t\t\tconst value = fftData[ bin ] + ( bin \u003c fftData.length - 1 ? ( fftData[ bin + 1 ] - fftData[ bin ] ) * ratio : 0 );","\t\t\t\treturn isNaN( value ) ? -Infinity : value;","\t\t\t}","","\t\t\t// set fillStyle and strokeStyle according to current colorMode (uses: channel, colorStops, colorCount)","\t\t\tconst setBarColor = ( value = 0, barIndex = 0 ) =\u003e {","\t\t\t\tlet color;","\t\t\t\t// for mode 10, always use the channel gradient (ignore colorMode)","\t\t\t\tif ( ( _colorMode == COLOR_GRADIENT \u0026\u0026 ! isTrueLeds ) || _mode == 10 )","\t\t\t\t\tcolor = _canvasGradients[ channel ];","\t\t\t\telse {","\t\t\t\t\tconst selectedIndex = _colorMode == COLOR_BAR_INDEX ? barIndex % colorCount : colorStops.findLastIndex( item =\u003e isLeds ? ledPosY( value ) \u003c= ledPosY( item.level ) : value \u003c= item.level );","\t\t\t\t\tcolor = colorStops[ selectedIndex ].color;","\t\t\t\t}","\t\t\t\t_ctx.fillStyle = _ctx.strokeStyle = color;","\t\t\t}","","\t\t\tif ( useCanvas ) {","\t\t\t\t// clear the channel area, if in overlay mode","\t\t\t\t// this is done per channel to clear any residue below 0 off the top channel (especially in line graph mode with lineWidth \u003e 1)","\t\t\t\tif ( overlay \u0026\u0026 mustClear )","\t\t\t\t\t_ctx.clearRect( 0, channelTop - channelGap, canvas.width, channelHeight + channelGap );","","\t\t\t\t// fill the analyzer background if needed (not overlay or overlay + showBgColor)","\t\t\t\tif ( ! overlay || showBgColor ) {","\t\t\t\t\tif ( overlay )","\t\t\t\t\t\t_ctx.globalAlpha = this.bgAlpha;","","\t\t\t\t\t_ctx.fillStyle = bgColor;","","\t\t\t\t\t// exclude the reflection area when overlay is true and reflexAlpha == 1 (avoids alpha over alpha difference, in case bgAlpha \u003c 1)","\t\t\t\t\tif ( mustClear )","\t\t\t\t\t\t_ctx.fillRect( initialX, channelTop - channelGap, analyzerWidth, ( overlay \u0026\u0026 this.reflexAlpha == 1 ? analyzerHeight : channelHeight ) + channelGap );","","\t\t\t\t\t_ctx.globalAlpha = 1;","\t\t\t\t}","","\t\t\t\t// draw dB scale (Y-axis) - avoid drawing it twice on 'dual-combined' channel layout","\t\t\t\tif ( this.showScaleY \u0026\u0026 ! isLumi \u0026\u0026 ! _radial \u0026\u0026 ( channel == 0 || ! isDualCombined ) )","\t\t\t\t\tdrawScaleY( channelTop );","","\t\t\t\t// set line width and dash for LEDs effect","\t\t\t\tif ( isLeds ) {","\t\t\t\t\t_ctx.setLineDash( [ ledHeight, ledSpaceV ] );","\t\t\t\t\t_ctx.lineWidth = _bars[0].width;","\t\t\t\t}","\t\t\t\telse // for outline effect ensure linewidth is not greater than half the bar width","\t\t\t\t\t_ctx.lineWidth = isOutline ? Math.min( _lineWidth, _bars[0].width / 2 ) : _lineWidth;","","\t\t\t\t// set clip region","\t\t\t\t_ctx.save();","\t\t\t\tif ( ! _radial ) {","\t\t\t\t\tconst channelRegion = new Path2D();","\t\t\t\t\tchannelRegion.rect( 0, channelTop, canvas.width, analyzerHeight );","\t\t\t\t\t_ctx.clip( channelRegion );","\t\t\t\t}","\t\t\t} // if ( useCanvas )","","\t\t\t// get a new array of data from the FFT","\t\t\tlet fftData = this._fftData[ channel ];","\t\t\tthis._analyzer[ channel ].getFloatFrequencyData( fftData );","","\t\t\t// apply weighting","\t\t\tif ( _weightingFilter )","\t\t\t\tfftData = fftData.map( ( val, idx ) =\u003e val + weightingdB( this._binToFreq( idx ) ) );","","\t\t\t// start drawing path (for mode 10)","\t\t\t_ctx.beginPath();","","\t\t\t// store line graph points to create mirror effect in radial mode","\t\t\tlet points = [];","","\t\t\t// draw bars / lines","","\t\t\tfor ( let barIndex = 0; barIndex \u003c nBars; barIndex++ ) {","","\t\t\t\tconst bar = _bars[ barIndex ],","\t\t\t\t\t  { posX, barCenter, width, freq, binLo, binHi, ratioLo, ratioHi } = bar;","","\t\t\t\tlet barValue = Math.max( interpolate( binLo, ratioLo ), interpolate( binHi, ratioHi ) );","","\t\t\t\t// check additional bins (if any) for this bar and keep the highest value","\t\t\t\tfor ( let j = binLo + 1; j \u003c binHi; j++ ) {","\t\t\t\t\tif ( fftData[ j ] \u003e barValue )","\t\t\t\t\t\tbarValue = fftData[ j ];","\t\t\t\t}","","\t\t\t\t// normalize bar amplitude in [0;1] range","\t\t\t\tbarValue = this._normalizedB( barValue );","","\t\t\t\tbar.value[ channel ] = barValue;","\t\t\t\tcurrentEnergy += barValue;","","\t\t\t\t// update bar peak","\t\t\t\tif ( bar.peak[ channel ] \u003e 0 ) {","\t\t\t\t\tbar.hold[ channel ]--;","\t\t\t\t\t// if hold is negative, it becomes the \"acceleration\" for peak drop","\t\t\t\t\tif ( bar.hold[ channel ] \u003c 0 )","\t\t\t\t\t\tbar.peak[ channel ] += bar.hold[ channel ] / ( holdFrames * holdFrames / 2 );","\t\t\t\t}","","\t\t\t\t// check if it's a new peak for this bar","\t\t\t\tif ( barValue \u003e= bar.peak[ channel ] ) {","\t\t\t\t\tbar.peak[ channel ] = barValue;","\t\t\t\t\tbar.hold[ channel ] = holdFrames;","\t\t\t\t}","","\t\t\t\t// if not using the canvas, move earlier to the next bar","\t\t\t\tif ( ! useCanvas )","\t\t\t\t\tcontinue;","","\t\t\t\t// set opacity for bar effects","\t\t\t\tif ( isLumi || isAlpha )","\t\t\t\t\t_ctx.globalAlpha = barValue;","\t\t\t\telse if ( isOutline )","\t\t\t\t\t_ctx.globalAlpha = fillAlpha;","","\t\t\t\t// set fillStyle and strokeStyle for the current bar","\t\t\t\tsetBarColor( barValue, barIndex );","","\t\t\t\t// compute actual bar height on screen","\t\t\t\tconst barHeight = ( isLumi ? maxBarHeight : isLeds ? ledPosY( barValue ) : barValue * maxBarHeight | 0 ) * direction;","","\t\t\t\t// Draw current bar or line segment","","\t\t\t\tif ( _mode == 10 ) {","\t\t\t\t\t// compute the average between the initial bar (barIndex==0) and the next one","\t\t\t\t\t// used to smooth the curve when the initial posX is off the screen, in mirror and radial modes","\t\t\t\t\tconst nextBarAvg = barIndex ? 0 : ( this._normalizedB( fftData[ _bars[1].binLo ] ) * maxBarHeight * direction + barHeight ) / 2;","","\t\t\t\t\tif ( _radial ) {","\t\t\t\t\t\tif ( barIndex == 0 )","\t\t\t\t\t\t\t_ctx.lineTo( ...radialXY( 0, ( posX \u003c 0 ? nextBarAvg : barHeight ) ) );","\t\t\t\t\t\t// draw line to the current point, avoiding overlapping wrap-around frequencies","\t\t\t\t\t\tif ( posX \u003e= 0 ) {","\t\t\t\t\t\t\tconst point = [ posX, barHeight ];","\t\t\t\t\t\t\t_ctx.lineTo( ...radialXY( ...point ) );","\t\t\t\t\t\t\tpoints.push( point );","\t\t\t\t\t\t}","\t\t\t\t\t}","\t\t\t\t\telse { // Linear","\t\t\t\t\t\tif ( barIndex == 0 ) {","\t\t\t\t\t\t\t// start the line off-screen using the previous FFT bin value as the initial amplitude","\t\t\t\t\t\t\tif ( _mirror != -1 ) {","\t\t\t\t\t\t\t\tconst prevFFTData = binLo ? this._normalizedB( fftData[ binLo - 1 ] ) * maxBarHeight : barHeight; // use previous FFT bin value, when available","\t\t\t\t\t\t\t\t_ctx.moveTo( initialX - _lineWidth, analyzerBottom - prevFFTData );","\t\t\t\t\t\t\t}","\t\t\t\t\t\t\telse","\t\t\t\t\t\t\t\t_ctx.moveTo( initialX, analyzerBottom - ( posX \u003c initialX ? nextBarAvg : barHeight ) );","\t\t\t\t\t\t}","\t\t\t\t\t\t// draw line to the current point","\t\t\t\t\t\t// avoid X values lower than the origin when mirroring left, otherwise draw them for best graph accuracy","\t\t\t\t\t\tif ( _mirror != -1 || posX \u003e= initialX )","\t\t\t\t\t\t\t_ctx.lineTo( posX, analyzerBottom - barHeight );","\t\t\t\t\t}","\t\t\t\t}","\t\t\t\telse {","\t\t\t\t\tif ( isLeds ) {","\t\t\t\t\t\t// draw \"unlit\" leds - avoid drawing it twice on 'dual-combined' channel layout","\t\t\t\t\t\tif ( showBgColor \u0026\u0026 ! overlay \u0026\u0026 ( channel == 0 || ! isDualCombined ) ) {","\t\t\t\t\t\t\tconst alpha = _ctx.globalAlpha;","\t\t\t\t\t\t\t_ctx.strokeStyle = LEDS_UNLIT_COLOR;","\t\t\t\t\t\t\t_ctx.globalAlpha = 1;","\t\t\t\t\t\t\tstrokeBar( barCenter, channelTop, analyzerBottom );","\t\t\t\t\t\t\t// restore properties","\t\t\t\t\t\t\t_ctx.strokeStyle = _ctx.fillStyle;","\t\t\t\t\t\t\t_ctx.globalAlpha = alpha;","\t\t\t\t\t\t}","\t\t\t\t\t\tif ( isTrueLeds ) {","\t\t\t\t\t\t\t// ledPosY() is used below to fit one entire led height into the selected range","\t\t\t\t\t\t\tconst colorIndex = isLumi ? 0 : colorStops.findLastIndex( item =\u003e ledPosY( barValue ) \u003c= ledPosY( item.level ) );","\t\t\t\t\t\t\tlet last = analyzerBottom;","\t\t\t\t\t\t\tfor ( let i = colorCount - 1; i \u003e= colorIndex; i-- ) {","\t\t\t\t\t\t\t\t_ctx.strokeStyle = colorStops[ i ].color;","\t\t\t\t\t\t\t\tlet y = analyzerBottom - ( i == colorIndex ? barHeight : ledPosY( colorStops[ i ].level ) );","\t\t\t\t\t\t\t\tstrokeBar( barCenter, last, y );","\t\t\t\t\t\t\t\tlast = y - ledSpaceV;","\t\t\t\t\t\t\t}","\t\t\t\t\t\t}","\t\t\t\t\t\telse","\t\t\t\t\t\t\tstrokeBar( barCenter, analyzerBottom, analyzerBottom - barHeight );","\t\t\t\t\t}","\t\t\t\t\telse if ( posX \u003e= initialX ) {","\t\t\t\t\t\tif ( _radial )","\t\t\t\t\t\t\tradialPoly( posX, 0, width, barHeight, isOutline );","\t\t\t\t\t\telse if ( isRound ) {","\t\t\t\t\t\t\tconst halfWidth = width / 2,","\t\t\t\t\t\t\t\t  y = analyzerBottom + halfWidth; // round caps have an additional height of half bar width","","\t\t\t\t\t\t\t_ctx.beginPath();","\t\t\t\t\t\t\t_ctx.moveTo( posX, y );","\t\t\t\t\t\t\t_ctx.lineTo( posX, y - barHeight );","\t\t\t\t\t\t\t_ctx.arc( barCenter, y - barHeight, halfWidth, Math.PI, TAU );","\t\t\t\t\t\t\t_ctx.lineTo( posX + width, y );","\t\t\t\t\t\t\tstrokeIf( isOutline );","\t\t\t\t\t\t\t_ctx.fill();","\t\t\t\t\t\t}","\t\t\t\t\t\telse {","\t\t\t\t\t\t\tconst offset = isOutline ? _ctx.lineWidth : 0;","\t\t\t\t\t\t\t_ctx.beginPath();","\t\t\t\t\t\t\t_ctx.rect( posX, analyzerBottom + offset, width, -barHeight - offset );","\t\t\t\t\t\t\tstrokeIf( isOutline );","\t\t\t\t\t\t\t_ctx.fill();","\t\t\t\t\t\t}","\t\t\t\t\t}","\t\t\t\t}","","\t\t\t\t// Draw peak","\t\t\t\tconst peak = bar.peak[ channel ];","\t\t\t\tif ( peak \u003e 0 \u0026\u0026 showPeaks \u0026\u0026 ! showPeakLine \u0026\u0026 ! isLumi \u0026\u0026 posX \u003e= initialX \u0026\u0026 posX \u003c finalX ) {","\t\t\t\t\t// set opacity","\t\t\t\t\tif ( isOutline \u0026\u0026 _lineWidth \u003e 0 )","\t\t\t\t\t\t_ctx.globalAlpha = 1;","\t\t\t\t\telse if ( isAlpha )","\t\t\t\t\t\t_ctx.globalAlpha = peak;","","\t\t\t\t\t// select the peak color for 'bar-level' colorMode or 'trueLeds'","\t\t\t\t\tif ( _colorMode == COLOR_BAR_LEVEL || isTrueLeds )","\t\t\t\t\t\tsetBarColor( peak );","","\t\t\t\t\t// render peak according to current mode / effect","\t\t\t\t\tif ( isLeds ) {","\t\t\t\t\t\tconst ledPeak = ledPosY( peak );","\t\t\t\t\t\tif ( ledPeak \u003e= ledSpaceV ) // avoid peak below first led","\t\t\t\t\t\t\t_ctx.fillRect( posX,\tanalyzerBottom - ledPeak, width, ledHeight );","\t\t\t\t\t}","\t\t\t\t\telse if ( ! _radial )","\t\t\t\t\t\t_ctx.fillRect( posX, analyzerBottom - peak * maxBarHeight, width, 2 );","\t\t\t\t\telse if ( _mode != 10 ) // radial - peaks for mode 10 are done by the peak line code","\t\t\t\t\t\tradialPoly( posX, peak * maxBarHeight * direction, width, -2 );","\t\t\t\t}","","\t\t\t} // for ( let barIndex = 0; barIndex \u003c nBars; barIndex++ )","","\t\t\t// if not using the canvas, move earlier to the next channel","\t\t\tif ( ! useCanvas )","\t\t\t\tcontinue;","","\t\t\t_ctx.restore(); // restore clip region","","\t\t\t// restore global alpha","\t\t\t_ctx.globalAlpha = 1;","","\t\t\t// Fill/stroke drawing path for mode 10","\t\t\tif ( _mode == 10 ) {","\t\t\t\tsetBarColor(); // select channel gradient","","\t\t\t\tif ( _radial ) {","\t\t\t\t\tif ( _mirror ) {","\t\t\t\t\t\tlet p;","\t\t\t\t\t\twhile ( p = points.pop() )","\t\t\t\t\t\t\t_ctx.lineTo( ...radialXY( ...p, -1 ) );","\t\t\t\t\t}","\t\t\t\t\t_ctx.closePath();","\t\t\t\t}","","\t\t\t\tif ( _lineWidth \u003e 0 )","\t\t\t\t\t_ctx.stroke();","","\t\t\t\tif ( fillAlpha \u003e 0 ) {","\t\t\t\t\tif ( _radial ) {","\t\t\t\t\t\t// exclude the center circle from the fill area","\t\t\t\t\t\t_ctx.moveTo( centerX + radius, centerY );","\t\t\t\t\t\t_ctx.arc( centerX, centerY, radius, 0, TAU, true );","\t\t\t\t\t}","\t\t\t\t\telse { // close the fill area","\t\t\t\t\t\t_ctx.lineTo( finalX, analyzerBottom );","\t\t\t\t\t\t_ctx.lineTo( initialX, analyzerBottom );","\t\t\t\t\t}","","\t\t\t\t\t_ctx.globalAlpha = fillAlpha;","\t\t\t\t\t_ctx.fill();","\t\t\t\t\t_ctx.globalAlpha = 1;","\t\t\t\t}","","\t\t\t\t// draw peak line (and standard peaks on radial)","\t\t\t\tif ( showPeakLine || ( _radial \u0026\u0026 showPeaks ) ) {","\t\t\t\t\tpoints = []; // for mirror line on radial","\t\t\t\t\t_ctx.beginPath();","\t\t\t\t\t_bars.forEach( ( b, i ) =\u003e {","\t\t\t\t\t\tlet x = b.posX,","\t\t\t\t\t\t\th = b.peak[ channel ],","\t\t\t\t\t\t\tm = i ? 'lineTo' : 'moveTo';","\t\t\t\t\t\tif ( _radial \u0026\u0026 x \u003c 0 ) {","\t\t\t\t\t\t\tconst nextBar = _bars[ i + 1 ];","\t\t\t\t\t\t\th = findY( x, h, nextBar.posX, nextBar.peak[ channel ], 0 );","\t\t\t\t\t\t\tx = 0;","\t\t\t\t\t\t}","\t\t\t\t\t\th *= maxBarHeight * direction;","\t\t\t\t\t\tif ( showPeakLine ) {","\t\t\t\t\t\t\t_ctx[ m ]( ...( _radial ? radialXY( x, h ) : [ x, analyzerBottom - h ] ) );","\t\t\t\t\t\t\tif ( _radial \u0026\u0026 _mirror )","\t\t\t\t\t\t\t\tpoints.push( [ x, h ] );","\t\t\t\t\t\t}","\t\t\t\t\t\telse if ( h )","\t\t\t\t\t\t\tradialPoly( x, h, 1, -2 * direction ); // standard peaks (also does mirror)","\t\t\t\t\t});","\t\t\t\t\tif ( showPeakLine ) {","\t\t\t\t\t\tlet p;","\t\t\t\t\t\twhile ( p = points.pop() )","\t\t\t\t\t\t\t_ctx.lineTo( ...radialXY( ...p, -1 ) ); // mirror line points","\t\t\t\t\t\t_ctx.lineWidth = 1;","\t\t\t\t\t\t_ctx.stroke(); // stroke peak line","\t\t\t\t\t}","\t\t\t\t}","\t\t\t}","","\t\t\t// create Reflex effect","\t\t\tdoReflex( channel );","","\t\t} // for ( let channel = 0; channel \u003c nChannels; channel++ ) {","","\t\tupdateEnergy( currentEnergy / ( nBars \u003c\u003c ( nChannels - 1 ) ) );","","\t\tif ( useCanvas ) {","\t\t\t// Mirror effect","\t\t\tif ( _mirror \u0026\u0026 ! _radial ) {","\t\t\t\t_ctx.setTransform( -1, 0, 0, 1, canvas.width - initialX, 0 );","\t\t\t\t_ctx.drawImage( canvas, initialX, 0, centerX, canvas.height, 0, 0, centerX, canvas.height );","\t\t\t\t_ctx.setTransform( 1, 0, 0, 1, 0, 0 );","\t\t\t}","","\t\t\t// restore solid lines","\t\t\t_ctx.setLineDash([]);","","\t\t\t// draw frequency scale (X-axis)","\t\t\tdrawScaleX();","\t\t}","","\t\t// calculate and display (if enabled) the current frame rate","\t\tupdateFPS();","","\t\t// call callback function, if defined","\t\tif ( this.onCanvasDraw ) {","\t\t\t_ctx.save();","\t\t\t_ctx.fillStyle = _ctx.strokeStyle = _canvasGradients[0];","\t\t\tthis.onCanvasDraw( this, { timestamp, _canvasGradients } );","\t\t\t_ctx.restore();","\t\t}","\t}","","\t/**","\t * Return scaled frequency according to the selected scale","\t */","\t_freqScaling( freq ) {","\t\tswitch ( this._frequencyScale ) {","\t\t\tcase SCALE_LOG :","\t\t\t\treturn Math.log2( freq );","\t\t\tcase SCALE_BARK :","\t\t\t\treturn ( 26.81 * freq ) / ( 1960 + freq ) - .53;","\t\t\tcase SCALE_MEL :","\t\t\t\treturn Math.log2( 1 + freq / 700 );","\t\t\tcase SCALE_LINEAR :","\t\t\t\treturn freq;","\t\t}","\t}","","\t/**","\t * Return the FFT data bin (array index) which represents a given frequency","\t */","\t_freqToBin( freq, method = 'round' ) {","\t\tconst max = this._analyzer[0].frequencyBinCount - 1,","\t\t\t  bin = Math[ method ]( freq * this.fftSize / this.audioCtx.sampleRate );","","\t\treturn bin \u003c max ? bin : max;","\t}","","\t/**","\t * Generate currently selected gradient","\t */","\t_makeGrad() {","\t\tif ( ! this._ready )","\t\t\treturn;","","\t\tconst { canvas, _ctx, _radial, _reflexRatio } = this,","\t\t\t  { analyzerWidth, initialX, radius } = this._aux,","\t\t\t  { isLumi }     = this._flg,","\t\t\t  isDualVertical = this._chLayout == CHANNEL_VERTICAL,","\t\t\t  analyzerRatio  = 1 - _reflexRatio,","\t\t\t  centerX        = canvas.width \u003e\u003e 1,","\t\t\t  centerY        = canvas.height \u003e\u003e 1,","\t\t\t  maxRadius      = Math.min( centerX, centerY ),","\t\t\t  gradientHeight = isLumi ? canvas.height : canvas.height * ( 1 - _reflexRatio * ( ! isDualVertical ) ) | 0;","\t\t\t  \t\t\t\t   // for vertical stereo we keep the full canvas height and handle the reflex areas while generating the color stops","","\t\tfor ( const channel of [0,1] ) {","\t\t\tconst currGradient = this._gradients[ this._selectedGrads[ channel ] ],","\t\t\t\t  colorStops   = currGradient.colorStops,","\t\t\t\t  isHorizontal = currGradient.dir == 'h';","","\t\t\tlet grad;","","\t\t\tif ( _radial )","\t\t\t\tgrad = _ctx.createRadialGradient( centerX, centerY, maxRadius, centerX, centerY, radius - ( maxRadius - radius ) * isDualVertical );","\t\t\telse","\t\t\t\tgrad = _ctx.createLinearGradient( ...( isHorizontal ? [ initialX, 0, initialX + analyzerWidth, 0 ] : [ 0, 0, 0, gradientHeight ] ) );","","\t\t\tif ( colorStops ) {","\t\t\t\tconst dual = isDualVertical \u0026\u0026 ! this._splitGradient \u0026\u0026 ( ! isHorizontal || _radial );","","\t\t\t\tfor ( let channelArea = 0; channelArea \u003c 1 + dual; channelArea++ ) {","\t\t\t\t\tconst maxIndex = colorStops.length - 1;","","\t\t\t\t\tcolorStops.forEach( ( colorStop, index ) =\u003e {","\t\t\t\t\t\tlet offset = colorStop.pos;","","\t\t\t\t\t\t// in dual mode (not split), use half the original offset for each channel","\t\t\t\t\t\tif ( dual )","\t\t\t\t\t\t\toffset /= 2;","","\t\t\t\t\t\t// constrain the offset within the useful analyzer areas (avoid reflex areas)","\t\t\t\t\t\tif ( isDualVertical \u0026\u0026 ! isLumi \u0026\u0026 ! _radial \u0026\u0026 ! isHorizontal ) {","\t\t\t\t\t\t\toffset *= analyzerRatio;","\t\t\t\t\t\t\t// skip the first reflex area in split mode","\t\t\t\t\t\t\tif ( ! dual \u0026\u0026 offset \u003e .5 * analyzerRatio )","\t\t\t\t\t\t\t\toffset += .5 * _reflexRatio;","\t\t\t\t\t\t}","","\t\t\t\t\t\t// only for dual-vertical non-split gradient (creates full gradient on both halves of the canvas)","\t\t\t\t\t\tif ( channelArea == 1 ) {","\t\t\t\t\t\t\t// add colors in reverse order if radial or lumi are active","\t\t\t\t\t\t\tif ( _radial || isLumi ) {","\t\t\t\t\t\t\t\tconst revIndex = maxIndex - index;","\t\t\t\t\t\t\t\tcolorStop = colorStops[ revIndex ];","\t\t\t\t\t\t\t\toffset = 1 - colorStop.pos / 2;","\t\t\t\t\t\t\t}","\t\t\t\t\t\t\telse {","\t\t\t\t\t\t\t\t// if the first offset is not 0, create an additional color stop to prevent bleeding from the first channel","\t\t\t\t\t\t\t\tif ( index == 0 \u0026\u0026 offset \u003e 0 )","\t\t\t\t\t\t\t\t\tgrad.addColorStop( .5, colorStop.color );","\t\t\t\t\t\t\t\t// bump the offset to the second half of the gradient","\t\t\t\t\t\t\t\toffset += .5;","\t\t\t\t\t\t\t}","\t\t\t\t\t\t}","","\t\t\t\t\t\t// add gradient color stop","\t\t\t\t\t\tgrad.addColorStop( offset, colorStop.color );","","\t\t\t\t\t\t// create additional color stop at the end of first channel to prevent bleeding","\t\t\t\t\t\tif ( isDualVertical \u0026\u0026 index == maxIndex \u0026\u0026 offset \u003c .5 )","\t\t\t\t\t\t\tgrad.addColorStop( .5, colorStop.color );","\t\t\t\t\t});","\t\t\t\t} // for ( let channelArea = 0; channelArea \u003c 1 + dual; channelArea++ )","\t\t\t}","","\t\t\tthis._canvasGradients[ channel ] = grad;","\t\t} // for ( const channel of [0,1] )","\t}","","\t/**","\t * Normalize a dB value in the [0;1] range","\t */","\t_normalizedB( value ) {","\t\tconst isLinear   = this._linearAmplitude,","\t\t\t  boost      = isLinear ? 1 / this._linearBoost : 1,","\t\t\t  clamp      = ( val, min, max ) =\u003e val \u003c= min ? min : val \u003e= max ? max : val,","\t\t\t  dBToLinear = val =\u003e 10 ** ( val / 20 );","","\t\tlet maxValue = this.maxDecibels,","\t\t\tminValue = this.minDecibels;","","\t\tif ( isLinear ) {","\t\t\tmaxValue = dBToLinear( maxValue );","\t\t\tminValue = dBToLinear( minValue );","\t\t\tvalue = dBToLinear( value ) ** boost;","\t\t}","","\t\treturn clamp( ( value - minValue ) / ( maxValue - minValue ) ** boost, 0, 1 );","\t}","","\t/**","\t * Internal function to change canvas dimensions on demand","\t */","\t_setCanvas( reason ) {","\t\tif ( ! this._ready )","\t\t\treturn;","","\t\tconst { canvas, _ctx } = this,","\t\t\t  canvasX    = this._scaleX.canvas,","\t\t\t  pixelRatio = window.devicePixelRatio / ( this._loRes + 1 );","","\t\tlet screenWidth  = window.screen.width  * pixelRatio,","\t\t\tscreenHeight = window.screen.height * pixelRatio;","","\t\t// Fix for iOS Safari - swap width and height when in landscape","\t\tif ( Math.abs( window.orientation ) == 90 \u0026\u0026 screenWidth \u003c screenHeight )","\t\t\t[ screenWidth, screenHeight ] = [ screenHeight, screenWidth ];","","\t\tconst isFullscreen = this.isFullscreen,","\t\t\t  isCanvasFs   = isFullscreen \u0026\u0026 this._fsEl == canvas,","\t\t\t  newWidth     = isCanvasFs ? screenWidth  : ( this._width  || this._container.clientWidth  || this._defaultWidth  ) * pixelRatio | 0,","\t\t\t  newHeight    = isCanvasFs ? screenHeight : ( this._height || this._container.clientHeight || this._defaultHeight ) * pixelRatio | 0;","","\t\t// set/update object properties","\t\tthis._pixelRatio = pixelRatio;","\t\tthis._fsWidth    = screenWidth;","\t\tthis._fsHeight   = screenHeight;","","\t\t// if canvas dimensions haven't changed, quit","\t\tif ( canvas.width == newWidth \u0026\u0026 canvas.height == newHeight )","\t\t\treturn;","","\t\t// apply new dimensions","\t\tcanvas.width  = newWidth;","\t\tcanvas.height = newHeight;","","\t\t// if not in overlay mode, paint the canvas black","\t\tif ( ! this.overlay ) {","\t\t\t_ctx.fillStyle = '#000';","\t\t\t_ctx.fillRect( 0, 0, newWidth, newHeight );","\t\t}","","\t\t// set lineJoin property for area fill mode (this is reset whenever the canvas size changes)","\t\t_ctx.lineJoin = 'bevel';","","\t\t// update dimensions of the scale canvas","\t\tcanvasX.width = newWidth;","\t\tcanvasX.height = Math.max( 20 * pixelRatio, Math.min( newWidth, newHeight ) / 32 | 0 );","","\t\t// calculate bar positions and led options","\t\tthis._calcBars();","","\t\t// (re)generate gradient","\t\tthis._makeGrad();","","\t\t// detect fullscreen changes (for Safari)","\t\tif ( this._fsStatus !== undefined \u0026\u0026 this._fsStatus !== isFullscreen )","\t\t\treason = REASON_FSCHANGE;","\t\tthis._fsStatus = isFullscreen;","","\t\t// call the callback function, if defined","\t\tif ( this.onCanvasResize )","\t\t\tthis.onCanvasResize( reason, this );","\t}","","\t/**","\t * Select a gradient for one or both channels","\t *","\t * @param {string} name gradient name","\t * @param [{number}] desired channel (0 or 1) - if empty or invalid, sets both channels","\t */","\t_setGradient( name, channel ) {","\t\tif ( ! this._gradients.hasOwnProperty( name ) )","\t\t\tthrow new AudioMotionError( ERR_UNKNOWN_GRADIENT, name );","","\t\tif ( ! [0,1].includes( channel ) ) {","\t\t\tthis._selectedGrads[1] = name;","\t\t\tchannel = 0;","\t\t}","","\t\tthis._selectedGrads[ channel ] = name;","\t\tthis._makeGrad();","\t}","","\t/**","\t * Set object properties","\t */","\t_setProps( options, useDefaults ) {","","\t\t// settings defaults","\t\tconst defaults = {","\t\t\talphaBars      : false,","\t\t\tansiBands      : false,","\t\t\tbarSpace       : 0.1,","\t\t\tbgAlpha        : 0.7,","\t\t\tchannelLayout  : CHANNEL_SINGLE,","\t\t\tcolorMode      : COLOR_GRADIENT,","\t\t\tfftSize        : 8192,","\t\t\tfillAlpha      : 1,","\t\t\tfrequencyScale : SCALE_LOG,","\t\t\tgradient       : GRADIENTS[0][0],","\t\t\tledBars        : false,","\t\t\tlinearAmplitude: false,","\t\t\tlinearBoost    : 1,","\t\t\tlineWidth      : 0,","\t\t\tloRes          : false,","\t\t\tlumiBars       : false,","\t\t\tmaxDecibels    : -25,","\t\t\tmaxFPS         : 0,","\t\t\tmaxFreq        : 22000,","\t\t\tminDecibels    : -85,","\t\t\tminFreq        : 20,","\t\t\tmirror         : 0,","\t\t\tmode           : 0,","\t\t\tnoteLabels     : false,","\t\t\toutlineBars    : false,","\t\t\toverlay        : false,","\t\t\tpeakLine       : false,","\t\t\tradial\t\t   : false,","\t\t\treflexAlpha    : 0.15,","\t\t\treflexBright   : 1,","\t\t\treflexFit      : true,","\t\t\treflexRatio    : 0,","\t\t\troundBars      : false,","\t\t\tshowBgColor    : true,","\t\t\tshowFPS        : false,","\t\t\tshowPeaks      : true,","\t\t\tshowScaleX     : true,","\t\t\tshowScaleY     : false,","\t\t\tsmoothing      : 0.5,","\t\t\tspinSpeed      : 0,","\t\t\tsplitGradient  : false,","\t\t\tstart          : true,","\t\t\ttrueLeds       : false,","\t\t\tuseCanvas      : true,","\t\t\tvolume         : 1,","\t\t\tweightingFilter: FILTER_NONE","\t\t};","","\t\t// callback functions properties","\t\tconst callbacks = [ 'onCanvasDraw', 'onCanvasResize' ];","","\t\t// properties undefined by default","\t\tconst defaultUndefined = [ 'gradientLeft', 'gradientRight', 'height', 'width', 'stereo' ];","","\t\t// build an array of valid properties; `start` is not an actual property and is handled after setting everything else","\t\tconst validProps = Object.keys( defaults ).filter( e =\u003e e != 'start' ).concat( callbacks, defaultUndefined );","","\t\tif ( useDefaults || options === undefined )","\t\t\toptions = { ...defaults, ...options }; // merge options with defaults","","\t\tfor ( const prop of Object.keys( options ) ) {","\t\t\tif ( callbacks.includes( prop ) \u0026\u0026 typeof options[ prop ] !== 'function' ) // check invalid callback","\t\t\t\tthis[ prop ] = undefined;","\t\t\telse if ( validProps.includes( prop ) ) // set only valid properties","\t\t\t\tthis[ prop ] = options[ prop ];","\t\t}","","\t\tif ( options.start !== undefined )","\t\t\tthis.toggleAnalyzer( options.start );","\t}","","}"],"stylingDirectives":null,"csv":null,"csvError":null,"dependabotInfo":{"showConfigurationBanner":false,"configFilePath":null,"networkDependabotPath":"/hvianna/audioMotion-analyzer/network/updates","dismissConfigurationNoticePath":"/settings/dismiss-notice/dependabot_configuration_notice","configurationNoticeDismissed":null,"repoAlertsPath":"/hvianna/audioMotion-analyzer/security/dependabot","repoSecurityAndAnalysisPath":"/hvianna/audioMotion-analyzer/settings/security_analysis","repoOwnerIsOrg":false,"currentUserCanAdminRepo":false},"displayName":"audioMotion-analyzer.js","displayUrl":"https://github.com/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js?raw=true","headerInfo":{"blobSize":"78.2 KB","deleteInfo":{"deleteTooltip":"You must be signed in to make or propose changes"},"editInfo":{"editTooltip":"You must be signed in to make or propose changes"},"ghDesktopPath":"https://desktop.github.com","gitLfsPath":null,"onBranch":true,"shortPath":"48c6259","siteNavLoginPath":"/login?return_to=https%3A%2F%2Fgithub.com%2Fhvianna%2FaudioMotion-analyzer%2Fblob%2Fmaster%2Fsrc%2FaudioMotion-analyzer.js","isCSV":false,"isRichtext":false,"toc":null,"lineInfo":{"truncatedLoc":"2529","truncatedSloc":"2144"},"mode":"file"},"image":false,"isCodeownersFile":null,"isPlain":false,"isValidLegacyIssueTemplate":false,"issueTemplateHelpUrl":"https://docs.github.com/articles/about-issue-and-pull-request-templates","issueTemplate":null,"discussionTemplate":null,"language":"JavaScript","languageID":183,"large":false,"loggedIn":false,"newDiscussionPath":"/hvianna/audioMotion-analyzer/discussions/new","newIssuePath":"/hvianna/audioMotion-analyzer/issues/new","planSupportInfo":{"repoIsFork":null,"repoOwnedByCurrentUser":null,"requestFullPath":"/hvianna/audioMotion-analyzer/blob/master/src/audioMotion-analyzer.js","showFreeOrgGatedFeatureMessage":null,"showPlanSupportBanner":null,"upgradeDataAttributes":null,"upgradePath":null},"publishBannersInfo":{"dismissActionNoticePath":"/settings/dismiss-notice/publish_action_from_dockerfile","dismissStackNoticePath":"/settings/dismiss-notice/publish_stack_from_file","releasePath":"/hvianna/audioMotion-analyzer/releases/new?marketplace=true","showPublishActionBanner":false,"showPublishStackBanner":false},"renderImageOrRaw":false,"richText":null,"renderedFileInfo":null,"shortPath":null,"tabSize":4,"topBannersInfo":{"overridingGlobalFundingFile":false,"globalPreferredFundingPath":null,"repoOwner":"hvianna","repoName":"audioMotion-analyzer","showInvalidCitationWarning":false,"citationHelpUrl":"https://docs.github.com/en/github/creating-cloning-and-archiving-repositories/creating-a-repository-on-github/about-citation-files","showDependabotConfigurationBanner":false,"actionsOnboardingTip":null},"truncated":false,"viewable":true,"workflowRedirectUrl":null,"symbols":{"timedOut":false,"notAnalyzed":false,"symbols":[{"name":"AudioMotionError","kind":"class","identStart":3432,"identEnd":3448,"extentStart":3426,"extentEnd":3655,"fullyQualifiedName":"AudioMotionError","identUtf16":{"start":{"lineNumber":91,"utf16Col":6},"end":{"lineNumber":91,"utf16Col":22}},"extentUtf16":{"start":{"lineNumber":91,"utf16Col":0},"end":{"lineNumber":98,"utf16Col":1}}},{"name":"constructor","kind":"method","identStart":3466,"identEnd":3477,"extentStart":3466,"extentEnd":3653,"fullyQualifiedName":"AudioMotionError.constructor","identUtf16":{"start":{"lineNumber":92,"utf16Col":1},"end":{"lineNumber":92,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":92,"utf16Col":1},"end":{"lineNumber":97,"utf16Col":2}}},{"name":"deprecate","kind":"function","identStart":3730,"identEnd":3739,"extentStart":3730,"extentEnd":3835,"fullyQualifiedName":"deprecate","identUtf16":{"start":{"lineNumber":101,"utf16Col":6},"end":{"lineNumber":101,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":101,"utf16Col":6},"end":{"lineNumber":101,"utf16Col":111}}},{"name":"validateFromList","kind":"function","identStart":4041,"identEnd":4057,"extentStart":4041,"extentEnd":4172,"fullyQualifiedName":"validateFromList","identUtf16":{"start":{"lineNumber":105,"utf16Col":6},"end":{"lineNumber":105,"utf16Col":22}},"extentUtf16":{"start":{"lineNumber":105,"utf16Col":6},"end":{"lineNumber":105,"utf16Col":137}}},{"name":"findY","kind":"function","identStart":4292,"identEnd":4297,"extentStart":4292,"extentEnd":4368,"fullyQualifiedName":"findY","identUtf16":{"start":{"lineNumber":108,"utf16Col":6},"end":{"lineNumber":108,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":108,"utf16Col":6},"end":{"lineNumber":108,"utf16Col":82}}},{"name":"findLastIndex","kind":"function","identStart":4467,"identEnd":4480,"extentStart":4451,"extentEnd":4632,"fullyQualifiedName":"findLastIndex","identUtf16":{"start":{"lineNumber":112,"utf16Col":17},"end":{"lineNumber":112,"utf16Col":30}},"extentUtf16":{"start":{"lineNumber":112,"utf16Col":1},"end":{"lineNumber":119,"utf16Col":2}}},{"name":"AudioMotionAnalyzer","kind":"class","identStart":4687,"identEnd":4706,"extentStart":4681,"extentEnd":80123,"fullyQualifiedName":"AudioMotionAnalyzer","identUtf16":{"start":{"lineNumber":124,"utf16Col":21},"end":{"lineNumber":124,"utf16Col":40}},"extentUtf16":{"start":{"lineNumber":124,"utf16Col":15},"end":{"lineNumber":2528,"utf16Col":1}}},{"name":"constructor","kind":"method","identStart":4924,"identEnd":4935,"extentStart":4924,"extentEnd":11477,"fullyQualifiedName":"AudioMotionAnalyzer.constructor","identUtf16":{"start":{"lineNumber":133,"utf16Col":1},"end":{"lineNumber":133,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":133,"utf16Col":1},"end":{"lineNumber":316,"utf16Col":2}}},{"name":"onResize","kind":"function","identStart":9099,"identEnd":9107,"extentStart":9099,"extentEnd":9423,"fullyQualifiedName":"AudioMotionAnalyzer.onResize","identUtf16":{"start":{"lineNumber":246,"utf16Col":8},"end":{"lineNumber":246,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":246,"utf16Col":8},"end":{"lineNumber":256,"utf16Col":3}}},{"name":"unlockContext","kind":"function","identStart":10664,"identEnd":10677,"extentStart":10664,"extentEnd":10815,"fullyQualifiedName":"AudioMotionAnalyzer.unlockContext","identUtf16":{"start":{"lineNumber":291,"utf16Col":8},"end":{"lineNumber":291,"utf16Col":21}},"extentUtf16":{"start":{"lineNumber":291,"utf16Col":8},"end":{"lineNumber":295,"utf16Col":3}}},{"name":"alphaBars","kind":"method","identStart":11703,"identEnd":11712,"extentStart":11699,"extentEnd":11745,"fullyQualifiedName":"AudioMotionAnalyzer.alphaBars","identUtf16":{"start":{"lineNumber":326,"utf16Col":5},"end":{"lineNumber":326,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":326,"utf16Col":1},"end":{"lineNumber":328,"utf16Col":2}}},{"name":"alphaBars","kind":"method","identStart":11751,"identEnd":11760,"extentStart":11747,"extentEnd":11824,"fullyQualifiedName":"AudioMotionAnalyzer.alphaBars","identUtf16":{"start":{"lineNumber":329,"utf16Col":5},"end":{"lineNumber":329,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":329,"utf16Col":1},"end":{"lineNumber":332,"utf16Col":2}}},{"name":"ansiBands","kind":"method","identStart":11831,"identEnd":11840,"extentStart":11827,"extentEnd":11873,"fullyQualifiedName":"AudioMotionAnalyzer.ansiBands","identUtf16":{"start":{"lineNumber":334,"utf16Col":5},"end":{"lineNumber":334,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":334,"utf16Col":1},"end":{"lineNumber":336,"utf16Col":2}}},{"name":"ansiBands","kind":"method","identStart":11879,"identEnd":11888,"extentStart":11875,"extentEnd":11952,"fullyQualifiedName":"AudioMotionAnalyzer.ansiBands","identUtf16":{"start":{"lineNumber":337,"utf16Col":5},"end":{"lineNumber":337,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":337,"utf16Col":1},"end":{"lineNumber":340,"utf16Col":2}}},{"name":"barSpace","kind":"method","identStart":11959,"identEnd":11967,"extentStart":11955,"extentEnd":11999,"fullyQualifiedName":"AudioMotionAnalyzer.barSpace","identUtf16":{"start":{"lineNumber":342,"utf16Col":5},"end":{"lineNumber":342,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":342,"utf16Col":1},"end":{"lineNumber":344,"utf16Col":2}}},{"name":"barSpace","kind":"method","identStart":12005,"identEnd":12013,"extentStart":12001,"extentEnd":12079,"fullyQualifiedName":"AudioMotionAnalyzer.barSpace","identUtf16":{"start":{"lineNumber":345,"utf16Col":5},"end":{"lineNumber":345,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":345,"utf16Col":1},"end":{"lineNumber":348,"utf16Col":2}}},{"name":"channelLayout","kind":"method","identStart":12086,"identEnd":12099,"extentStart":12082,"extentEnd":12131,"fullyQualifiedName":"AudioMotionAnalyzer.channelLayout","identUtf16":{"start":{"lineNumber":350,"utf16Col":5},"end":{"lineNumber":350,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":350,"utf16Col":1},"end":{"lineNumber":352,"utf16Col":2}}},{"name":"channelLayout","kind":"method","identStart":12137,"identEnd":12150,"extentStart":12133,"extentEnd":12689,"fullyQualifiedName":"AudioMotionAnalyzer.channelLayout","identUtf16":{"start":{"lineNumber":353,"utf16Col":5},"end":{"lineNumber":353,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":353,"utf16Col":1},"end":{"lineNumber":365,"utf16Col":2}}},{"name":"colorMode","kind":"method","identStart":12696,"identEnd":12705,"extentStart":12692,"extentEnd":12738,"fullyQualifiedName":"AudioMotionAnalyzer.colorMode","identUtf16":{"start":{"lineNumber":367,"utf16Col":5},"end":{"lineNumber":367,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":367,"utf16Col":1},"end":{"lineNumber":369,"utf16Col":2}}},{"name":"colorMode","kind":"method","identStart":12744,"identEnd":12753,"extentStart":12740,"extentEnd":12868,"fullyQualifiedName":"AudioMotionAnalyzer.colorMode","identUtf16":{"start":{"lineNumber":370,"utf16Col":5},"end":{"lineNumber":370,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":370,"utf16Col":1},"end":{"lineNumber":372,"utf16Col":2}}},{"name":"fftSize","kind":"method","identStart":12875,"identEnd":12882,"extentStart":12871,"extentEnd":12925,"fullyQualifiedName":"AudioMotionAnalyzer.fftSize","identUtf16":{"start":{"lineNumber":374,"utf16Col":5},"end":{"lineNumber":374,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":374,"utf16Col":1},"end":{"lineNumber":376,"utf16Col":2}}},{"name":"fftSize","kind":"method","identStart":12931,"identEnd":12938,"extentStart":12927,"extentEnd":13177,"fullyQualifiedName":"AudioMotionAnalyzer.fftSize","identUtf16":{"start":{"lineNumber":377,"utf16Col":5},"end":{"lineNumber":377,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":377,"utf16Col":1},"end":{"lineNumber":383,"utf16Col":2}}},{"name":"frequencyScale","kind":"method","identStart":13184,"identEnd":13198,"extentStart":13180,"extentEnd":13236,"fullyQualifiedName":"AudioMotionAnalyzer.frequencyScale","identUtf16":{"start":{"lineNumber":385,"utf16Col":5},"end":{"lineNumber":385,"utf16Col":19}},"extentUtf16":{"start":{"lineNumber":385,"utf16Col":1},"end":{"lineNumber":387,"utf16Col":2}}},{"name":"frequencyScale","kind":"method","identStart":13242,"identEnd":13256,"extentStart":13238,"extentEnd":13394,"fullyQualifiedName":"AudioMotionAnalyzer.frequencyScale","identUtf16":{"start":{"lineNumber":388,"utf16Col":5},"end":{"lineNumber":388,"utf16Col":19}},"extentUtf16":{"start":{"lineNumber":388,"utf16Col":1},"end":{"lineNumber":391,"utf16Col":2}}},{"name":"gradient","kind":"method","identStart":13401,"identEnd":13409,"extentStart":13397,"extentEnd":13449,"fullyQualifiedName":"AudioMotionAnalyzer.gradient","identUtf16":{"start":{"lineNumber":393,"utf16Col":5},"end":{"lineNumber":393,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":393,"utf16Col":1},"end":{"lineNumber":395,"utf16Col":2}}},{"name":"gradient","kind":"method","identStart":13455,"identEnd":13463,"extentStart":13451,"extentEnd":13507,"fullyQualifiedName":"AudioMotionAnalyzer.gradient","identUtf16":{"start":{"lineNumber":396,"utf16Col":5},"end":{"lineNumber":396,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":396,"utf16Col":1},"end":{"lineNumber":398,"utf16Col":2}}},{"name":"gradientLeft","kind":"method","identStart":13514,"identEnd":13526,"extentStart":13510,"extentEnd":13566,"fullyQualifiedName":"AudioMotionAnalyzer.gradientLeft","identUtf16":{"start":{"lineNumber":400,"utf16Col":5},"end":{"lineNumber":400,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":400,"utf16Col":1},"end":{"lineNumber":402,"utf16Col":2}}},{"name":"gradientLeft","kind":"method","identStart":13572,"identEnd":13584,"extentStart":13568,"extentEnd":13631,"fullyQualifiedName":"AudioMotionAnalyzer.gradientLeft","identUtf16":{"start":{"lineNumber":403,"utf16Col":5},"end":{"lineNumber":403,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":403,"utf16Col":1},"end":{"lineNumber":405,"utf16Col":2}}},{"name":"gradientRight","kind":"method","identStart":13638,"identEnd":13651,"extentStart":13634,"extentEnd":13691,"fullyQualifiedName":"AudioMotionAnalyzer.gradientRight","identUtf16":{"start":{"lineNumber":407,"utf16Col":5},"end":{"lineNumber":407,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":407,"utf16Col":1},"end":{"lineNumber":409,"utf16Col":2}}},{"name":"gradientRight","kind":"method","identStart":13697,"identEnd":13710,"extentStart":13693,"extentEnd":13757,"fullyQualifiedName":"AudioMotionAnalyzer.gradientRight","identUtf16":{"start":{"lineNumber":410,"utf16Col":5},"end":{"lineNumber":410,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":410,"utf16Col":1},"end":{"lineNumber":412,"utf16Col":2}}},{"name":"height","kind":"method","identStart":13764,"identEnd":13770,"extentStart":13760,"extentEnd":13800,"fullyQualifiedName":"AudioMotionAnalyzer.height","identUtf16":{"start":{"lineNumber":414,"utf16Col":5},"end":{"lineNumber":414,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":414,"utf16Col":1},"end":{"lineNumber":416,"utf16Col":2}}},{"name":"height","kind":"method","identStart":13806,"identEnd":13812,"extentStart":13802,"extentEnd":13876,"fullyQualifiedName":"AudioMotionAnalyzer.height","identUtf16":{"start":{"lineNumber":417,"utf16Col":5},"end":{"lineNumber":417,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":417,"utf16Col":1},"end":{"lineNumber":420,"utf16Col":2}}},{"name":"ledBars","kind":"method","identStart":13883,"identEnd":13890,"extentStart":13879,"extentEnd":13922,"fullyQualifiedName":"AudioMotionAnalyzer.ledBars","identUtf16":{"start":{"lineNumber":422,"utf16Col":5},"end":{"lineNumber":422,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":422,"utf16Col":1},"end":{"lineNumber":424,"utf16Col":2}}},{"name":"ledBars","kind":"method","identStart":13928,"identEnd":13935,"extentStart":13924,"extentEnd":13998,"fullyQualifiedName":"AudioMotionAnalyzer.ledBars","identUtf16":{"start":{"lineNumber":425,"utf16Col":5},"end":{"lineNumber":425,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":425,"utf16Col":1},"end":{"lineNumber":428,"utf16Col":2}}},{"name":"linearAmplitude","kind":"method","identStart":14005,"identEnd":14020,"extentStart":14001,"extentEnd":14059,"fullyQualifiedName":"AudioMotionAnalyzer.linearAmplitude","identUtf16":{"start":{"lineNumber":430,"utf16Col":5},"end":{"lineNumber":430,"utf16Col":20}},"extentUtf16":{"start":{"lineNumber":430,"utf16Col":1},"end":{"lineNumber":432,"utf16Col":2}}},{"name":"linearAmplitude","kind":"method","identStart":14065,"identEnd":14080,"extentStart":14061,"extentEnd":14130,"fullyQualifiedName":"AudioMotionAnalyzer.linearAmplitude","identUtf16":{"start":{"lineNumber":433,"utf16Col":5},"end":{"lineNumber":433,"utf16Col":20}},"extentUtf16":{"start":{"lineNumber":433,"utf16Col":1},"end":{"lineNumber":435,"utf16Col":2}}},{"name":"linearBoost","kind":"method","identStart":14137,"identEnd":14148,"extentStart":14133,"extentEnd":14183,"fullyQualifiedName":"AudioMotionAnalyzer.linearBoost","identUtf16":{"start":{"lineNumber":437,"utf16Col":5},"end":{"lineNumber":437,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":437,"utf16Col":1},"end":{"lineNumber":439,"utf16Col":2}}},{"name":"linearBoost","kind":"method","identStart":14189,"identEnd":14200,"extentStart":14185,"extentEnd":14261,"fullyQualifiedName":"AudioMotionAnalyzer.linearBoost","identUtf16":{"start":{"lineNumber":440,"utf16Col":5},"end":{"lineNumber":440,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":440,"utf16Col":1},"end":{"lineNumber":442,"utf16Col":2}}},{"name":"lineWidth","kind":"method","identStart":14268,"identEnd":14277,"extentStart":14264,"extentEnd":14310,"fullyQualifiedName":"AudioMotionAnalyzer.lineWidth","identUtf16":{"start":{"lineNumber":444,"utf16Col":5},"end":{"lineNumber":444,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":444,"utf16Col":1},"end":{"lineNumber":446,"utf16Col":2}}},{"name":"lineWidth","kind":"method","identStart":14316,"identEnd":14325,"extentStart":14312,"extentEnd":14372,"fullyQualifiedName":"AudioMotionAnalyzer.lineWidth","identUtf16":{"start":{"lineNumber":447,"utf16Col":5},"end":{"lineNumber":447,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":447,"utf16Col":1},"end":{"lineNumber":449,"utf16Col":2}}},{"name":"loRes","kind":"method","identStart":14379,"identEnd":14384,"extentStart":14375,"extentEnd":14413,"fullyQualifiedName":"AudioMotionAnalyzer.loRes","identUtf16":{"start":{"lineNumber":451,"utf16Col":5},"end":{"lineNumber":451,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":451,"utf16Col":1},"end":{"lineNumber":453,"utf16Col":2}}},{"name":"loRes","kind":"method","identStart":14419,"identEnd":14424,"extentStart":14415,"extentEnd":14499,"fullyQualifiedName":"AudioMotionAnalyzer.loRes","identUtf16":{"start":{"lineNumber":454,"utf16Col":5},"end":{"lineNumber":454,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":454,"utf16Col":1},"end":{"lineNumber":457,"utf16Col":2}}},{"name":"lumiBars","kind":"method","identStart":14506,"identEnd":14514,"extentStart":14502,"extentEnd":14546,"fullyQualifiedName":"AudioMotionAnalyzer.lumiBars","identUtf16":{"start":{"lineNumber":459,"utf16Col":5},"end":{"lineNumber":459,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":459,"utf16Col":1},"end":{"lineNumber":461,"utf16Col":2}}},{"name":"lumiBars","kind":"method","identStart":14552,"identEnd":14560,"extentStart":14548,"extentEnd":14643,"fullyQualifiedName":"AudioMotionAnalyzer.lumiBars","identUtf16":{"start":{"lineNumber":462,"utf16Col":5},"end":{"lineNumber":462,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":462,"utf16Col":1},"end":{"lineNumber":466,"utf16Col":2}}},{"name":"maxDecibels","kind":"method","identStart":14650,"identEnd":14661,"extentStart":14646,"extentEnd":14708,"fullyQualifiedName":"AudioMotionAnalyzer.maxDecibels","identUtf16":{"start":{"lineNumber":468,"utf16Col":5},"end":{"lineNumber":468,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":468,"utf16Col":1},"end":{"lineNumber":470,"utf16Col":2}}},{"name":"maxDecibels","kind":"method","identStart":14714,"identEnd":14725,"extentStart":14710,"extentEnd":14810,"fullyQualifiedName":"AudioMotionAnalyzer.maxDecibels","identUtf16":{"start":{"lineNumber":471,"utf16Col":5},"end":{"lineNumber":471,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":471,"utf16Col":1},"end":{"lineNumber":474,"utf16Col":2}}},{"name":"maxFPS","kind":"method","identStart":14817,"identEnd":14823,"extentStart":14813,"extentEnd":14853,"fullyQualifiedName":"AudioMotionAnalyzer.maxFPS","identUtf16":{"start":{"lineNumber":476,"utf16Col":5},"end":{"lineNumber":476,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":476,"utf16Col":1},"end":{"lineNumber":478,"utf16Col":2}}},{"name":"maxFPS","kind":"method","identStart":14859,"identEnd":14865,"extentStart":14855,"extentEnd":14925,"fullyQualifiedName":"AudioMotionAnalyzer.maxFPS","identUtf16":{"start":{"lineNumber":479,"utf16Col":5},"end":{"lineNumber":479,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":479,"utf16Col":1},"end":{"lineNumber":481,"utf16Col":2}}},{"name":"maxFreq","kind":"method","identStart":14932,"identEnd":14939,"extentStart":14928,"extentEnd":14970,"fullyQualifiedName":"AudioMotionAnalyzer.maxFreq","identUtf16":{"start":{"lineNumber":483,"utf16Col":5},"end":{"lineNumber":483,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":483,"utf16Col":1},"end":{"lineNumber":485,"utf16Col":2}}},{"name":"maxFreq","kind":"method","identStart":14976,"identEnd":14983,"extentStart":14972,"extentEnd":15174,"fullyQualifiedName":"AudioMotionAnalyzer.maxFreq","identUtf16":{"start":{"lineNumber":486,"utf16Col":5},"end":{"lineNumber":486,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":486,"utf16Col":1},"end":{"lineNumber":493,"utf16Col":2}}},{"name":"minDecibels","kind":"method","identStart":15181,"identEnd":15192,"extentStart":15177,"extentEnd":15239,"fullyQualifiedName":"AudioMotionAnalyzer.minDecibels","identUtf16":{"start":{"lineNumber":495,"utf16Col":5},"end":{"lineNumber":495,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":495,"utf16Col":1},"end":{"lineNumber":497,"utf16Col":2}}},{"name":"minDecibels","kind":"method","identStart":15245,"identEnd":15256,"extentStart":15241,"extentEnd":15341,"fullyQualifiedName":"AudioMotionAnalyzer.minDecibels","identUtf16":{"start":{"lineNumber":498,"utf16Col":5},"end":{"lineNumber":498,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":498,"utf16Col":1},"end":{"lineNumber":501,"utf16Col":2}}},{"name":"minFreq","kind":"method","identStart":15348,"identEnd":15355,"extentStart":15344,"extentEnd":15386,"fullyQualifiedName":"AudioMotionAnalyzer.minFreq","identUtf16":{"start":{"lineNumber":503,"utf16Col":5},"end":{"lineNumber":503,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":503,"utf16Col":1},"end":{"lineNumber":505,"utf16Col":2}}},{"name":"minFreq","kind":"method","identStart":15392,"identEnd":15399,"extentStart":15388,"extentEnd":15549,"fullyQualifiedName":"AudioMotionAnalyzer.minFreq","identUtf16":{"start":{"lineNumber":506,"utf16Col":5},"end":{"lineNumber":506,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":506,"utf16Col":1},"end":{"lineNumber":513,"utf16Col":2}}},{"name":"mirror","kind":"method","identStart":15556,"identEnd":15562,"extentStart":15552,"extentEnd":15592,"fullyQualifiedName":"AudioMotionAnalyzer.mirror","identUtf16":{"start":{"lineNumber":515,"utf16Col":5},"end":{"lineNumber":515,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":515,"utf16Col":1},"end":{"lineNumber":517,"utf16Col":2}}},{"name":"mirror","kind":"method","identStart":15598,"identEnd":15604,"extentStart":15594,"extentEnd":15725,"fullyQualifiedName":"AudioMotionAnalyzer.mirror","identUtf16":{"start":{"lineNumber":518,"utf16Col":5},"end":{"lineNumber":518,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":518,"utf16Col":1},"end":{"lineNumber":522,"utf16Col":2}}},{"name":"mode","kind":"method","identStart":15732,"identEnd":15736,"extentStart":15728,"extentEnd":15764,"fullyQualifiedName":"AudioMotionAnalyzer.mode","identUtf16":{"start":{"lineNumber":524,"utf16Col":5},"end":{"lineNumber":524,"utf16Col":9}},"extentUtf16":{"start":{"lineNumber":524,"utf16Col":1},"end":{"lineNumber":526,"utf16Col":2}}},{"name":"mode","kind":"method","identStart":15770,"identEnd":15774,"extentStart":15766,"extentEnd":15995,"fullyQualifiedName":"AudioMotionAnalyzer.mode","identUtf16":{"start":{"lineNumber":527,"utf16Col":5},"end":{"lineNumber":527,"utf16Col":9}},"extentUtf16":{"start":{"lineNumber":527,"utf16Col":1},"end":{"lineNumber":536,"utf16Col":2}}},{"name":"noteLabels","kind":"method","identStart":16002,"identEnd":16012,"extentStart":15998,"extentEnd":16046,"fullyQualifiedName":"AudioMotionAnalyzer.noteLabels","identUtf16":{"start":{"lineNumber":538,"utf16Col":5},"end":{"lineNumber":538,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":538,"utf16Col":1},"end":{"lineNumber":540,"utf16Col":2}}},{"name":"noteLabels","kind":"method","identStart":16052,"identEnd":16062,"extentStart":16048,"extentEnd":16131,"fullyQualifiedName":"AudioMotionAnalyzer.noteLabels","identUtf16":{"start":{"lineNumber":541,"utf16Col":5},"end":{"lineNumber":541,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":541,"utf16Col":1},"end":{"lineNumber":544,"utf16Col":2}}},{"name":"outlineBars","kind":"method","identStart":16138,"identEnd":16149,"extentStart":16134,"extentEnd":16184,"fullyQualifiedName":"AudioMotionAnalyzer.outlineBars","identUtf16":{"start":{"lineNumber":546,"utf16Col":5},"end":{"lineNumber":546,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":546,"utf16Col":1},"end":{"lineNumber":548,"utf16Col":2}}},{"name":"outlineBars","kind":"method","identStart":16190,"identEnd":16201,"extentStart":16186,"extentEnd":16267,"fullyQualifiedName":"AudioMotionAnalyzer.outlineBars","identUtf16":{"start":{"lineNumber":549,"utf16Col":5},"end":{"lineNumber":549,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":549,"utf16Col":1},"end":{"lineNumber":552,"utf16Col":2}}},{"name":"peakLine","kind":"method","identStart":16274,"identEnd":16282,"extentStart":16270,"extentEnd":16314,"fullyQualifiedName":"AudioMotionAnalyzer.peakLine","identUtf16":{"start":{"lineNumber":554,"utf16Col":5},"end":{"lineNumber":554,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":554,"utf16Col":1},"end":{"lineNumber":556,"utf16Col":2}}},{"name":"peakLine","kind":"method","identStart":16320,"identEnd":16328,"extentStart":16316,"extentEnd":16371,"fullyQualifiedName":"AudioMotionAnalyzer.peakLine","identUtf16":{"start":{"lineNumber":557,"utf16Col":5},"end":{"lineNumber":557,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":557,"utf16Col":1},"end":{"lineNumber":559,"utf16Col":2}}},{"name":"radial","kind":"method","identStart":16378,"identEnd":16384,"extentStart":16374,"extentEnd":16414,"fullyQualifiedName":"AudioMotionAnalyzer.radial","identUtf16":{"start":{"lineNumber":561,"utf16Col":5},"end":{"lineNumber":561,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":561,"utf16Col":1},"end":{"lineNumber":563,"utf16Col":2}}},{"name":"radial","kind":"method","identStart":16420,"identEnd":16426,"extentStart":16416,"extentEnd":16507,"fullyQualifiedName":"AudioMotionAnalyzer.radial","identUtf16":{"start":{"lineNumber":564,"utf16Col":5},"end":{"lineNumber":564,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":564,"utf16Col":1},"end":{"lineNumber":568,"utf16Col":2}}},{"name":"reflexRatio","kind":"method","identStart":16514,"identEnd":16525,"extentStart":16510,"extentEnd":16560,"fullyQualifiedName":"AudioMotionAnalyzer.reflexRatio","identUtf16":{"start":{"lineNumber":570,"utf16Col":5},"end":{"lineNumber":570,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":570,"utf16Col":1},"end":{"lineNumber":572,"utf16Col":2}}},{"name":"reflexRatio","kind":"method","identStart":16566,"identEnd":16577,"extentStart":16562,"extentEnd":16790,"fullyQualifiedName":"AudioMotionAnalyzer.reflexRatio","identUtf16":{"start":{"lineNumber":573,"utf16Col":5},"end":{"lineNumber":573,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":573,"utf16Col":1},"end":{"lineNumber":582,"utf16Col":2}}},{"name":"roundBars","kind":"method","identStart":16797,"identEnd":16806,"extentStart":16793,"extentEnd":16839,"fullyQualifiedName":"AudioMotionAnalyzer.roundBars","identUtf16":{"start":{"lineNumber":584,"utf16Col":5},"end":{"lineNumber":584,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":584,"utf16Col":1},"end":{"lineNumber":586,"utf16Col":2}}},{"name":"roundBars","kind":"method","identStart":16845,"identEnd":16854,"extentStart":16841,"extentEnd":16918,"fullyQualifiedName":"AudioMotionAnalyzer.roundBars","identUtf16":{"start":{"lineNumber":587,"utf16Col":5},"end":{"lineNumber":587,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":587,"utf16Col":1},"end":{"lineNumber":590,"utf16Col":2}}},{"name":"smoothing","kind":"method","identStart":16925,"identEnd":16934,"extentStart":16921,"extentEnd":16991,"fullyQualifiedName":"AudioMotionAnalyzer.smoothing","identUtf16":{"start":{"lineNumber":592,"utf16Col":5},"end":{"lineNumber":592,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":592,"utf16Col":1},"end":{"lineNumber":594,"utf16Col":2}}},{"name":"smoothing","kind":"method","identStart":16997,"identEnd":17006,"extentStart":16993,"extentEnd":17101,"fullyQualifiedName":"AudioMotionAnalyzer.smoothing","identUtf16":{"start":{"lineNumber":595,"utf16Col":5},"end":{"lineNumber":595,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":595,"utf16Col":1},"end":{"lineNumber":598,"utf16Col":2}}},{"name":"spinSpeed","kind":"method","identStart":17108,"identEnd":17117,"extentStart":17104,"extentEnd":17150,"fullyQualifiedName":"AudioMotionAnalyzer.spinSpeed","identUtf16":{"start":{"lineNumber":600,"utf16Col":5},"end":{"lineNumber":600,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":600,"utf16Col":1},"end":{"lineNumber":602,"utf16Col":2}}},{"name":"spinSpeed","kind":"method","identStart":17156,"identEnd":17165,"extentStart":17152,"extentEnd":17355,"fullyQualifiedName":"AudioMotionAnalyzer.spinSpeed","identUtf16":{"start":{"lineNumber":603,"utf16Col":5},"end":{"lineNumber":603,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":603,"utf16Col":1},"end":{"lineNumber":608,"utf16Col":2}}},{"name":"splitGradient","kind":"method","identStart":17362,"identEnd":17375,"extentStart":17358,"extentEnd":17412,"fullyQualifiedName":"AudioMotionAnalyzer.splitGradient","identUtf16":{"start":{"lineNumber":610,"utf16Col":5},"end":{"lineNumber":610,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":610,"utf16Col":1},"end":{"lineNumber":612,"utf16Col":2}}},{"name":"splitGradient","kind":"method","identStart":17418,"identEnd":17431,"extentStart":17414,"extentEnd":17499,"fullyQualifiedName":"AudioMotionAnalyzer.splitGradient","identUtf16":{"start":{"lineNumber":613,"utf16Col":5},"end":{"lineNumber":613,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":613,"utf16Col":1},"end":{"lineNumber":616,"utf16Col":2}}},{"name":"stereo","kind":"method","identStart":17506,"identEnd":17512,"extentStart":17502,"extentEnd":17604,"fullyQualifiedName":"AudioMotionAnalyzer.stereo","identUtf16":{"start":{"lineNumber":618,"utf16Col":5},"end":{"lineNumber":618,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":618,"utf16Col":1},"end":{"lineNumber":621,"utf16Col":2}}},{"name":"stereo","kind":"method","identStart":17610,"identEnd":17616,"extentStart":17606,"extentEnd":17738,"fullyQualifiedName":"AudioMotionAnalyzer.stereo","identUtf16":{"start":{"lineNumber":622,"utf16Col":5},"end":{"lineNumber":622,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":622,"utf16Col":1},"end":{"lineNumber":625,"utf16Col":2}}},{"name":"trueLeds","kind":"method","identStart":17745,"identEnd":17753,"extentStart":17741,"extentEnd":17785,"fullyQualifiedName":"AudioMotionAnalyzer.trueLeds","identUtf16":{"start":{"lineNumber":627,"utf16Col":5},"end":{"lineNumber":627,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":627,"utf16Col":1},"end":{"lineNumber":629,"utf16Col":2}}},{"name":"trueLeds","kind":"method","identStart":17791,"identEnd":17799,"extentStart":17787,"extentEnd":17842,"fullyQualifiedName":"AudioMotionAnalyzer.trueLeds","identUtf16":{"start":{"lineNumber":630,"utf16Col":5},"end":{"lineNumber":630,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":630,"utf16Col":1},"end":{"lineNumber":632,"utf16Col":2}}},{"name":"volume","kind":"method","identStart":17849,"identEnd":17855,"extentStart":17845,"extentEnd":17896,"fullyQualifiedName":"AudioMotionAnalyzer.volume","identUtf16":{"start":{"lineNumber":634,"utf16Col":5},"end":{"lineNumber":634,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":634,"utf16Col":1},"end":{"lineNumber":636,"utf16Col":2}}},{"name":"volume","kind":"method","identStart":17902,"identEnd":17908,"extentStart":17898,"extentEnd":17957,"fullyQualifiedName":"AudioMotionAnalyzer.volume","identUtf16":{"start":{"lineNumber":637,"utf16Col":5},"end":{"lineNumber":637,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":637,"utf16Col":1},"end":{"lineNumber":639,"utf16Col":2}}},{"name":"weightingFilter","kind":"method","identStart":17964,"identEnd":17979,"extentStart":17960,"extentEnd":18018,"fullyQualifiedName":"AudioMotionAnalyzer.weightingFilter","identUtf16":{"start":{"lineNumber":641,"utf16Col":5},"end":{"lineNumber":641,"utf16Col":20}},"extentUtf16":{"start":{"lineNumber":641,"utf16Col":1},"end":{"lineNumber":643,"utf16Col":2}}},{"name":"weightingFilter","kind":"method","identStart":18024,"identEnd":18039,"extentStart":18020,"extentEnd":18190,"fullyQualifiedName":"AudioMotionAnalyzer.weightingFilter","identUtf16":{"start":{"lineNumber":644,"utf16Col":5},"end":{"lineNumber":644,"utf16Col":20}},"extentUtf16":{"start":{"lineNumber":644,"utf16Col":1},"end":{"lineNumber":646,"utf16Col":2}}},{"name":"width","kind":"method","identStart":18197,"identEnd":18202,"extentStart":18193,"extentEnd":18231,"fullyQualifiedName":"AudioMotionAnalyzer.width","identUtf16":{"start":{"lineNumber":648,"utf16Col":5},"end":{"lineNumber":648,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":648,"utf16Col":1},"end":{"lineNumber":650,"utf16Col":2}}},{"name":"width","kind":"method","identStart":18237,"identEnd":18242,"extentStart":18233,"extentEnd":18305,"fullyQualifiedName":"AudioMotionAnalyzer.width","identUtf16":{"start":{"lineNumber":651,"utf16Col":5},"end":{"lineNumber":651,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":651,"utf16Col":1},"end":{"lineNumber":654,"utf16Col":2}}},{"name":"audioCtx","kind":"method","identStart":18338,"identEnd":18346,"extentStart":18334,"extentEnd":18383,"fullyQualifiedName":"AudioMotionAnalyzer.audioCtx","identUtf16":{"start":{"lineNumber":658,"utf16Col":5},"end":{"lineNumber":658,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":658,"utf16Col":1},"end":{"lineNumber":660,"utf16Col":2}}},{"name":"canvas","kind":"method","identStart":18389,"identEnd":18395,"extentStart":18385,"extentEnd":18429,"fullyQualifiedName":"AudioMotionAnalyzer.canvas","identUtf16":{"start":{"lineNumber":661,"utf16Col":5},"end":{"lineNumber":661,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":661,"utf16Col":1},"end":{"lineNumber":663,"utf16Col":2}}},{"name":"canvasCtx","kind":"method","identStart":18435,"identEnd":18444,"extentStart":18431,"extentEnd":18471,"fullyQualifiedName":"AudioMotionAnalyzer.canvasCtx","identUtf16":{"start":{"lineNumber":664,"utf16Col":5},"end":{"lineNumber":664,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":664,"utf16Col":1},"end":{"lineNumber":666,"utf16Col":2}}},{"name":"connectedSources","kind":"method","identStart":18477,"identEnd":18493,"extentStart":18473,"extentEnd":18524,"fullyQualifiedName":"AudioMotionAnalyzer.connectedSources","identUtf16":{"start":{"lineNumber":667,"utf16Col":5},"end":{"lineNumber":667,"utf16Col":21}},"extentUtf16":{"start":{"lineNumber":667,"utf16Col":1},"end":{"lineNumber":669,"utf16Col":2}}},{"name":"connectedTo","kind":"method","identStart":18530,"identEnd":18541,"extentStart":18526,"extentEnd":18573,"fullyQualifiedName":"AudioMotionAnalyzer.connectedTo","identUtf16":{"start":{"lineNumber":670,"utf16Col":5},"end":{"lineNumber":670,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":670,"utf16Col":1},"end":{"lineNumber":672,"utf16Col":2}}},{"name":"fps","kind":"method","identStart":18579,"identEnd":18582,"extentStart":18575,"extentEnd":18609,"fullyQualifiedName":"AudioMotionAnalyzer.fps","identUtf16":{"start":{"lineNumber":673,"utf16Col":5},"end":{"lineNumber":673,"utf16Col":8}},"extentUtf16":{"start":{"lineNumber":673,"utf16Col":1},"end":{"lineNumber":675,"utf16Col":2}}},{"name":"fsHeight","kind":"method","identStart":18615,"identEnd":18623,"extentStart":18611,"extentEnd":18655,"fullyQualifiedName":"AudioMotionAnalyzer.fsHeight","identUtf16":{"start":{"lineNumber":676,"utf16Col":5},"end":{"lineNumber":676,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":676,"utf16Col":1},"end":{"lineNumber":678,"utf16Col":2}}},{"name":"fsWidth","kind":"method","identStart":18661,"identEnd":18668,"extentStart":18657,"extentEnd":18699,"fullyQualifiedName":"AudioMotionAnalyzer.fsWidth","identUtf16":{"start":{"lineNumber":679,"utf16Col":5},"end":{"lineNumber":679,"utf16Col":12}},"extentUtf16":{"start":{"lineNumber":679,"utf16Col":1},"end":{"lineNumber":681,"utf16Col":2}}},{"name":"isAlphaBars","kind":"method","identStart":18705,"identEnd":18716,"extentStart":18701,"extentEnd":18751,"fullyQualifiedName":"AudioMotionAnalyzer.isAlphaBars","identUtf16":{"start":{"lineNumber":682,"utf16Col":5},"end":{"lineNumber":682,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":682,"utf16Col":1},"end":{"lineNumber":684,"utf16Col":2}}},{"name":"isBandsMode","kind":"method","identStart":18757,"identEnd":18768,"extentStart":18753,"extentEnd":18803,"fullyQualifiedName":"AudioMotionAnalyzer.isBandsMode","identUtf16":{"start":{"lineNumber":685,"utf16Col":5},"end":{"lineNumber":685,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":685,"utf16Col":1},"end":{"lineNumber":687,"utf16Col":2}}},{"name":"isDestroyed","kind":"method","identStart":18809,"identEnd":18820,"extentStart":18805,"extentEnd":18853,"fullyQualifiedName":"AudioMotionAnalyzer.isDestroyed","identUtf16":{"start":{"lineNumber":688,"utf16Col":5},"end":{"lineNumber":688,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":688,"utf16Col":1},"end":{"lineNumber":690,"utf16Col":2}}},{"name":"isFullscreen","kind":"method","identStart":18859,"identEnd":18871,"extentStart":18855,"extentEnd":18984,"fullyQualifiedName":"AudioMotionAnalyzer.isFullscreen","identUtf16":{"start":{"lineNumber":691,"utf16Col":5},"end":{"lineNumber":691,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":691,"utf16Col":1},"end":{"lineNumber":693,"utf16Col":2}}},{"name":"isLedBars","kind":"method","identStart":18990,"identEnd":18999,"extentStart":18986,"extentEnd":19033,"fullyQualifiedName":"AudioMotionAnalyzer.isLedBars","identUtf16":{"start":{"lineNumber":694,"utf16Col":5},"end":{"lineNumber":694,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":694,"utf16Col":1},"end":{"lineNumber":696,"utf16Col":2}}},{"name":"isLumiBars","kind":"method","identStart":19039,"identEnd":19049,"extentStart":19035,"extentEnd":19083,"fullyQualifiedName":"AudioMotionAnalyzer.isLumiBars","identUtf16":{"start":{"lineNumber":697,"utf16Col":5},"end":{"lineNumber":697,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":697,"utf16Col":1},"end":{"lineNumber":699,"utf16Col":2}}},{"name":"isOctaveBands","kind":"method","identStart":19089,"identEnd":19102,"extentStart":19085,"extentEnd":19139,"fullyQualifiedName":"AudioMotionAnalyzer.isOctaveBands","identUtf16":{"start":{"lineNumber":700,"utf16Col":5},"end":{"lineNumber":700,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":700,"utf16Col":1},"end":{"lineNumber":702,"utf16Col":2}}},{"name":"isOn","kind":"method","identStart":19145,"identEnd":19149,"extentStart":19141,"extentEnd":19181,"fullyQualifiedName":"AudioMotionAnalyzer.isOn","identUtf16":{"start":{"lineNumber":703,"utf16Col":5},"end":{"lineNumber":703,"utf16Col":9}},"extentUtf16":{"start":{"lineNumber":703,"utf16Col":1},"end":{"lineNumber":705,"utf16Col":2}}},{"name":"isOutlineBars","kind":"method","identStart":19187,"identEnd":19200,"extentStart":19183,"extentEnd":19237,"fullyQualifiedName":"AudioMotionAnalyzer.isOutlineBars","identUtf16":{"start":{"lineNumber":706,"utf16Col":5},"end":{"lineNumber":706,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":706,"utf16Col":1},"end":{"lineNumber":708,"utf16Col":2}}},{"name":"pixelRatio","kind":"method","identStart":19243,"identEnd":19253,"extentStart":19239,"extentEnd":19287,"fullyQualifiedName":"AudioMotionAnalyzer.pixelRatio","identUtf16":{"start":{"lineNumber":709,"utf16Col":5},"end":{"lineNumber":709,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":709,"utf16Col":1},"end":{"lineNumber":711,"utf16Col":2}}},{"name":"isRoundBars","kind":"method","identStart":19293,"identEnd":19304,"extentStart":19289,"extentEnd":19339,"fullyQualifiedName":"AudioMotionAnalyzer.isRoundBars","identUtf16":{"start":{"lineNumber":712,"utf16Col":5},"end":{"lineNumber":712,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":712,"utf16Col":1},"end":{"lineNumber":714,"utf16Col":2}}},{"name":"version","kind":"method","identStart":19352,"identEnd":19359,"extentStart":19341,"extentEnd":19384,"fullyQualifiedName":"AudioMotionAnalyzer.version","identUtf16":{"start":{"lineNumber":715,"utf16Col":12},"end":{"lineNumber":715,"utf16Col":19}},"extentUtf16":{"start":{"lineNumber":715,"utf16Col":1},"end":{"lineNumber":717,"utf16Col":2}}},{"name":"connectInput","kind":"method","identStart":19854,"identEnd":19866,"extentStart":19854,"extentEnd":20349,"fullyQualifiedName":"AudioMotionAnalyzer.connectInput","identUtf16":{"start":{"lineNumber":733,"utf16Col":1},"end":{"lineNumber":733,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":733,"utf16Col":1},"end":{"lineNumber":748,"utf16Col":2}}},{"name":"connectOutput","kind":"method","identStart":20539,"identEnd":20552,"extentStart":20539,"extentEnd":20994,"fullyQualifiedName":"AudioMotionAnalyzer.connectOutput","identUtf16":{"start":{"lineNumber":755,"utf16Col":1},"end":{"lineNumber":755,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":755,"utf16Col":1},"end":{"lineNumber":767,"utf16Col":2}}},{"name":"destroy","kind":"method","identStart":21029,"identEnd":21036,"extentStart":21029,"extentEnd":21860,"fullyQualifiedName":"AudioMotionAnalyzer.destroy","identUtf16":{"start":{"lineNumber":772,"utf16Col":1},"end":{"lineNumber":772,"utf16Col":8}},"extentUtf16":{"start":{"lineNumber":772,"utf16Col":1},"end":{"lineNumber":808,"utf16Col":2}}},{"name":"disconnectInput","kind":"method","identStart":22168,"identEnd":22183,"extentStart":22168,"extentEnd":22658,"fullyQualifiedName":"AudioMotionAnalyzer.disconnectInput","identUtf16":{"start":{"lineNumber":816,"utf16Col":1},"end":{"lineNumber":816,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":816,"utf16Col":1},"end":{"lineNumber":834,"utf16Col":2}}},{"name":"disconnectOutput","kind":"method","identStart":22837,"identEnd":22853,"extentStart":22837,"extentEnd":23341,"fullyQualifiedName":"AudioMotionAnalyzer.disconnectOutput","identUtf16":{"start":{"lineNumber":841,"utf16Col":1},"end":{"lineNumber":841,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":841,"utf16Col":1},"end":{"lineNumber":854,"utf16Col":2}}},{"name":"getBars","kind":"method","identStart":23413,"identEnd":23420,"extentStart":23413,"extentEnd":23574,"fullyQualifiedName":"AudioMotionAnalyzer.getBars","identUtf16":{"start":{"lineNumber":861,"utf16Col":1},"end":{"lineNumber":861,"utf16Col":8}},"extentUtf16":{"start":{"lineNumber":861,"utf16Col":1},"end":{"lineNumber":863,"utf16Col":2}}},{"name":"getEnergy","kind":"method","identStart":23931,"identEnd":23940,"extentStart":23931,"extentEnd":24870,"fullyQualifiedName":"AudioMotionAnalyzer.getEnergy","identUtf16":{"start":{"lineNumber":872,"utf16Col":1},"end":{"lineNumber":872,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":872,"utf16Col":1},"end":{"lineNumber":906,"utf16Col":2}}},{"name":"registerGradient","kind":"method","identStart":24972,"identEnd":24988,"extentStart":24972,"extentEnd":26545,"fullyQualifiedName":"AudioMotionAnalyzer.registerGradient","identUtf16":{"start":{"lineNumber":914,"utf16Col":1},"end":{"lineNumber":914,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":914,"utf16Col":1},"end":{"lineNumber":955,"utf16Col":2}}},{"name":"isInvalid","kind":"function","identStart":25430,"identEnd":25439,"extentStart":25430,"extentEnd":25482,"fullyQualifiedName":"AudioMotionAnalyzer.isInvalid","identUtf16":{"start":{"lineNumber":927,"utf16Col":5},"end":{"lineNumber":927,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":927,"utf16Col":5},"end":{"lineNumber":927,"utf16Col":57}}},{"name":"setCanvasSize","kind":"method","identStart":26679,"identEnd":26692,"extentStart":26679,"extentEnd":26778,"fullyQualifiedName":"AudioMotionAnalyzer.setCanvasSize","identUtf16":{"start":{"lineNumber":963,"utf16Col":1},"end":{"lineNumber":963,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":963,"utf16Col":1},"end":{"lineNumber":967,"utf16Col":2}}},{"name":"setFreqRange","kind":"method","identStart":26962,"identEnd":26974,"extentStart":26962,"extentEnd":27200,"fullyQualifiedName":"AudioMotionAnalyzer.setFreqRange","identUtf16":{"start":{"lineNumber":975,"utf16Col":1},"end":{"lineNumber":975,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":975,"utf16Col":1},"end":{"lineNumber":982,"utf16Col":2}}},{"name":"setLedParams","kind":"method","identStart":27388,"identEnd":27400,"extentStart":27388,"extentEnd":27787,"fullyQualifiedName":"AudioMotionAnalyzer.setLedParams","identUtf16":{"start":{"lineNumber":990,"utf16Col":1},"end":{"lineNumber":990,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":990,"utf16Col":1},"end":{"lineNumber":1002,"utf16Col":2}}},{"name":"setOptions","kind":"method","identStart":27891,"identEnd":27901,"extentStart":27891,"extentEnd":27946,"fullyQualifiedName":"AudioMotionAnalyzer.setOptions","identUtf16":{"start":{"lineNumber":1009,"utf16Col":1},"end":{"lineNumber":1009,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":1009,"utf16Col":1},"end":{"lineNumber":1011,"utf16Col":2}}},{"name":"setSensitivity","kind":"method","identStart":28095,"identEnd":28109,"extentStart":28095,"extentEnd":28277,"fullyQualifiedName":"AudioMotionAnalyzer.setSensitivity","identUtf16":{"start":{"lineNumber":1019,"utf16Col":1},"end":{"lineNumber":1019,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":1019,"utf16Col":1},"end":{"lineNumber":1024,"utf16Col":2}}},{"name":"start","kind":"method","identStart":28313,"identEnd":28318,"extentStart":28313,"extentEnd":28356,"fullyQualifiedName":"AudioMotionAnalyzer.start","identUtf16":{"start":{"lineNumber":1029,"utf16Col":1},"end":{"lineNumber":1029,"utf16Col":6}},"extentUtf16":{"start":{"lineNumber":1029,"utf16Col":1},"end":{"lineNumber":1031,"utf16Col":2}}},{"name":"stop","kind":"method","identStart":28391,"identEnd":28395,"extentStart":28391,"extentEnd":28434,"fullyQualifiedName":"AudioMotionAnalyzer.stop","identUtf16":{"start":{"lineNumber":1036,"utf16Col":1},"end":{"lineNumber":1036,"utf16Col":5}},"extentUtf16":{"start":{"lineNumber":1036,"utf16Col":1},"end":{"lineNumber":1038,"utf16Col":2}}},{"name":"toggleAnalyzer","kind":"method","identStart":28610,"identEnd":28624,"extentStart":28610,"extentEnd":29223,"fullyQualifiedName":"AudioMotionAnalyzer.toggleAnalyzer","identUtf16":{"start":{"lineNumber":1046,"utf16Col":1},"end":{"lineNumber":1046,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":1046,"utf16Col":1},"end":{"lineNumber":1065,"utf16Col":2}}},{"name":"toggleFullscreen","kind":"method","identStart":29272,"identEnd":29288,"extentStart":29272,"extentEnd":29688,"fullyQualifiedName":"AudioMotionAnalyzer.toggleFullscreen","identUtf16":{"start":{"lineNumber":1070,"utf16Col":1},"end":{"lineNumber":1070,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":1070,"utf16Col":1},"end":{"lineNumber":1086,"utf16Col":2}}},{"name":"_binToFreq","kind":"method","identStart":29951,"identEnd":29961,"extentStart":29951,"extentEnd":30057,"fullyQualifiedName":"AudioMotionAnalyzer._binToFreq","identUtf16":{"start":{"lineNumber":1099,"utf16Col":1},"end":{"lineNumber":1099,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":1099,"utf16Col":1},"end":{"lineNumber":1101,"utf16Col":2}}},{"name":"_calcBars","kind":"method","identStart":30157,"identEnd":30166,"extentStart":30157,"extentEnd":43304,"fullyQualifiedName":"AudioMotionAnalyzer._calcBars","identUtf16":{"start":{"lineNumber":1106,"utf16Col":1},"end":{"lineNumber":1106,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":1106,"utf16Col":1},"end":{"lineNumber":1466,"utf16Col":2}}},{"name":"barsPush","kind":"function","identStart":32616,"identEnd":32624,"extentStart":32616,"extentEnd":32695,"fullyQualifiedName":"AudioMotionAnalyzer.barsPush","identUtf16":{"start":{"lineNumber":1170,"utf16Col":8},"end":{"lineNumber":1170,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":1170,"utf16Col":8},"end":{"lineNumber":1170,"utf16Col":87}}},{"name":"calcRatio","kind":"function","identStart":33643,"identEnd":33652,"extentStart":33643,"extentEnd":33920,"fullyQualifiedName":"AudioMotionAnalyzer.calcRatio","identUtf16":{"start":{"lineNumber":1194,"utf16Col":8},"end":{"lineNumber":1194,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":1194,"utf16Col":8},"end":{"lineNumber":1201,"utf16Col":3}}},{"name":"roundSD","kind":"function","identStart":34156,"identEnd":34163,"extentStart":34156,"extentEnd":34284,"fullyQualifiedName":"AudioMotionAnalyzer.roundSD","identUtf16":{"start":{"lineNumber":1208,"utf16Col":9},"end":{"lineNumber":1208,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":1208,"utf16Col":9},"end":{"lineNumber":1208,"utf16Col":137}}},{"name":"nearestPreferred","kind":"function","identStart":34389,"identEnd":34405,"extentStart":34389,"extentEnd":35001,"fullyQualifiedName":"AudioMotionAnalyzer.nearestPreferred","identUtf16":{"start":{"lineNumber":1211,"utf16Col":9},"end":{"lineNumber":1211,"utf16Col":25}},"extentUtf16":{"start":{"lineNumber":1211,"utf16Col":9},"end":{"lineNumber":1225,"utf16Col":4}}},{"name":"invFreqScaling","kind":"function","identStart":37582,"identEnd":37596,"extentStart":37582,"extentEnd":37824,"fullyQualifiedName":"AudioMotionAnalyzer.invFreqScaling","identUtf16":{"start":{"lineNumber":1286,"utf16Col":9},"end":{"lineNumber":1286,"utf16Col":23}},"extentUtf16":{"start":{"lineNumber":1286,"utf16Col":9},"end":{"lineNumber":1295,"utf16Col":4}}},{"name":"_createScales","kind":"method","identStart":43381,"identEnd":43394,"extentStart":43381,"extentEnd":48494,"fullyQualifiedName":"AudioMotionAnalyzer._createScales","identUtf16":{"start":{"lineNumber":1471,"utf16Col":1},"end":{"lineNumber":1471,"utf16Col":14}},"extentUtf16":{"start":{"lineNumber":1471,"utf16Col":1},"end":{"lineNumber":1595,"utf16Col":2}}},{"name":"radialLabel","kind":"function","identStart":45367,"identEnd":45378,"extentStart":45367,"extentEnd":45768,"fullyQualifiedName":"AudioMotionAnalyzer.radialLabel","identUtf16":{"start":{"lineNumber":1518,"utf16Col":8},"end":{"lineNumber":1518,"utf16Col":19}},"extentUtf16":{"start":{"lineNumber":1518,"utf16Col":8},"end":{"lineNumber":1529,"utf16Col":3}}},{"name":"_draw","kind":"method","identStart":48595,"identEnd":48600,"extentStart":48595,"extentEnd":70739,"fullyQualifiedName":"AudioMotionAnalyzer._draw","identUtf16":{"start":{"lineNumber":1601,"utf16Col":1},"end":{"lineNumber":1601,"utf16Col":6}},"extentUtf16":{"start":{"lineNumber":1601,"utf16Col":1},"end":{"lineNumber":2235,"utf16Col":2}}},{"name":"doReflex","kind":"function","identStart":50560,"identEnd":50568,"extentStart":50560,"extentEnd":51417,"fullyQualifiedName":"AudioMotionAnalyzer.doReflex","identUtf16":{"start":{"lineNumber":1668,"utf16Col":8},"end":{"lineNumber":1668,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":1668,"utf16Col":8},"end":{"lineNumber":1693,"utf16Col":3}}},{"name":"drawScaleX","kind":"function","identStart":51453,"identEnd":51463,"extentStart":51453,"extentEnd":51843,"fullyQualifiedName":"AudioMotionAnalyzer.drawScaleX","identUtf16":{"start":{"lineNumber":1696,"utf16Col":8},"end":{"lineNumber":1696,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":1696,"utf16Col":8},"end":{"lineNumber":1709,"utf16Col":3}}},{"name":"drawScaleY","kind":"function","identStart":51879,"identEnd":51889,"extentStart":51879,"extentEnd":53288,"fullyQualifiedName":"AudioMotionAnalyzer.drawScaleY","identUtf16":{"start":{"lineNumber":1712,"utf16Col":8},"end":{"lineNumber":1712,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":1712,"utf16Col":8},"end":{"lineNumber":1752,"utf16Col":3}}},{"name":"weightingdB","kind":"function","identStart":53403,"identEnd":53414,"extentStart":53403,"extentEnd":54941,"fullyQualifiedName":"AudioMotionAnalyzer.weightingdB","identUtf16":{"start":{"lineNumber":1755,"utf16Col":8},"end":{"lineNumber":1755,"utf16Col":19}},"extentUtf16":{"start":{"lineNumber":1755,"utf16Col":8},"end":{"lineNumber":1790,"utf16Col":3}}},{"name":"linearTodB","kind":"function","identStart":53588,"identEnd":53598,"extentStart":53588,"extentEnd":53634,"fullyQualifiedName":"AudioMotionAnalyzer.linearTodB","identUtf16":{"start":{"lineNumber":1762,"utf16Col":6},"end":{"lineNumber":1762,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":1762,"utf16Col":6},"end":{"lineNumber":1762,"utf16Col":52}}},{"name":"strokeBar","kind":"function","identStart":54995,"identEnd":55004,"extentStart":54995,"extentEnd":55118,"fullyQualifiedName":"AudioMotionAnalyzer.strokeBar","identUtf16":{"start":{"lineNumber":1793,"utf16Col":8},"end":{"lineNumber":1793,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":1793,"utf16Col":8},"end":{"lineNumber":1798,"utf16Col":3}}},{"name":"strokeIf","kind":"function","identStart":55178,"identEnd":55186,"extentStart":55178,"extentEnd":55349,"fullyQualifiedName":"AudioMotionAnalyzer.strokeIf","identUtf16":{"start":{"lineNumber":1801,"utf16Col":8},"end":{"lineNumber":1801,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":1801,"utf16Col":8},"end":{"lineNumber":1808,"utf16Col":3}}},{"name":"getAngle","kind":"function","identStart":55436,"identEnd":55444,"extentStart":55436,"extentEnd":55511,"fullyQualifiedName":"AudioMotionAnalyzer.getAngle","identUtf16":{"start":{"lineNumber":1811,"utf16Col":8},"end":{"lineNumber":1811,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":1811,"utf16Col":8},"end":{"lineNumber":1811,"utf16Col":83}}},{"name":"radialXY","kind":"function","identStart":55581,"identEnd":55589,"extentStart":55581,"extentEnd":55773,"fullyQualifiedName":"AudioMotionAnalyzer.radialXY","identUtf16":{"start":{"lineNumber":1814,"utf16Col":8},"end":{"lineNumber":1814,"utf16Col":16}},"extentUtf16":{"start":{"lineNumber":1814,"utf16Col":8},"end":{"lineNumber":1818,"utf16Col":3}}},{"name":"radialPoly","kind":"function","identStart":55856,"identEnd":55866,"extentStart":55856,"extentEnd":56591,"fullyQualifiedName":"AudioMotionAnalyzer.radialPoly","identUtf16":{"start":{"lineNumber":1821,"utf16Col":8},"end":{"lineNumber":1821,"utf16Col":18}},"extentUtf16":{"start":{"lineNumber":1821,"utf16Col":8},"end":{"lineNumber":1837,"utf16Col":3}}},{"name":"ledPosY","kind":"function","identStart":56700,"identEnd":56707,"extentStart":56700,"extentEnd":56798,"fullyQualifiedName":"AudioMotionAnalyzer.ledPosY","identUtf16":{"start":{"lineNumber":1840,"utf16Col":8},"end":{"lineNumber":1840,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":1840,"utf16Col":8},"end":{"lineNumber":1840,"utf16Col":106}}},{"name":"updateEnergy","kind":"function","identStart":56840,"identEnd":56852,"extentStart":56840,"extentEnd":57144,"fullyQualifiedName":"AudioMotionAnalyzer.updateEnergy","identUtf16":{"start":{"lineNumber":1843,"utf16Col":8},"end":{"lineNumber":1843,"utf16Col":20}},"extentUtf16":{"start":{"lineNumber":1843,"utf16Col":8},"end":{"lineNumber":1854,"utf16Col":3}}},{"name":"updateFPS","kind":"function","identStart":57217,"identEnd":57226,"extentStart":57217,"extentEnd":57877,"fullyQualifiedName":"AudioMotionAnalyzer.updateFPS","identUtf16":{"start":{"lineNumber":1857,"utf16Col":8},"end":{"lineNumber":1857,"utf16Col":17}},"extentUtf16":{"start":{"lineNumber":1857,"utf16Col":8},"end":{"lineNumber":1875,"utf16Col":3}}},{"name":"interpolate","kind":"function","identStart":58664,"identEnd":58675,"extentStart":58664,"extentEnd":58868,"fullyQualifiedName":"AudioMotionAnalyzer.interpolate","identUtf16":{"start":{"lineNumber":1895,"utf16Col":9},"end":{"lineNumber":1895,"utf16Col":20}},"extentUtf16":{"start":{"lineNumber":1895,"utf16Col":9},"end":{"lineNumber":1898,"utf16Col":4}}},{"name":"setBarColor","kind":"function","identStart":58986,"identEnd":58997,"extentStart":58986,"extentEnd":59545,"fullyQualifiedName":"AudioMotionAnalyzer.setBarColor","identUtf16":{"start":{"lineNumber":1901,"utf16Col":9},"end":{"lineNumber":1901,"utf16Col":20}},"extentUtf16":{"start":{"lineNumber":1901,"utf16Col":9},"end":{"lineNumber":1911,"utf16Col":4}}},{"name":"_freqScaling","kind":"method","identStart":70812,"identEnd":70824,"extentStart":70812,"extentEnd":71101,"fullyQualifiedName":"AudioMotionAnalyzer._freqScaling","identUtf16":{"start":{"lineNumber":2240,"utf16Col":1},"end":{"lineNumber":2240,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":2240,"utf16Col":1},"end":{"lineNumber":2251,"utf16Col":2}}},{"name":"_freqToBin","kind":"method","identStart":71191,"identEnd":71201,"extentStart":71191,"extentEnd":71397,"fullyQualifiedName":"AudioMotionAnalyzer._freqToBin","identUtf16":{"start":{"lineNumber":2256,"utf16Col":1},"end":{"lineNumber":2256,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":2256,"utf16Col":1},"end":{"lineNumber":2261,"utf16Col":2}}},{"name":"_makeGrad","kind":"method","identStart":71451,"identEnd":71460,"extentStart":71451,"extentEnd":74569,"fullyQualifiedName":"AudioMotionAnalyzer._makeGrad","identUtf16":{"start":{"lineNumber":2266,"utf16Col":1},"end":{"lineNumber":2266,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":2266,"utf16Col":1},"end":{"lineNumber":2343,"utf16Col":2}}},{"name":"_normalizedB","kind":"method","identStart":74626,"identEnd":74638,"extentStart":74626,"extentEnd":75171,"fullyQualifiedName":"AudioMotionAnalyzer._normalizedB","identUtf16":{"start":{"lineNumber":2348,"utf16Col":1},"end":{"lineNumber":2348,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":2348,"utf16Col":1},"end":{"lineNumber":2364,"utf16Col":2}}},{"name":"clamp","kind":"function","identStart":74755,"identEnd":74760,"extentStart":74755,"extentEnd":74830,"fullyQualifiedName":"AudioMotionAnalyzer.clamp","identUtf16":{"start":{"lineNumber":2351,"utf16Col":5},"end":{"lineNumber":2351,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":2351,"utf16Col":5},"end":{"lineNumber":2351,"utf16Col":80}}},{"name":"dBToLinear","kind":"function","identStart":74837,"identEnd":74847,"extentStart":74837,"extentEnd":74875,"fullyQualifiedName":"AudioMotionAnalyzer.dBToLinear","identUtf16":{"start":{"lineNumber":2352,"utf16Col":5},"end":{"lineNumber":2352,"utf16Col":15}},"extentUtf16":{"start":{"lineNumber":2352,"utf16Col":5},"end":{"lineNumber":2352,"utf16Col":43}}},{"name":"_setCanvas","kind":"method","identStart":75244,"identEnd":75254,"extentStart":75244,"extentEnd":77333,"fullyQualifiedName":"AudioMotionAnalyzer._setCanvas","identUtf16":{"start":{"lineNumber":2369,"utf16Col":1},"end":{"lineNumber":2369,"utf16Col":11}},"extentUtf16":{"start":{"lineNumber":2369,"utf16Col":1},"end":{"lineNumber":2429,"utf16Col":2}}},{"name":"_setGradient","kind":"method","identStart":77525,"identEnd":77537,"extentStart":77525,"extentEnd":77826,"fullyQualifiedName":"AudioMotionAnalyzer._setGradient","identUtf16":{"start":{"lineNumber":2437,"utf16Col":1},"end":{"lineNumber":2437,"utf16Col":13}},"extentUtf16":{"start":{"lineNumber":2437,"utf16Col":1},"end":{"lineNumber":2448,"utf16Col":2}}},{"name":"_setProps","kind":"method","identStart":77865,"identEnd":77874,"extentStart":77865,"extentEnd":80120,"fullyQualifiedName":"AudioMotionAnalyzer._setProps","identUtf16":{"start":{"lineNumber":2453,"utf16Col":1},"end":{"lineNumber":2453,"utf16Col":10}},"extentUtf16":{"start":{"lineNumber":2453,"utf16Col":1},"end":{"lineNumber":2526,"utf16Col":2}}}]}},"copilotInfo":null,"csrf_tokens":{"/hvianna/audioMotion-analyzer/branches":{"post":"GMxsd5bqaK3uHAOVfyrenSL7ZQZj3paX77KW8G1xcUGxM-9PaEpIAg1aeiufz_hmmOqK5bTIXKWl9EVafO-bRQ"},"/repos/preferences":{"post":"UIWdPNcHl1OV4-1-eBvFFj70pO05f6sqrdg0U18KxET03cGdoOFFc_DZLrENun3l9ZdnVKspzhPGGFJsZ0VgNQ"}}},"title":"audioMotion-analyzer/src/audioMotion-analyzer.js at master · hvianna/audioMotion-analyzer","appPayload":{"helpUrl":"https://docs.github.com","findFileWorkerPath":"/assets-cdn/worker/find-file-worker-83d4418b406d.js","findInFileWorkerPath":"/assets-cdn/worker/find-in-file-worker-2dd6b5095052.js","githubDevUrl":null,"enabled_features":{"code_nav_ui_events":false,"copilot_conversational_ux":false,"copilot_conversational_ux_symbols":false,"copilot_conversational_ux_direct_connection":false,"copilot_popover_file_editor_header":false,"copilot_smell_icebreaker_ux":false}}}</script>
  <div data-target="react-app.reactRoot"></div>
</react-app>
</turbo-frame>



  </div>

</turbo-frame>

    </main>
  </div>

  </div>

          <footer class="footer width-full container-xl p-responsive" role="contentinfo">
  <h2 class='sr-only'>Footer</h2>

  <div class="position-relative d-flex flex-items-center pb-2 f6 color-fg-muted border-top color-border-muted flex-column-reverse flex-lg-row flex-wrap flex-lg-nowrap mt-6 pt-6">
    <div class="list-style-none d-flex flex-wrap col-0 col-lg-2 flex-justify-start flex-lg-justify-between mb-2 mb-lg-0">
      <div class="mt-2 mt-lg-0 d-flex flex-items-center">
        <a aria-label="Homepage" title="GitHub" class="footer-octicon mr-2" href="https://github.com">
          <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z"></path>
</svg>
</a>        <span>
        &copy; 2023 GitHub, Inc.
        </span>
      </div>
    </div>

    <nav aria-label='Footer' class="col-12 col-lg-8">
      <h3 class='sr-only' id='sr-footer-heading'>Footer navigation</h3>
      <ul class="list-style-none d-flex flex-wrap col-12 flex-justify-center flex-lg-justify-between mb-2 mb-lg-0" aria-labelledby='sr-footer-heading'>
          <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/site-policy/github-terms/github-terms-of-service" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to terms&quot;,&quot;label&quot;:&quot;text:terms&quot;}">Terms</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/site-policy/privacy-policies/github-privacy-statement" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;}">Privacy</a></li>
          <li class="mr-3 mr-lg-0"><a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;}" href="https://github.com/security">Security</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://www.githubstatus.com/" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to status&quot;,&quot;label&quot;:&quot;text:status&quot;}">Status</a></li>
          <li class="mr-3 mr-lg-0"><a data-ga-click="Footer, go to help, text:Docs" href="https://docs.github.com">Docs</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://support.github.com?tags=dotcom-footer" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to contact&quot;,&quot;label&quot;:&quot;text:contact&quot;}">Contact GitHub</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://github.com/pricing" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to Pricing&quot;,&quot;label&quot;:&quot;text:Pricing&quot;}">Pricing</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://docs.github.com" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to api&quot;,&quot;label&quot;:&quot;text:api&quot;}">API</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://services.github.com" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to training&quot;,&quot;label&quot;:&quot;text:training&quot;}">Training</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://github.blog" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to blog&quot;,&quot;label&quot;:&quot;text:blog&quot;}">Blog</a></li>
          <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>
      </ul>
    </nav>
  </div>

  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 color-fg-muted"></span>
  </div>
</footer>




  <div id="ajax-error-message" class="ajax-error-message flash flash-error" hidden>
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
    </button>
    You can’t perform that action at this time.
  </div>

    <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

    <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large" style="width:360px;">
  </div>
</div>

    <template id="snippet-clipboard-copy-button">
  <div class="zeroclipboard-container position-absolute right-0 top-0">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn js-clipboard-copy m-2 p-0 tooltipped-no-delay" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon m-2">
    <path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none m-2">
    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>
<template id="snippet-clipboard-copy-button-unpositioned">
  <div class="zeroclipboard-container">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn btn-invisible js-clipboard-copy m-2 p-0 tooltipped-no-delay d-flex flex-justify-center flex-items-center" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon">
    <path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none">
    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>




    </div>

    <div id="js-global-screen-reader-notice" class="sr-only" aria-live="polite" ></div>
  </body>
</html>

